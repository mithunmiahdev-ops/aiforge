import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { seedIfNeeded } from "./seed";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// <root>/src/db → project root
export const ROOT_DIR = path.resolve(__dirname, "../..");
export const DATA_DIR = process.env.DATABASE_PATH
  ? path.dirname(path.resolve(ROOT_DIR, process.env.DATABASE_PATH))
  : path.join(ROOT_DIR, "data");
export const DB_PATH = process.env.DATABASE_PATH
  ? path.resolve(ROOT_DIR, process.env.DATABASE_PATH)
  : path.join(ROOT_DIR, "data/app.db");
export const STORAGE_DIR = process.env.STORAGE_DIR
  ? path.resolve(ROOT_DIR, process.env.STORAGE_DIR)
  : path.join(ROOT_DIR, "storage");

type GlobalWithDb = typeof globalThis & { __aiforge_db?: Database.Database };

export function getDb(): Database.Database {
  const g = globalThis as GlobalWithDb;
  if (g.__aiforge_db) return g.__aiforge_db;
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
  fs.mkdirSync(path.join(STORAGE_DIR, "uploads"), { recursive: true });
  fs.mkdirSync(path.join(STORAGE_DIR, "generated"), { recursive: true });
  const db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.pragma("busy_timeout = 5000");
  db.exec(fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8"));
  g.__aiforge_db = db;
  seedIfNeeded(); // idempotent — guarded by system.seedVersion
  return db;
}

/** Run a SELECT returning all rows as plain objects. */
export function all<T = Record<string, any>>(db: Database.Database, sql: string, ...args: any[]): T[] {
  return db.prepare(sql).all(...args) as T[];
}
/** Run a SELECT returning the first row or null. */
export function get<T = Record<string, any>>(db: Database.Database, sql: string, ...args: any[]): T | null {
  return (db.prepare(sql).get(...args) as T) ?? null;
}
/** Run a mutation. */
export function run(db: Database.Database, sql: string, ...args: any[]): { changes: number; lastInsertRowid: number | bigint } {
  return db.prepare(sql).run(...args) as { changes: number; lastInsertRowid: number | bigint };
}
/** Escape LIKE wildcards. */
export function likeEscape(s: string): string {
  return s.replace(/[\\%_]/g, (c) => "\\" + c);
}

export const nowIso = () => new Date().toISOString();
