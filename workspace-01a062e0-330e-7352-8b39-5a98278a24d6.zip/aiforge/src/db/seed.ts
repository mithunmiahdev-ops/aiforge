import fs from "node:fs";
import path from "node:path";
import { getDb, get, run } from "./index";
import { hashPassword, randomToken } from "@/server/crypto";
import { DEFAULT_SETTINGS } from "@/server/settings";
import { STORAGE_DIR } from "./index";

/**
 * Seeds demo/initial content exactly once (guarded by system.seedVersion).
 * All demo content is clearly marked "(demo)" so the admin can replace it.
 */
export function seedIfNeeded() {
  const db = getDb();
  const seedVersionRow = get<{ value: string }>(db, "SELECT value FROM site_settings WHERE key = 'system'");
  let current = 0;
  if (seedVersionRow) { try { current = JSON.parse(seedVersionRow.value).seedVersion ?? 0; } catch {} }
  if (current >= 1) return;
  seed(db);
  run(db, "INSERT INTO site_settings (key, value) VALUES ('system', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
    JSON.stringify({ ...DEFAULT_SETTINGS.system, seedVersion: 1 }));
}

function seed(db: ReturnType<typeof getDb>) {
  // ── Settings groups ────────────────────────────────────────────────
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    if (key === "system") continue;
    run(db, "INSERT OR IGNORE INTO site_settings (key, value) VALUES (?,?)", key, JSON.stringify(value));
  }

  // ── Roles ──────────────────────────────────────────────────────────
  run(db, "INSERT OR IGNORE INTO admin_roles (id, name, description, permissions) VALUES (1,'Administrator','Full access to every part of the platform.','[\"*\"]')");
  run(db, "INSERT OR IGNORE INTO admin_roles (id, name, description, permissions) VALUES (2,'Editor','Can manage tools, blog, prompt templates and FAQs.','[\"tools.manage\",\"blog.manage\",\"templates.manage\",\"content.manage\"]')");
  run(db, "INSERT OR IGNORE INTO admin_roles (id, name, description, permissions) VALUES (3,'Viewer','Read-only access to the dashboard.','[\"dashboard.view\"]')");

  // ── Initial admin ──────────────────────────────────────────────────
  const adminExists = get(db, "SELECT id FROM admin_users WHERE role_id = 1");
  if (!adminExists) {
    const email = process.env.ADMIN_EMAIL || "admin@example.com";
    let password = process.env.ADMIN_PASSWORD || "";
    let generated = false;
    if (!password || password.length < 10) {
      password = randomToken(12); // strong random, communicated once below
      generated = true;
    }
    run(db, "INSERT INTO admin_users (email, name, password_hash, role_id) VALUES (?,?,?,1)",
      email, process.env.ADMIN_NAME || "Administrator", hashPassword(password));
    if (generated) {
      const line = `Initial admin account\nEmail: ${email}\nPassword: ${password}\n(delete this file after first login)\n`;
      try { fs.writeFileSync(path.join(path.dirname(STORAGE_DIR), "data", ".initial-admin.txt"), line, { mode: 0o600 }); } catch {}
      console.log("\n┌──────────────────────────────────────────────────┐");
      console.log("│  INITIAL ADMIN ACCOUNT (save it, then delete)   │");
      console.log(`│  Email:    ${email.padEnd(38)}│`);
      console.log(`│  Password: ${password.padEnd(38)}│`);
      console.log("│  Also written to data/.initial-admin.txt        │");
      console.log("└──────────────────────────────────────────────────┘\n");
    }
  }

  // ── Tool categories ────────────────────────────────────────────────
  const cats: [string, string, string, string][] = [
    ["Video", "video", "AI video creation and video prompt tools", "clapperboard"],
    ["Image", "image", "AI image generation and image prompt tools", "image"],
    ["Writing", "writing", "AI writing tools for stories, scripts, blogs and copy", "pen-line"],
    ["Audio", "audio", "AI audio, voice and text-to-speech tools", "audio-lines"],
    ["Marketing", "marketing", "AI tools for marketers and creators", "megaphone"],
    ["SEO", "seo", "AI tools for search engine optimization", "search"],
  ];
  for (let i = 0; i < cats.length; i++) {
    run(db, "INSERT OR IGNORE INTO tool_categories (name, slug, description, icon, sort) VALUES (?,?,?,?,?)", ...cats[i], i);
  }

  // ── Tools ──────────────────────────────────────────────────────────
  const tools = seedTools();
  const desc = (t: ReturnType<typeof seedTools>[number]) =>
    `**${t.name}** — ${t.tagline}. Free, no signup, no account needed.\n\n` +
    `### How to use\n1. Describe what you want to create in the prompt box\n2. Pick your options (style, format, length)\n3. Press **Generate**, preview the result and download it\n\n` +
    `Daily fair-use limits apply so the tool stays fast and free for everyone. ${t.isNew ? "This tool is new — more features are on the way." : ""}`;
  for (const t of tools) {
    run(db, `INSERT OR IGNORE INTO tools
      (name, slug, tagline, description, category_id, icon, type, capability, config, is_featured, is_popular, is_new, enabled, sort, daily_limit, cooldown_seconds, max_prompt_chars, max_duration_seconds, seo_title, seo_description)
      VALUES (?,?,?,?,(SELECT id FROM tool_categories WHERE slug=?),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      t.name, t.slug, t.tagline, desc(t), t.category, t.icon, t.type, t.capability,
      JSON.stringify(t.config), t.featured ? 1 : 0, t.popular ? 1 : 0, t.isNew ? 1 : 0, 1, t.sort,
      t.dailyLimit, t.cooldown, t.maxPrompt, t.maxDuration, t.seoTitle, t.seoDesc);
  }

  // ── Demo providers (enabled by default so every tool works instantly out of the
  //    box; output is always clearly watermarked as DEMO — replace with a real
  //    provider in Admin → AI Providers) ──────────────────────────────────────
  const demoProviders: [string, string][] = [["Demo Video Provider", "video"], ["Demo Image Provider", "image"], ["Demo Text Provider", "text"], ["Demo Audio Provider", "audio"]];
  for (const [name, cap] of demoProviders) {
    run(db, "INSERT INTO ai_providers (name, capability, type, enabled, priority, notes) VALUES (?,?, 'demo', 1, 900, ?)",
      name, cap, "Built-in demo adapter — ENABLED so tools work before you add API keys. Returns clearly-watermarked placeholder output; not real AI. Add a real provider (lower priority number) and it takes over automatically, with this demo as fallback.");
  }
  run(db, "INSERT INTO ai_providers (name, capability, type, endpoint, model, enabled, priority, notes) VALUES ('OpenAI-compatible (text)','text','openai','https://api.openai.com/v1','gpt-4o-mini',0,100,'Set your API key, then enable. Works with any OpenAI-compatible chat endpoint.')");
  run(db, "INSERT INTO ai_providers (name, capability, type, endpoint, model, enabled, priority, notes) VALUES ('OpenAI-compatible (image)','image','openai','https://api.openai.com/v1','dall-e-3',0,100,'OpenAI-compatible /images/generations endpoint.')");
  run(db, "INSERT INTO ai_providers (name, capability, type, endpoint, model, enabled, priority, notes) VALUES ('OpenAI-compatible (TTS)','audio','openai','https://api.openai.com/v1','tts-1',0,100,'OpenAI-compatible /audio/speech endpoint.')");
  run(db, "INSERT INTO ai_providers (name, capability, type, endpoint, model, enabled, priority, notes) VALUES ('Custom HTTP (video)','video','custom-http','',  '',0,100,'POSTs {tool, params, prompt} to your endpoint; expects JSON {url} pointing to a generated video. Use for any video provider.')");

  // ── Prompt templates ───────────────────────────────────────────────
  const templates: [string, string, string, string][] = [
    ["Blog outline (ChatGPT)", "Structured blog post outline with SEO sections.", "ChatGPT",
      "You are an expert content strategist. Write a detailed outline for a blog post about {{topic}} targeted at {{audience}}. Include an H1, H2 sections with 2-3 bullet points each, a hook introduction, and a conclusion with a call to action. Tone: {{tone}}."],
    ["Midjourney image prompt", "Rich Midjourney v6 prompt with style parameters.", "Midjourney",
      "{{subject}}, {{style}} style, dramatic lighting, ultra detailed, professional color grading, balanced composition --ar {{aspect}} --v 6 --style raw"],
    ["YouTube script hook", "First 30 seconds of a YouTube video that retains viewers.", "YouTube",
      "Write 3 variations of a 30-second opening hook for a YouTube video about {{topic}} aimed at {{audience}}. Each hook must open with a bold claim, create curiosity, and end with a promise. Conversational {{tone}} tone."],
    ["TikTok content ideas", "A week of short-form video ideas.", "TikTok",
      "Give me 7 TikTok video ideas about {{topic}} for {{audience}}. For each: a 1-line hook, a 3-beat structure, and a caption with 5 hashtags. Tone: {{tone}}."],
    ["Product description", "Conversion-focused e-commerce copy.", "ChatGPT",
      "Write a product description for {{product}} highlighting benefits over features, addressing objections, and ending with a subtle call to action. Audience: {{audience}}. Tone: {{tone}}. Length: {{length}}."],
    ["SEO titles", "10 click-worthy, honest SEO titles.", "ChatGPT",
      "Generate 10 SEO title tags (max 60 characters) for an article about {{topic}}. Prioritize clarity and honest curiosity over clickbait. Include the primary keyword naturally."],
  ];
  templates.forEach(([name, desc, platform, content], i) => {
    run(db, "INSERT OR IGNORE INTO prompt_templates (name, description, platform, content, sort) VALUES (?,?,?,?,?)", name, desc, platform, content, i);
  });

  // ── FAQs (home) ────────────────────────────────────────────────────
  const faqs: [string, string][] = [
    ["Do I need an account to use these AI tools?", "No. Every tool on this site works without registration, login or email. Open a tool, enter your prompt and generate — that's it."],
    ["Is it really free?", "Yes. The tools are free to use within daily fair-use limits. Limits exist to prevent abuse, and you can see the remaining generations on each tool page."],
    ["How many generations can I make per day?", "Each tool has its own configurable daily limit and a short cooldown between generations. The exact numbers are shown on the tool page before you start."],
    ["Can I use the generated content commercially?", "Generally yes for content you create, but this depends on the underlying AI provider's terms. Check the provider policy for the tool you are using, and always review outputs before publishing."],
    ["How is abuse prevented without accounts?", "We use anonymous session identifiers, IP-based throttling, request quotas and server-side validation. No personal information is required or stored."],
    ["What happens if an AI service is unavailable?", "You'll see a clear notice such as \"Generation is temporarily unavailable\". Nothing breaks — you can retry, and your prompt is preserved."],
  ];
  faqs.forEach(([q, a], i) => run(db, "INSERT INTO faqs (question, answer, section, sort) VALUES (?,?, 'home', ?)", q, a, i));

  // ── Homepage sections ──────────────────────────────────────────────
  const sections: [string, string, string, string, string, number][] = [
    ["hero", "hero", "", "", JSON.stringify({
      badge: "No signup · Free to use",
      headline: "Create Powerful AI Content — Completely Free",
      subheadline: "Generate videos, images, prompts, audio and written content in seconds. No account, no credit card, no limits on creativity — just open a tool and start creating.",
      ctaPrimaryLabel: "Start Creating Free", ctaPrimaryHref: "/tools",
      ctaSecondaryLabel: "Explore AI Tools", ctaSecondaryHref: "/tools",
    }), 0],
    ["categories", "categories", "Create anything with AI", "Pick a category and start generating — every tool is free and requires no account.", "{}", 1],
    ["popular_tools", "popular_tools", "Popular AI tools", "The tools visitors use most.", "{}", 2],
    ["how_it_works", "how_it_works", "How it works", "From idea to output in three steps.", JSON.stringify({
      steps: [
        { title: "Pick a tool", desc: "Choose from video, image, prompt, audio and writing tools — all free.", icon: "mouse-pointer-click" },
        { title: "Describe your idea", desc: "Type a prompt, pick a style and set your options.", icon: "pen-line" },
        { title: "Generate & download", desc: "Preview the result, regenerate if you like, and download it.", icon: "download" },
      ],
    }), 3],
    ["why_us", "why_us", "Why creators choose us", "A genuinely free AI workspace — built to respect you.", JSON.stringify({
      items: [
        { title: "Truly free, truly open", desc: "No paywalls on the tools, no forced accounts, no hidden trials.", icon: "gift" },
        { title: "Privacy by design", desc: "We don't ask for your email. Minimal data, honest policies.", icon: "shield-check" },
        { title: "Every creator category", desc: "Video, image, audio, prompts and writing in one place.", icon: "layout-grid" },
        { title: "Fast, focused tools", desc: "Clean interfaces that get you from prompt to output fast.", icon: "zap" },
      ],
    }), 4],
    ["featured_tools", "featured_tools", "Featured tools", "Hand-picked tools to start with.", "{}", 5],
    ["blog_latest", "blog_latest", "Latest from the blog", "Guides, prompt ideas and AI creation tips.", "{}", 6],
    ["faq", "faq", "Frequently asked questions", "", "{}", 7],
    ["cta", "cta", "", "", JSON.stringify({
      title: "Ready to create something amazing?",
      sub: "Open any tool and generate your first AI content in seconds — free, no signup.",
      ctaLabel: "Create for Free", ctaHref: "/tools",
    }), 8],
    ["stats", "stats", "Numbers", "Disabled by default — enable in the admin and enter your own real statistics only. Never publish numbers you cannot verify.", JSON.stringify({ items: [] }), 9],
  ];
  for (const [key, type, title, subtitle, content, sort] of sections) {
    run(db, "INSERT OR IGNORE INTO homepage_sections (key, type, title, subtitle, content, enabled, sort) VALUES (?,?,?,?,?,?,?)",
      key, type, title, subtitle, content, key === "stats" ? 0 : 1, sort);
  }

  // ── Navigation ─────────────────────────────────────────────────────
  const nav: [string, string, string, number, number][] = [
    ["header", "/", "Home", 0, 0],
    ["header", "/tools", "AI Tools", 1, 0],
    ["header", "/tools/ai-video-generator", "Video Generator", 2, 0],
    ["header", "/tools/ai-image-generator", "Image Generator", 3, 0],
    ["header", "/tools/ai-prompt-generator", "Prompt Generator", 4, 0],
    ["header", "/tools/ai-audio-generator", "Audio Generator", 5, 0],
    ["header", "/blog", "Blog", 6, 0],
    ["header", "/pricing", "Pricing", 7, 0],
    ["header", "/about", "About", 8, 0],
    ["header", "/contact", "Contact", 9, 0],
  ];
  for (const [loc, url, label, sort] of nav) run(db, "INSERT INTO navigation_items (location, url, label, sort) VALUES (?,?,?,?)", loc, url, label, sort);
  const more = get<{ id: number }>(db, "SELECT id FROM navigation_items WHERE label='AI Tools' AND location='header'");
  if (more) {
    const moreItems: [string, number][] = [["/tools/ai-story-generator", 0], ["/tools/ai-youtube-script-generator", 1], ["/tools/ai-blog-writer", 2], ["/tools/ai-thumbnail-prompt-generator", 3], ["/tools/ai-hashtag-generator", 4], ["/tools", 5]];
    for (const [url, sort] of moreItems) run(db, "INSERT INTO navigation_items (location, parent_id, url, label, sort) VALUES ('header',?,?,?,?)", more.id, url, labelFor(url), sort);
  }
  run(db, "INSERT INTO navigation_items (location, url, label, sort, is_button, button_style) VALUES ('header_cta','/tools','Try AI Tools',0,1,'primary')");
  run(db, "INSERT INTO navigation_items (location, url, label, sort, is_button, button_style) VALUES ('header_cta','/admin/login','Admin Login',1,1,'ghost')");

  const footerCols: [string, [string, string][]][] = [
    ["AI Tools", [["/tools/ai-video-generator", "AI Video Generator"], ["/tools/ai-image-generator", "AI Image Generator"], ["/tools/ai-prompt-generator", "AI Prompt Generator"], ["/tools/ai-audio-generator", "AI Audio Generator"], ["/tools", "All AI Tools"]]],
    ["Resources", [["/blog", "Blog"], ["/tools?sort=popular", "Popular Tools"], ["/tools?sort=new", "New Tools"], ["/search", "Search"]]],
    ["Company", [["/about", "About"], ["/pricing", "Pricing"], ["/contact", "Contact"]]],
    ["Legal", [["/privacy-policy", "Privacy Policy"], ["/terms", "Terms of Service"], ["/cookie-policy", "Cookie Policy"], ["/disclaimer", "Disclaimer"]]],
  ];
  for (const [group, items] of footerCols) {
    for (let i = 0; i < items.length; i++) run(db, "INSERT INTO navigation_items (location, footer_group, url, label, sort) VALUES ('footer',?,?,?,?)", group, items[i][0], items[i][1], i);
  }

  // ── Ad placements (all disabled; configure in Admin → Ads) ─────────
  const placements: [string, string, string][] = [
    ["below_hero", "Below hero (homepage)", "auto"],
    ["content_between", "Between content sections", "auto"],
    ["tool_top", "Tool page — top", "auto"],
    ["tool_bottom", "Tool page — bottom", "auto"],
    ["sidebar_desktop", "Sidebar (desktop only)", "vertical"],
    ["blog_content", "Blog article — after content", "auto"],
    ["footer", "Above footer", "auto"],
  ];
  placements.forEach(([key, name, format], i) => run(db, "INSERT OR IGNORE INTO ad_placements (key, name, format, sort) VALUES (?,?,?,?)", key, name, format, i));

  // ── Legal + about pages (templates — review before production) ─────
  const pages: [string, string, string][] = [
    ["privacy-policy", "Privacy Policy", `**Privacy Policy (template — review & customize in Admin → Legal Pages)** *(demo)*

_Last updated: pending_

We respect your privacy. Because our AI tools require **no account**, we collect very little data.

**What we collect**
- Anonymous usage data: anonymous session identifiers, approximate IP-based rate-limit counters, and tool usage counts (tool name, timestamps, success/failure).
- If you contact us: the name, email and message you submit.
- Standard server logs (IP, user agent, timestamps) for security and abuse prevention.

**What we don't collect**
- No accounts, no passwords, no emails for tool usage, no tracking profiles.

**Cookies**
- A strictly-necessary anonymous session cookie for fair-use limits, and (where enabled) an analytics/ads consent cookie. See our Cookie Policy.

**AI providers**
When you generate content, your prompt is sent to the configured AI provider solely to process your request. Prompts are not used for marketing.

**Data retention & rights**
Usage records are kept for analytics and abuse prevention and deleted when no longer needed. Contact us to request deletion of any personal data you provided.`],
    ["terms", "Terms of Service", `**Terms of Service (template — review & customize)** *(demo)*

By using this website you agree to these terms.

**Free service.** Tools are provided free of charge within fair-use limits. Limits may change.

**Acceptable use.** Do not use the tools to create illegal, harmful, deceptive or rights-infringing content. Automated scraping and attempts to bypass rate limits are prohibited.

**AI-generated content.** Outputs are generated by AI and may be inaccurate. You are responsible for reviewing and how you use generated content. Commercial use depends on the underlying provider's terms.

**No warranty.** The service is provided "as is" without warranties of any kind.`],
    ["cookie-policy", "Cookie Policy", `**Cookie Policy (template)** *(demo)*

**Strictly necessary cookies**
- \`aiforge_anon\` — an anonymous identifier used solely for fair-use rate limiting. No personal data.

**Optional cookies (only with consent)**
- Analytics (e.g., Google Analytics) and advertising (e.g., Google AdSense) cookies, only if you accept in the consent banner and only if the site operator has enabled them.

**Managing cookies**
You can block or delete cookies in your browser settings. The tools keep working without optional cookies.`],
    ["disclaimer", "Disclaimer", `**Disclaimer (template)** *(demo)*

Content on this site is generated with artificial intelligence and provided for informational and creative purposes only. AI output may contain errors and must be reviewed before use. We are not liable for decisions made based on AI-generated content.

External links and advertisements are not endorsements.`],
    ["about", "About", `**About *(demo — edit in Admin → Legal Pages)***

We believe powerful AI creation tools should be open to everyone — not locked behind signups and subscriptions.

**What we do**
This platform brings free AI tools for video, images, prompts, audio and writing into one clean, fast workspace. Open a tool, describe your idea, and download the result.

**Why free?**
Fair-use limits and unobtrusive advertising keep the tools sustainable while staying free for creators.

**Our principles**
- No forced accounts
- Honest labeling of what is AI-generated
- Minimal data collection
- Clear limits, transparently shown`],
  ];
  for (const [slug, title, content] of pages) run(db, "INSERT OR IGNORE INTO pages (slug, title, content, is_system) VALUES (?,?,?,1)", slug, title, content);

  // ── Blog demo posts ────────────────────────────────────────────────
  const blogCats: [string, string][] = [["Guides", "guides"], ["Prompt Ideas", "prompt-ideas"], ["News", "news"]];
  for (const [name, slug] of blogCats) run(db, "INSERT OR IGNORE INTO blog_categories (name, slug) VALUES (?,?)", name, slug);

  const posts = seedPosts();
  for (const p of posts) {
    run(db, `INSERT OR IGNORE INTO blog_posts
      (title, slug, excerpt, content, status, publish_at, published_at, author_name, category_id, tags, reading_minutes, faq)
      VALUES (?,?,?,?, 'published', datetime('now', ?), datetime('now', ?), ?, (SELECT id FROM blog_categories WHERE slug=?), ?, ?, ?)`,
      p.title, p.slug, p.excerpt, p.content, `-${p.daysAgo} days`, `-${p.daysAgo} days`, "Admin", p.category, JSON.stringify(p.tags), p.reading, JSON.stringify(p.faq));
  }
}

function labelFor(url: string): string {
  const map: Record<string, string> = {
    "/tools/ai-story-generator": "AI Story Generator",
    "/tools/ai-youtube-script-generator": "YouTube Script Generator",
    "/tools/ai-blog-writer": "AI Blog Writer",
    "/tools/ai-thumbnail-prompt-generator": "Thumbnail Prompt Generator",
    "/tools/ai-hashtag-generator": "Hashtag Generator",
    "/tools": "View all tools",
  };
  return map[url] ?? url;
}

function seedTools() {
  const videoConfig = {
    styles: ["Cinematic", "Realistic", "3D Animation", "Cartoon", "Anime", "Documentary", "Product Advertisement", "Social Media", "Custom"],
    aspects: ["16:9", "9:16", "1:1"],
    durations: [5, 10, 15, 30],
    qualities: ["Standard", "High"],
  };
  const imageConfig = {
    presets: ["Photorealistic", "Cinematic", "3D", "Cartoon", "Anime", "Illustration", "Product Photography", "Fantasy", "Architecture", "Portrait"],
    aspects: ["1:1", "16:9", "9:16", "4:3", "3:4"],
    qualities: ["Standard", "High"],
    maxImages: 4,
  };
  const promptConfig = {
    platforms: ["ChatGPT", "Gemini", "Claude", "Midjourney", "AI Image Generators", "AI Video Generators", "AI Music Generators", "Social Media", "YouTube", "TikTok", "Facebook"],
    contentTypes: ["Blog post", "Image prompt", "Video prompt", "Social post", "Ad copy", "Email", "Product page", "Script", "Song lyrics"],
    tones: ["Professional", "Friendly", "Casual", "Persuasive", "Inspirational", "Humorous", "Academic"],
    lengths: ["Short", "Medium", "Long", "One-liner"],
  };
  const audioConfig = { moods: ["Neutral", "Energetic", "Calm", "Dramatic", "Cheerful"], defaultDuration: 30 };
  const t = (fields: any[], systemPrompt: string) => ({ fields, systemPrompt });
  return [
    { name: "AI Video Generator", slug: "ai-video-generator", tagline: "Turn a text prompt into a short AI video", category: "video", icon: "clapperboard", type: "video", capability: "video", config: videoConfig, featured: true, popular: true, isNew: true, sort: 0, dailyLimit: 5, cooldown: 45, maxPrompt: 1500, maxDuration: 60, seoTitle: "", seoDesc: "Free AI video generator — create short videos from a text prompt. No signup, no account required." },
    { name: "AI Image Generator", slug: "ai-image-generator", tagline: "Generate high-quality AI images from text", category: "image", icon: "image", type: "image", capability: "image", config: imageConfig, featured: true, popular: true, isNew: false, sort: 1, dailyLimit: 15, cooldown: 30, maxPrompt: 1500, maxDuration: 60, seoTitle: "", seoDesc: "Free AI image generator — create images from text prompts in multiple styles and aspect ratios. No signup." },
    { name: "AI Prompt Generator", slug: "ai-prompt-generator", tagline: "Build expert-level prompts for any AI platform", category: "writing", icon: "wand-sparkles", type: "prompt", capability: "text", config: promptConfig, featured: true, popular: true, isNew: false, sort: 2, dailyLimit: 30, cooldown: 15, maxPrompt: 1000, maxDuration: 60, seoTitle: "", seoDesc: "Free AI prompt generator — craft optimized prompts for ChatGPT, Midjourney, Claude and more. No signup." },
    { name: "AI Audio Generator", slug: "ai-audio-generator", tagline: "Turn text into natural AI speech and audio", category: "audio", icon: "audio-lines", type: "audio", capability: "audio", config: audioConfig, featured: true, popular: false, isNew: true, sort: 3, dailyLimit: 10, cooldown: 60, maxPrompt: 4000, maxDuration: 300, seoTitle: "", seoDesc: "Free AI audio generator — convert text to speech with different voices, languages and moods. No signup." },
    { name: "AI Story Generator", slug: "ai-story-generator", tagline: "Create original stories in any genre", category: "writing", icon: "book-open", type: "text", capability: "text", config: t([
      { name: "genre", label: "Genre", type: "select", options: ["Fantasy", "Sci-Fi", "Mystery", "Romance", "Horror", "Adventure", "Comedy", "Drama", "Fairy tale"] },
      { name: "tone", label: "Tone", type: "select", options: ["Whimsical", "Dark", "Uplifting", "Suspenseful", "Nostalgic", "Humorous"] },
      { name: "length", label: "Length", type: "select", options: ["Flash fiction", "Short story", "Chapter"] },
    ], "You are a skilled storyteller. Write a {{length}} in the {{genre}} genre with a {{tone}} tone, based on the user's premise. Use vivid sensory detail and a clear narrative arc."), featured: false, popular: true, isNew: false, sort: 4, dailyLimit: 20, cooldown: 20, maxPrompt: 1000, maxDuration: 60, seoTitle: "", seoDesc: "Free AI story generator — create original short stories from a premise. Any genre, any tone. No signup." },
    { name: "AI YouTube Script Generator", slug: "ai-youtube-script-generator", tagline: "Write engaging YouTube scripts with hooks", category: "marketing", icon: "youtube", type: "text", capability: "text", config: t([
      { name: "duration", label: "Target video length", type: "select", options: ["60 seconds (Short)", "5 minutes", "10 minutes", "20+ minutes"] },
      { name: "style", label: "Style", type: "select", options: ["Tutorial", "Listicle", "Review", "Vlog", "Explainer", "Documentary"] },
    ], "You are a professional YouTube scriptwriter. Write a complete script for a {{duration}} {{style}} video: a strong hook (first 15 seconds), structured sections, B-roll suggestions in brackets, and a call to action."), featured: false, popular: false, isNew: false, sort: 5, dailyLimit: 15, cooldown: 30, maxPrompt: 600, maxDuration: 60, seoTitle: "", seoDesc: "Free AI YouTube script generator with hooks and structure. No signup required." },
    { name: "AI Blog Writer", slug: "ai-blog-writer", tagline: "Draft SEO-friendly blog articles in minutes", category: "writing", icon: "pen-line", type: "text", capability: "text", config: t([
      { name: "audience", label: "Target audience", type: "text", placeholder: "e.g. beginner photographers" },
      { name: "tone", label: "Tone", type: "select", options: ["Professional", "Casual", "Friendly", "Authoritative"] },
      { name: "keywords", label: "Focus keywords (comma separated)", type: "text", placeholder: "e.g. ai tools, free video generator" },
    ], "You are an expert blog writer. Write a well-structured, SEO-aware article based on the user's topic for {{audience}} in a {{tone}} tone. Use headings (##), short paragraphs and a conclusion. Naturally include: {{keywords}}."), featured: false, popular: false, isNew: false, sort: 6, dailyLimit: 10, cooldown: 60, maxPrompt: 300, maxDuration: 60, seoTitle: "", seoDesc: "Free AI blog writer — draft structured, SEO-friendly articles from a topic. No signup." },
    { name: "AI Product Description Generator", slug: "ai-product-description-generator", tagline: "Persuasive e-commerce copy that sells", category: "marketing", icon: "package", type: "text", capability: "text", config: t([
      { name: "audience", label: "Target customer", type: "text", placeholder: "e.g. busy parents" },
      { name: "tone", label: "Tone", type: "select", options: ["Persuasive", "Premium", "Playful", "Minimal"] },
    ], "You are a conversion copywriter. Write a product description for the user's product targeting {{audience}} in a {{tone}} tone: a benefit-led opening, 3-5 feature bullets, an objection handler, and a call to action."), featured: false, popular: false, isNew: false, sort: 7, dailyLimit: 20, cooldown: 20, maxPrompt: 600, maxDuration: 60, seoTitle: "", seoDesc: "Free AI product description generator for e-commerce copy. No signup." },
    { name: "AI Social Media Caption Generator", slug: "ai-social-media-caption-generator", tagline: "Scroll-stopping captions for every platform", category: "marketing", icon: "share-2", type: "text", capability: "text", config: t([
      { name: "platform", label: "Platform", type: "select", options: ["Instagram", "TikTok", "Facebook", "X / Twitter", "LinkedIn", "Pinterest"] },
      { name: "tone", label: "Tone", type: "select", options: ["Fun", "Professional", "Witty", "Inspiring", "Bold"] },
    ], "You are a social media expert. Write 5 caption options for {{platform}} in a {{tone}} tone based on the user's description. Include emoji where appropriate, a CTA in 2 of them, and suggest 3-5 hashtags each."), featured: false, popular: false, isNew: true, sort: 8, dailyLimit: 25, cooldown: 15, maxPrompt: 500, maxDuration: 60, seoTitle: "", seoDesc: "Free AI caption generator for Instagram, TikTok, X and more. No signup." },
    { name: "AI Thumbnail Prompt Generator", slug: "ai-thumbnail-prompt-generator", tagline: "Prompts for scroll-stopping YouTube thumbnails", category: "marketing", icon: "layout-template", type: "text", capability: "text", config: t([
      { name: "platform", label: "Platform", type: "select", options: ["YouTube", "Blog", "TikTok", "Pinterest"] },
      { name: "style", label: "Style", type: "select", options: ["Bold & minimal", "Photorealistic", "Cartoon", "Tech / neon", "Text-focused"] },
    ], "You are an expert at AI image prompts for thumbnails. Based on the user's video/topic, write 3 detailed image-generation prompts for {{platform}} thumbnails in a {{style}} style. Include composition, subject emphasis, color and lighting guidance suitable for small-screen visibility."), featured: false, popular: false, isNew: true, sort: 9, dailyLimit: 25, cooldown: 15, maxPrompt: 400, maxDuration: 60, seoTitle: "", seoDesc: "Free AI thumbnail prompt generator — get detailed image prompts for YouTube thumbnails. No signup." },
    { name: "AI Character Prompt Generator", slug: "ai-character-prompt-generator", tagline: "Detailed character prompts for art & stories", category: "image", icon: "user-round", type: "text", capability: "text", config: t([
      { name: "use", label: "Intended use", type: "select", options: ["AI art (image prompt)", "Novel / story", "Game design", "Roleplay"] },
      { name: "artStyle", label: "Art style", type: "select", options: ["Realistic", "Anime", "Comic", "3D render", "Painterly", "Pixel art"] },
    ], "You are a character designer. Create a richly detailed character prompt for {{use}} in a {{artStyle}} style from the user's concept: appearance, clothing, expression, pose, environment, lighting and mood."), featured: false, popular: false, isNew: false, sort: 10, dailyLimit: 25, cooldown: 15, maxPrompt: 500, maxDuration: 60, seoTitle: "", seoDesc: "Free AI character prompt generator for art, novels and games. No signup." },
    { name: "AI Image-to-Prompt", slug: "ai-image-to-prompt", tagline: "Describe an image idea as a perfect generation prompt", category: "image", icon: "scan-eye", type: "text", capability: "text", config: t([
      { name: "target", label: "Prompt target", type: "select", options: ["Midjourney", "Stable Diffusion", "DALL·E", "Any image AI"] },
      { name: "detail", label: "Detail level", type: "select", options: ["Concise", "Detailed", "Exhaustive"] },
    ], "You convert image descriptions into optimized generation prompts for {{target}} at a {{detail}} level. Include subject, style, composition, lighting, camera/lens feel and parameters. The user describes an image idea:"), featured: false, popular: false, isNew: false, sort: 11, dailyLimit: 25, cooldown: 15, maxPrompt: 800, maxDuration: 60, seoTitle: "", seoDesc: "Free image-to-prompt converter — turn image ideas into optimized AI prompts. No signup." },
    { name: "AI Video Prompt Generator", slug: "ai-video-prompt-generator", tagline: "Cinematic prompts for AI video models", category: "video", icon: "film", type: "text", capability: "text", config: t([
      { name: "platform", label: "Video model", type: "select", options: ["Sora-style", "Runway", "Pika", "Kling", "Any video AI"] },
      { name: "shot", label: "Shot type", type: "select", options: ["Cinematic wide", "Close-up", "Drone", "Tracking shot", "Product shot"] },
    ], "You write prompts for AI video generation for {{platform}}. Based on the user's idea, produce a {{shot}} prompt: scene, subject action, camera movement, lighting, mood, style and duration hints."), featured: false, popular: false, isNew: false, sort: 12, dailyLimit: 25, cooldown: 15, maxPrompt: 600, maxDuration: 60, seoTitle: "", seoDesc: "Free AI video prompt generator for Sora, Runway, Pika and more. No signup." },
    { name: "AI SEO Title Generator", slug: "ai-seo-title-generator", tagline: "Click-worthy titles under 60 characters", category: "seo", icon: "heading", type: "text", capability: "text", config: t([
      { name: "keyword", label: "Primary keyword (optional)", type: "text", placeholder: "e.g. ai video generator" },
      { name: "count", label: "How many", type: "select", options: ["5", "10", "15"] },
    ], "You are an SEO specialist. Generate {{count}} title tags (max 60 characters) for the user's content. Honest, specific and curiosity-driven — never misleading clickbait. Naturally include the keyword {{keyword}} when it fits."), featured: false, popular: false, isNew: false, sort: 13, dailyLimit: 30, cooldown: 10, maxPrompt: 300, maxDuration: 60, seoTitle: "", seoDesc: "Free AI SEO title generator — 60-character titles that earn clicks. No signup." },
    { name: "AI Meta Description Generator", slug: "ai-meta-description-generator", tagline: "Compelling meta descriptions under 160 characters", category: "seo", icon: "text", type: "text", capability: "text", config: t([
      { name: "count", label: "How many", type: "select", options: ["3", "5", "8"] },
    ], "You write meta descriptions (150-160 characters) for the user's page. Include the core value proposition and a soft call to action. Produce {{count}} options."), featured: false, popular: false, isNew: false, sort: 14, dailyLimit: 30, cooldown: 10, maxPrompt: 400, maxDuration: 60, seoTitle: "", seoDesc: "Free AI meta description generator — perfect-length descriptions for SEO. No signup." },
    { name: "AI Hashtag Generator", slug: "ai-hashtag-generator", tagline: "Relevant hashtags that actually get reach", category: "marketing", icon: "hash", type: "text", capability: "text", config: t([
      { name: "platform", label: "Platform", type: "select", options: ["Instagram", "TikTok", "X / Twitter", "LinkedIn", "YouTube", "Pinterest"] },
      { name: "count", label: "Hashtag count", type: "select", options: ["10", "20", "30"] },
    ], "You are a social media strategist. Generate {{count}} high-relevance hashtags for {{platform}} based on the user's content description. Mix broad, niche and micro-community tags. Output as a ready-to-copy block."), featured: false, popular: false, isNew: true, sort: 15, dailyLimit: 30, cooldown: 10, maxPrompt: 300, maxDuration: 60, seoTitle: "", seoDesc: "Free AI hashtag generator for Instagram, TikTok and more. No signup." },
  ];
}

function seedPosts() {
  return [
    {
      title: "How to Write AI Video Prompts That Actually Look Cinematic (demo)",
      slug: "how-to-write-cinematic-ai-video-prompts",
      excerpt: "Demo article — replace or delete from Admin → Blog. The anatomy of a cinematic AI video prompt: camera, light, motion and mood.",
      category: "guides", tags: ["ai video", "prompting", "tutorial"], daysAgo: 2, reading: 6,
      content: `> **Demo article** — this is seeded demo content. Replace or delete it in **Admin → Blog**.

## Why most AI video prompts fall flat

A prompt like *"a cat in a city"* gives the model nothing to direct. Cinematic output needs a director's prompt.

## The 4-part anatomy

1. **Subject + action** — who or what, doing exactly what
2. **Camera** — "slow dolly-in", "handheld tracking", "aerial pull-back"
3. **Light + mood** — "golden hour backlight", "neon reflections after rain"
4. **Style anchor** — "shot on 35mm, shallow depth of field"

## A worked example

\`\`\`
A lone cyclist glides through a rain-slicked Tokyo alley at dusk, camera
tracking alongside at wheel height, neon signs reflecting in puddles,
shot on 35mm with shallow depth of field, moody teal-and-orange grade.
\`\`\`

## Try it yourself

Open the [AI Video Prompt Generator](/tools/ai-video-prompt-generator) and the [AI Video Generator](/tools/ai-video-generator) — both free, no signup.`,
      faq: [{ question: "Do I need an account to use these tools?", answer: "No — every tool on this site works without any signup." }],
    },
    {
      title: "10 Prompt Templates Every Creator Should Save (demo)",
      slug: "10-prompt-templates-every-creator-should-save",
      excerpt: "Demo article — reusable prompt patterns for blogs, thumbnails, captions and product copy.",
      category: "prompt-ideas", tags: ["prompts", "templates", "productivity"], daysAgo: 6, reading: 8,
      content: `> **Demo article** — replace or delete it in **Admin → Blog**.

Templates beat blank pages. Here are ten patterns worth saving:

1. **Role + task + constraint** — "You are X. Do Y. Keep it under Z."
2. **Audience framing** — always state who the output is for.
3. **Tone anchoring** — one adjective changes everything.
4. **Example seeding** — show one good example, ask for variations.
5. **Objection handling** — for sales copy, list objections to address.

…and five more in the [Prompt Generator](/tools/ai-prompt-generator), where you can generate and refine these live.`,
      faq: [],
    },
    {
      title: "Free AI Tools: What's Possible Without an Account in 2026 (demo)",
      slug: "free-ai-tools-without-an-account",
      excerpt: "Demo article — a tour of what you can create today with zero signup.",
      category: "news", tags: ["free ai", "tools"], daysAgo: 12, reading: 5,
      content: `> **Demo article** — replace or delete it in **Admin → Blog**.

The barrier to AI creation isn't the models — it's the signup walls around them. This platform takes a different approach:

- **Video** — text-to-video with style and aspect controls
- **Image** — multi-style image generation
- **Prompts** — expert prompts for any AI platform
- **Audio** — text-to-speech with voices and moods
- **Writing** — stories, scripts, blogs, captions, SEO copy

All free within daily fair-use limits. Start at the [AI Tools directory](/tools).`,
      faq: [],
    },
  ];
}
