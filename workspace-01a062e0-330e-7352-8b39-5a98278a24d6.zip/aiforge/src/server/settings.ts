import { getDb, get, run, nowIso } from "@/db";

/** Typed settings groups stored as JSON in site_settings. Defaults merge with saved values. */

export interface SiteSettings {
  siteName: string;
  tagline: string;
  description: string;
  logoUrl: string;
  faviconUrl: string;
  primaryColor: string;   // rgb triplet "109 94 252"
  secondaryColor: string; // rgb triplet "34 211 238"
  defaultTheme: "dark" | "light";
  footerDescription: string;
  copyright: string;
  contactEmail: string;
  socials: { twitter: string; youtube: string; github: string; linkedin: string; instagram: string; facebook: string };
}
export interface SeoSettings {
  titleTemplate: string; // "{title} | {siteName}"
  defaultDescription: string;
  defaultKeywords: string;
  defaultOgImage: string;
  twitterHandle: string;
  robotsDefault: string;
  noindexSearchPage: boolean;
}
export interface AdsSettings {
  enabled: boolean;
  publisherId: string;
  testMode: boolean;
  adRevenueMonthly: string;  // manual field for dashboard
  adNotesMonthly: string;
}
export interface AnalyticsSettings {
  gaEnabled: boolean;
  gaMeasurementId: string;
  gtmEnabled: boolean;
  gtmContainerId: string;
  searchConsoleVerification: string;
  requireConsent: boolean;
}
export interface SecuritySettings {
  loginMaxAttempts: number;
  loginWindowMinutes: number;
  sessionHours: number;
  globalDailyLimitPerIp: number;
  contactPerHour: number;
}
export interface SystemSettings {
  maintenanceOn: boolean;
  maintenanceMessage: string;
  seedVersion: number;
}
export interface UsageSettings {
  costPerGeneration: { video: number; image: number; text: number; audio: number };
}
export interface AudioSettings {
  languages: { code: string; label: string }[];
  voices: { id: string; label: string }[];
}
export interface PricingSettings {
  plans: { name: string; price: string; period: string; description: string; features: string[]; ctaLabel: string; ctaHref: string; highlight: boolean; enabled: boolean }[];
}

export interface SettingsMap {
  site: SiteSettings;
  seo: SeoSettings;
  ads: AdsSettings;
  analytics: AnalyticsSettings;
  security: SecuritySettings;
  system: SystemSettings;
  usage: UsageSettings;
  audio: AudioSettings;
  pricing: PricingSettings;
}

export const DEFAULT_SETTINGS: SettingsMap = {
  site: {
    siteName: "AIForge",
    tagline: "Free AI creation platform",
    description:
      "Generate videos, images, prompts, audio and written content with free AI tools. No account, no signup — just open a tool and create.",
    logoUrl: "",
    faviconUrl: "",
    primaryColor: "109 94 252",
    secondaryColor: "34 211 238",
    defaultTheme: "dark",
    footerDescription:
      "A free suite of AI creation tools. Generate video, images, prompts, audio and text content — no signup required.",
    copyright: "AIForge. All rights reserved.",
    contactEmail: "hello@example.com",
    socials: { twitter: "", youtube: "", github: "", linkedin: "", instagram: "", facebook: "" },
  },
  seo: {
    titleTemplate: "{title} | {siteName}",
    defaultDescription:
      "Free AI tools to generate videos, images, prompts, audio and text content. No signup required — create in seconds.",
    defaultKeywords: "ai tools, free ai, ai generator, ai video, ai image, ai prompt, ai audio",
    defaultOgImage: "/icons/og-default.jpg",
    twitterHandle: "",
    robotsDefault: "index,follow",
    noindexSearchPage: true,
  },
  ads: { enabled: false, publisherId: "", testMode: false, adRevenueMonthly: "", adNotesMonthly: "" },
  analytics: { gaEnabled: false, gaMeasurementId: "", gtmEnabled: false, gtmContainerId: "", searchConsoleVerification: "", requireConsent: true },
  security: { loginMaxAttempts: 5, loginWindowMinutes: 15, sessionHours: 12, globalDailyLimitPerIp: 80, contactPerHour: 5 },
  system: { maintenanceOn: false, maintenanceMessage: "We're upgrading the platform. Coming back soon — please check back in a little while.", seedVersion: 0 },
  usage: { costPerGeneration: { video: 0, image: 0, text: 0, audio: 0 } },
  audio: {
    languages: [
      { code: "en", label: "English" },
      { code: "es", label: "Spanish" },
      { code: "fr", label: "French" },
      { code: "de", label: "German" },
      { code: "hi", label: "Hindi" },
      { code: "bn", label: "Bengali" },
      { code: "ar", label: "Arabic" },
      { code: "ja", label: "Japanese" },
    ],
    voices: [
      { id: "alloy", label: "Alloy — neutral" },
      { id: "nova", label: "Nova — warm female" },
      { id: "echo", label: "Echo — calm male" },
      { id: "shimmer", label: "Shimmer — bright female" },
      { id: "onyx", label: "Onyx — deep male" },
    ],
  },
  pricing: {
    plans: [
      {
        name: "Free",
        price: "$0",
        period: "forever",
        description: "Everything you need to start creating with AI. No account required.",
        features: [
          "All AI tools included",
          "No signup or credit card",
          "Daily free generations",
          "Commercial-use friendly outputs",
          "New tools added regularly",
        ],
        ctaLabel: "Start Creating Free",
        ctaHref: "/tools",
        highlight: true,
        enabled: true,
      },
    ],
  },
};

export function getSettings<K extends keyof SettingsMap>(group: K): SettingsMap[K] {
  const db = getDb();
  const row = get(db, "SELECT value FROM site_settings WHERE key = ?", group);
  const saved = row ? safeParse(row.value) : {};
  return { ...(DEFAULT_SETTINGS[group] as any), ...saved } as SettingsMap[K];
}

export function getAllSettings(): SettingsMap {
  return {
    site: getSettings("site"),
    seo: getSettings("seo"),
    ads: getSettings("ads"),
    analytics: getSettings("analytics"),
    security: getSettings("security"),
    system: getSettings("system"),
    usage: getSettings("usage"),
    audio: getSettings("audio"),
    pricing: getSettings("pricing"),
  };
}

export function saveSettings<K extends keyof SettingsMap>(group: K, patch: Partial<SettingsMap[K]>) {
  const db = getDb();
  const current = getSettings(group);
  const merged = { ...current, ...patch };
  run(
    db,
    "INSERT INTO site_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
    group,
    JSON.stringify(merged)
  );
  return merged;
}

/** Resolve {{siteName}} style tokens + the "{title} | {siteName}" template. */
export function applyTitleTemplate(template: string, title: string, siteName: string) {
  return template.replace(/\{title\}/g, title).replace(/\{siteName\}/g, siteName).replace(/\{site\}/g, siteName);
}

function safeParse(s: string): any {
  try {
    return JSON.parse(s);
  } catch {
    return {};
  }
}

export function baseUrl(): string {
  return (process.env.PUBLIC_BASE_URL || getSettings("seo").defaultOgImage === "" ? process.env.PUBLIC_BASE_URL || "http://localhost:3000" : "http://localhost:3000");
}

export function touchUpdated(db: ReturnType<typeof getDb>, table: string, id: number | string) {
  run(db, `UPDATE ${table} SET updated_at = ? WHERE id = ?`, nowIso(), id);
}
