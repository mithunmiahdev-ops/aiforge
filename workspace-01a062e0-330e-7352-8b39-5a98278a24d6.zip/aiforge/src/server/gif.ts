/**
 * Minimal animated-GIF encoder (GIF89a + LZW), pure Node — no dependencies.
 * Used by the demo video provider so its output is a real, playable,
 * downloadable animated file (still clearly watermarked "DEMO").
 */

class ByteWriter {
  private buf = Buffer.alloc(256 * 1024);
  private len = 0;
  private grow() {
    const next = Buffer.alloc(Math.max(this.buf.length * 2, this.len + 4096));
    this.buf.copy(next, 0, 0, this.len);
    this.buf = next;
  }
  byte(b: number) { if (this.len >= this.buf.length) this.grow(); this.buf[this.len++] = b & 0xff; }
  bytes(bs: ArrayLike<number>) { for (let i = 0; i < bs.length; i++) this.byte(bs[i]); }
  short(v: number) { this.byte(v & 0xff); this.byte((v >> 8) & 0xff); }
  ascii(s: string) { for (let i = 0; i < s.length; i++) this.byte(s.charCodeAt(i)); }
  out() { return this.buf.subarray(0, this.len); }
}

class BitWriter {
  private bytes: number[] = [];
  private cur = 0;
  private nBits = 0;
  constructor(private out: ByteWriter) {}
  write(code: number, size: number) {
    this.cur |= (code << this.nBits) >>> 0;
    this.nBits += size;
    while (this.nBits >= 8) { this.bytes.push(this.cur & 0xff); this.cur = (this.cur >>> 8) >>> 0; this.nBits -= 8; }
  }
  /** pad, wrap into ≤255-byte sub-blocks + block terminator */
  end() {
    if (this.nBits > 0) { this.bytes.push(this.cur & 0xff); this.cur = 0; this.nBits = 0; }
    for (let i = 0; i < this.bytes.length; i += 255) {
      const n = Math.min(255, this.bytes.length - i);
      this.out.byte(n);
      for (let j = 0; j < n; j++) this.out.byte(this.bytes[i + j]);
    }
    this.out.byte(0);
    this.bytes = [];
  }
}

/** LZW image data for one frame of indexed pixels. */
function lzw(pixels: Uint8Array, minCodeSize: number, out: ByteWriter) {
  const clear = 1 << minCodeSize;
  const eoi = clear + 1;
  let codeSize = minCodeSize + 1;
  let next = eoi + 1;
  let dict = new Map<number, number>();
  const bw = new BitWriter(out);
  bw.write(clear, codeSize);
  if (pixels.length === 0) { bw.write(eoi, codeSize); bw.end(); return; }
  let prefix = pixels[0];
  for (let i = 1; i < pixels.length; i++) {
    const k = pixels[i];
    const key = ((prefix << 8) | k) >>> 0;
    const hit = dict.get(key);
    if (hit !== undefined) { prefix = hit; continue; }
    bw.write(prefix, codeSize);
    if (next < 4096) {
      // IMPORTANT: bump the code size BEFORE assigning, when next equals 2^codeSize —
      // the encoder's dictionary runs one entry ahead of the decoder's (omggif-compatible).
      if (next >= (1 << codeSize) && codeSize < 12) codeSize++;
      dict.set(key, next++);
    } else {
      bw.write(clear, codeSize);
      dict = new Map();
      codeSize = minCodeSize + 1;
      next = eoi + 1;
    }
    prefix = k;
  }
  bw.write(prefix, codeSize);
  bw.write(eoi, codeSize);
  bw.end();
}

/* ── 256-color palette: 216 web-safe + 32 grays + 8 brand accents ── */
function buildPalette(): [number, number, number][] {
  const pal: [number, number, number][] = [];
  for (let r = 0; r < 6; r++) for (let g = 0; g < 6; g++) for (let b = 0; b < 6; b++)
    pal.push([r * 51, g * 51, b * 51]);
  for (let i = 0; i < 32; i++) { const v = Math.round((i * 255) / 31); pal.push([v, v, v]); }
  pal.push([109, 94, 252], [77, 63, 214], [34, 211, 238], [20, 160, 190], [43, 30, 107], [16, 12, 40], [140, 130, 255], [120, 235, 255]);
  return pal;
}

const PALETTE = buildPalette();
const PALETTE_FLAT = Buffer.alloc(768);
PALETTE.forEach(([r, g, b], i) => { PALETTE_FLAT[i * 3] = r; PALETTE_FLAT[i * 3 + 1] = g; PALETTE_FLAT[i * 3 + 2] = b; });

/** nearest-palette lookup with memoization (quantized cache) */
const cache = new Int16Array(32768).fill(-1);
function nearest(r: number, g: number, b: number): number {
  const key = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
  const hit = cache[key];
  if (hit >= 0) return hit;
  let best = 0, bestD = Infinity;
  for (let i = 0; i < PALETTE.length; i++) {
    const [pr, pg, pb] = PALETTE[i];
    const dr = pr - r, dg = pg - g, db = pb - b;
    const d = dr * dr + dg * dg + db * db;
    if (d < bestD) { bestD = d; best = i; }
  }
  cache[key] = best;
  return best;
}

/* ── tiny 5×7 bitmap font for the DEMO watermark ── */
const FONT: Record<string, string[]> = {
  D: ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
  E: ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
  M: ["10001", "11011", "10101", "10001", "10001", "10001", "10001"],
  O: ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
};

/** Encode an animated GIF from raw RGB frames (Uint8Array rgb triples). */
export function encodeGif(frames: Uint8Array[], width: number, height: number, delayCs = 8): Buffer {
  const out = new ByteWriter();
  out.ascii("GIF89a");
  out.short(width);
  out.short(height);
  out.byte(0xf7); // global color table, 256 entries
  out.byte(0);
  out.byte(0);
  out.bytes(PALETTE_FLAT);
  // Netscape looping extension (infinite)
  out.bytes([0x21, 0xff, 0x0b]); out.ascii("NETSCAPE2.0"); out.bytes([0x03, 0x01, 0x00, 0x00, 0x00]);
  const indexed = Buffer.allocUnsafe(width * height);
  for (const rgb of frames) {
    for (let i = 0, p = 0; i < indexed.length; i++, p += 3) {
      indexed[i] = nearest(rgb[p], rgb[p + 1], rgb[p + 2]);
    }
    // graphic control: disposal=1 (leave in place), delay
    out.bytes([0x21, 0xf9, 0x04, 0x04]); out.short(delayCs); out.bytes([0x00, 0x00]);
    // image descriptor
    out.byte(0x2c); out.short(0); out.short(0); out.short(width); out.short(height); out.byte(0);
    out.byte(8); // LZW min code size (256-color)
    lzw(indexed, 8, out);
  }
  out.byte(0x3b);
  return out.out();
}

/**
 * Renders the watermarked demo "video": drifting gradient orbs on a dark
 * canvas with a moving shimmer and a DEMO tag. Deterministic per prompt.
 */
export function encodeDemoVideoGif(aspect: string, seedText = "", secondsHint = 0): Buffer {
  let [w, h] = aspect === "9:16" ? [288, 512] : aspect === "1:1" ? [384, 384] : [512, 288];
  const framesCount = 24;
  const delay = 8; // 80ms/frame ≈ 1.9s loop

  // seed orbs from the prompt text (deterministic)
  let seed = 2166136261;
  for (let i = 0; i < seedText.length; i++) { seed ^= seedText.charCodeAt(i); seed = Math.imul(seed, 16777619) >>> 0; }
  const rand = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
  const orbs = Array.from({ length: 3 }, (_, i) => ({
    cx: 0.2 + rand() * 0.6,
    cy: 0.2 + rand() * 0.6,
    r: (0.28 + rand() * 0.22) * Math.min(w, h),
    amp: 0.04 + rand() * 0.08,
    speed: 1 + rand() * 1.6,
    phase: rand() * Math.PI * 2,
    col: i === 0 ? [109, 94, 252] : i === 1 ? [34, 211, 238] : [217, 70, 239],
  }));

  const frames: Uint8Array[] = [];
  for (let f = 0; f < framesCount; f++) {
    const t = (f / framesCount) * Math.PI * 2;
    const rgb = new Uint8Array(w * h * 3);
    let p = 0;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let r = 16, g = 12, b = 40;
        for (const o of orbs) {
          const ox = (o.cx + Math.sin(t * o.speed + o.phase) * o.amp) * w;
          const oy = (o.cy + Math.cos(t * o.speed * 0.8 + o.phase) * o.amp) * h;
          const dx = x - ox, dy = y - oy;
          const d2 = (dx * dx + dy * dy) / (o.r * o.r);
          const fall = Math.exp(-d2 * 2.2);
          r += o.col[0] * fall * 0.75;
          g += o.col[1] * fall * 0.75;
          b += o.col[2] * fall * 0.75;
        }
        // moving diagonal shimmer
        if ((x + y + Math.floor(f * 6)) % 32 < 1) { r += 26; g += 26; b += 34; }
        // vignette
        const vx = x / w - 0.5, vy = y / h - 0.5;
        const vig = 1 - (vx * vx + vy * vy) * 0.9;
        rgb[p++] = Math.max(0, Math.min(255, r * vig));
        rgb[p++] = Math.max(0, Math.min(255, g * vig));
        rgb[p++] = Math.max(0, Math.min(255, b * vig));
      }
    }
    drawTag(rgb, w, 8, 8, "DEMO", 2);
    frames.push(rgb);
  }
  const gif = encodeGif(frames, w, h, delay);
  void secondsHint;
  return gif;
}

function drawTag(rgb: Uint8Array, w: number, ox: number, oy: number, text: string, scale: number) {
  let cx = ox;
  for (const ch of text) {
    const glyph = FONT[ch];
    if (!glyph) { cx += 6 * scale; continue; }
    for (let gy = 0; gy < glyph.length; gy++) {
      for (let gx = 0; gx < glyph[gy].length; gx++) {
        if (glyph[gy][gx] !== "1") continue;
        for (let sy = 0; sy < scale; sy++) {
          for (let sx = 0; sx < scale; sx++) {
            const px = cx + gx * scale + sx, py = oy + gy * scale + sy;
            const i = (py * w + px) * 3;
            rgb[i] = 235; rgb[i + 1] = 235; rgb[i + 2] = 240;
          }
        }
      }
    }
    cx += 6 * scale;
  }
}
