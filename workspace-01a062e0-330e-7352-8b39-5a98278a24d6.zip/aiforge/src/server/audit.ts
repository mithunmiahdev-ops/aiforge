import { getDb, run } from "@/db";

/** Central audit/system logger. `detail` must be public-safe (no secrets). */
export function logEvent(opts: {
  type: "admin_action" | "security" | "error" | "system";
  actor?: string;
  action: string;
  object?: string;
  detail?: Record<string, unknown>;
  ip?: string;
}) {
  try {
    const db = getDb();
    run(
      db,
      "INSERT INTO system_logs (type, actor, action, object, detail, ip) VALUES (?,?,?,?,?,?)",
      opts.type,
      opts.actor ?? "system",
      opts.action,
      opts.object ?? "",
      JSON.stringify(opts.detail ?? {}).slice(0, 2000),
      opts.ip ?? ""
    );
  } catch {
    // never let logging break a request
  }
}
