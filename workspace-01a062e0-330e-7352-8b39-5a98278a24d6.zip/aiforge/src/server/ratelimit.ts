import { getDb, get, run } from "@/db";

export interface RateResult {
  ok: boolean;
  /** seconds until the window resets (when !ok) */
  retryAfter: number;
  remaining: number;
}

/**
 * Fixed-window rate limiter backed by the database (survives restarts, works
 * across serverless instances when sharing a database).
 */
export function checkRate(key: string, limit: number, windowSeconds: number): RateResult {
  if (limit <= 0) return { ok: true, retryAfter: 0, remaining: Infinity };
  const db = getDb();
  const now = Date.now();
  const row = get<{ window_start: number; count: number }>(db, "SELECT window_start, count FROM rate_limits WHERE key = ?", key);
  if (!row || now - row.window_start >= windowSeconds * 1000) {
    run(db, "INSERT INTO rate_limits (key, window_start, count) VALUES (?,?,1) ON CONFLICT(key) DO UPDATE SET window_start=excluded.window_start, count=excluded.count", key, now);
    return { ok: true, retryAfter: 0, remaining: limit - 1 };
  }
  if (row.count < limit) {
    run(db, "UPDATE rate_limits SET count = count + 1 WHERE key = ?", key);
    return { ok: true, retryAfter: 0, remaining: limit - row.count - 1 };
  }
  const retryAfter = Math.max(1, Math.ceil((row.window_start + windowSeconds * 1000 - now) / 1000));
  return { ok: false, retryAfter, remaining: 0 };
}

/** Count of events inside a trailing window (used for login attempts analytics). */
export function windowCount(key: string, windowSeconds: number): number {
  const db = getDb();
  const row = get<{ window_start: number; count: number }>(db, "SELECT window_start, count FROM rate_limits WHERE key = ?", key);
  if (!row || Date.now() - row.window_start >= windowSeconds * 1000) return 0;
  return row.count;
}

export function resetKey(key: string) {
  const db = getDb();
  run(db, "DELETE FROM rate_limits WHERE key = ?", key);
}
