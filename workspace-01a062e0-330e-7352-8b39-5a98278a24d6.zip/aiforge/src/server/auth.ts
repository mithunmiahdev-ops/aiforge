import crypto from "node:crypto";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { getDb, get, run, nowIso } from "@/db";
import { randomToken, sha256, hashPassword, verifyPasswordHash } from "./crypto";
import { getSettings } from "./settings";

export const SESSION_COOKIE = "aiforge_admin_session";
export { hashPassword, verifyPasswordHash };

export interface AdminUser {
  id: number;
  email: string;
  name: string;
  role: string;
  permissions: string[];
  is_active: number;
}

/** Create a session row + set the secure cookie. Returns the raw token. */
export function createSession(userId: number, ip: string, userAgent: string): string {
  const db = getDb();
  const token = randomToken(32);
  const hours = getSettings("security").sessionHours || 12;
  const expires = new Date(Date.now() + hours * 3600_000).toISOString();
  run(
    db,
    "INSERT INTO admin_sessions (token_hash, user_id, expires_at, ip, user_agent) VALUES (?,?,?,?,?)",
    sha256(token), userId, expires, ip.slice(0, 60), userAgent.slice(0, 200)
  );
  const store = cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: hours * 3600,
  });
  return token;
}

export function destroySession() {
  const store = cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    const db = getDb();
    run(db, "DELETE FROM admin_sessions WHERE token_hash = ?", sha256(token));
  }
  store.delete(SESSION_COOKIE);
}

/** Resolve the current admin user from the session cookie (server-side only). */
export function getAdminUser(): AdminUser | null {
  const store = cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const db = getDb();
  const row = get<{ id: number; email: string; name: string; is_active: number; expires_at: string; role: string; permissions: string }>(
    db,
    `SELECT u.id, u.email, u.name, u.is_active, s.expires_at, r.name AS role, r.permissions
     FROM admin_sessions s
     JOIN admin_users u ON u.id = s.user_id
     JOIN admin_roles r ON r.id = u.role_id
     WHERE s.token_hash = ?`,
    sha256(token)
  );
  if (!row) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    run(db, "DELETE FROM admin_sessions WHERE id = ?", row.id);
    return null;
  }
  if (!row.is_active) return null;
  let permissions: string[] = [];
  try { permissions = JSON.parse(row.permissions); } catch {}
  return { id: row.id, email: row.email, name: row.name, role: row.role, permissions, is_active: row.is_active };
}

export function hasPermission(user: AdminUser | null, permission: string): boolean {
  if (!user) return false;
  return user.permissions.includes("*") || user.permissions.includes(permission);
}

/** Guard for admin pages. Redirects to login; optionally checks a permission. */
export function requireAdmin(permission?: string): AdminUser {
  const user = getAdminUser();
  if (!user) redirect("/admin/login");
  if (permission && !hasPermission(user, permission)) redirect("/admin?denied=1");
  return user;
}

/** Guard for admin server actions — throws instead of redirecting. */
export function assertAdmin(permission?: string): AdminUser {
  const user = getAdminUser();
  if (!user) throw new Error("UNAUTHORIZED");
  if (permission && !hasPermission(user, permission)) throw new Error("FORBIDDEN");
  return user;
}

export async function requestIp(): Promise<string> {
  const h = await headers();
  return (h.get("x-forwarded-for") || "").split(",")[0].trim() || h.get("x-real-ip") || "127.0.0.1";
}

export function purgeExpiredSessions() {
  const db = getDb();
  run(db, "DELETE FROM admin_sessions WHERE expires_at < ?", nowIso());
}
