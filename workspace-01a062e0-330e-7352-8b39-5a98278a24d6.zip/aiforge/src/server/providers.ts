import { getDb, get, all } from "@/db";
import { decryptSecret } from "./crypto";
import { saveBuffer } from "./storage";
/**
 * Modular AI provider layer.
 *
 * Flow: Visitor → Frontend → Secure backend (this layer) → AI provider → backend → visitor.
 * API keys live ONLY on the server (encrypted at rest) and are never returned to any client.
 *
 * Adapters:
 *  - "demo"        → built-in, clearly-watermarked placeholder output (no external calls)
 *  - "openai"      → any OpenAI-compatible REST API (chat completions / images / speech)
 *  - "custom-http" → POST {tool, params, prompt} to your endpoint; expects {url} or {text} or {b64, mime}
 */

export type Capability = "video" | "image" | "text" | "audio";

export interface ProviderRow {
  id: number;
  name: string;
  capability: Capability;
  type: string;
  endpoint: string;
  api_key_encrypted: string;
  model: string;
  enabled: number;
  priority: number;
  timeout_ms: number;
  max_requests: number;
  fallback_provider_id: number | null;
}

export interface GenerateInput {
  capability: Capability;
  toolName: string;
  systemPrompt: string;
  prompt: string;
  params: Record<string, unknown>;
}

export interface GenerateResult {
  kind: "text" | "image" | "audio" | "video";
  text?: string;
  url?: string;
  mime?: string;
  providerName: string;
  model: string;
}

export class ProviderError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

/** Resolve the ordered provider chain for a capability (priority asc), with fallbacks. */
export function resolveProviders(capability: Capability, preferredProviderId?: number | null): ProviderRow[] {
  const db = getDb();
  const enabled = all<ProviderRow>(db, "SELECT * FROM ai_providers WHERE capability = ? AND enabled = 1 ORDER BY priority ASC, id ASC", capability);
  if (preferredProviderId) {
    const preferred = enabled.find((p) => p.id === preferredProviderId);
    if (preferred) return [preferred, ...enabled.filter((p) => p.id !== preferredProviderId)];
  }
  return enabled;
}

export function providerConfigured(capability: Capability): boolean {
  return resolveProviders(capability).length > 0;
}

/** Public-safe provider status for the admin dashboard (never includes keys). */
export function providerStatus() {
  const db = getDb();
  const rows = all<ProviderRow & { has_key: number }>(
    db,
    "SELECT *, LENGTH(api_key_encrypted) > 0 AS has_key FROM ai_providers ORDER BY capability, priority"
  );
  return rows.map(({ api_key_encrypted, ...r }) => ({
    id: r.id, name: r.name, capability: r.capability, type: r.type, model: r.model,
    enabled: !!r.enabled, priority: r.priority, hasKey: !!r.has_key, timeout_ms: r.timeout_ms,
  }));
}

/** Run a generation against the provider chain, falling back on failure. */
export async function generateWithProviders(input: GenerateInput, preferredProviderId?: number | null): Promise<GenerateResult> {
  const chain = resolveProviders(input.capability, preferredProviderId);
  if (chain.length === 0) {
    throw new ProviderError("NOT_CONFIGURED", "AI service is not configured");
  }
  const attempted: string[] = [];
  let lastErr: unknown = null;
  for (const provider of chain) {
    try {
      return await runAdapter(provider, input);
    } catch (err) {
      lastErr = err;
      attempted.push(`${provider.name}:${err instanceof Error ? err.message : "error"}`);
      continue; // try next provider in chain
    }
  }
  if (lastErr instanceof ProviderError && lastErr.code === "NOT_CONFIGURED") throw lastErr;
  throw new ProviderError("PROVIDER_ERROR", `All configured providers failed (${attempted.length} attempted)`);
}

async function runAdapter(provider: ProviderRow, input: GenerateInput): Promise<GenerateResult> {
  // per-provider max_requests guard
  if (provider.max_requests > 0) {
    const db = getDb();
    const used = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM generation_jobs WHERE provider = ? AND status = 'completed'", provider.name);
    if ((used?.c ?? 0) >= provider.max_requests) throw new ProviderError("PROVIDER_LIMIT", "Provider request budget exhausted");
  }
  switch (provider.type) {
    case "demo": return demoAdapter(provider, input);
    case "openai": return openAiAdapter(provider, input);
    case "custom-http": return customHttpAdapter(provider, input);
    default: throw new ProviderError("PROVIDER_ERROR", `Unknown provider type "${provider.type}"`);
  }
}

/* ── OpenAI-compatible adapter ─────────────────────────────────────── */

async function openAiAdapter(p: ProviderRow, input: GenerateInput): Promise<GenerateResult> {
  const key = decryptSecret(p.api_key_encrypted);
  if (!key) throw new ProviderError("PROVIDER_ERROR", "Provider has no API key configured");
  const base = (p.endpoint || "https://api.openai.com/v1").replace(/\/$/, "");
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (key) headers.Authorization = `Bearer ${key}`;
  const timeout = AbortSignal.timeout(p.timeout_ms || 120000);

  if (input.capability === "text") {
    const body = {
      model: p.model || "gpt-4o-mini",
      messages: [
        ...(input.systemPrompt ? [{ role: "system", content: input.systemPrompt }] : []),
        { role: "user", content: input.prompt },
      ],
      temperature: 0.8,
    };
    const res = await fetch(`${base}/chat/completions`, { method: "POST", headers, body: JSON.stringify(body), signal: timeout });
    if (!res.ok) throw new ProviderError("PROVIDER_ERROR", `Provider HTTP ${res.status}`);
    const json: any = await res.json();
    const text = json?.choices?.[0]?.message?.content?.trim();
    if (!text) throw new ProviderError("PROVIDER_ERROR", "Empty completion");
    return { kind: "text", text, providerName: p.name, model: body.model };
  }

  if (input.capability === "image") {
    const n = Math.min(Number(input.params.count) || 1, 4);
    const size = aspectToSize(String(input.params.aspect || "1:1"));
    const style = String(input.params.negative ? `${input.prompt}. Avoid: ${input.params.negative}` : input.prompt);
    const body = { model: p.model || "dall-e-3", prompt: style.slice(0, 3800), n: p.model.includes("dall-e-3") ? 1 : n, size, response_format: "b64_json" };
    const res = await fetch(`${base}/images/generations`, { method: "POST", headers, body: JSON.stringify(body), signal: timeout });
    if (!res.ok) throw new ProviderError("PROVIDER_ERROR", `Provider HTTP ${res.status}`);
    const json: any = await res.json();
    const items: any[] = json?.data ?? [];
    if (!items.length) throw new ProviderError("PROVIDER_ERROR", "No images returned");
    const urls: string[] = [];
    for (let i = 0; i < Math.min(items.length, 4); i++) {
      const it = items[i];
      if (it.b64_json) urls.push(saveBuffer(Buffer.from(it.b64_json, "base64"), "png"));
      else if (it.url) urls.push(it.url);
    }
    if (!urls.length) throw new ProviderError("PROVIDER_ERROR", "No usable image data");
    return { kind: "image", url: urls[0], mime: "image/png", ...((urls.length > 1 || n > 1) ? { text: JSON.stringify(urls) } : {}), providerName: p.name, model: body.model } as GenerateResult;
  }

  if (input.capability === "audio") {
    const voice = String(input.params.voice || "alloy").toLowerCase();
    const body = { model: p.model || "tts-1", voice, input: input.prompt.slice(0, 4000), response_format: "mp3" };
    const res = await fetch(`${base}/audio/speech`, { method: "POST", headers, body: JSON.stringify(body), signal: timeout });
    if (!res.ok) throw new ProviderError("PROVIDER_ERROR", `Provider HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 100) throw new ProviderError("PROVIDER_ERROR", "Empty audio response");
    return { kind: "audio", url: saveBuffer(buf, "mp3"), mime: "audio/mpeg", providerName: p.name, model: body.model };
  }

  // video via custom endpoint contract
  return customHttpAdapter(p, input);
}

function aspectToSize(aspect: string): string {
  switch (aspect) {
    case "16:9": case "4:3": return "1792x1024";
    case "9:16": case "3:4": return "1024x1792";
    default: return "1024x1024";
  }
}

/* ── Custom HTTP adapter (any provider; documented contract) ───────── */

async function customHttpAdapter(p: ProviderRow, input: GenerateInput): Promise<GenerateResult> {
  if (!p.endpoint) throw new ProviderError("PROVIDER_ERROR", "Custom provider endpoint is not set");
  const key = decryptSecret(p.api_key_encrypted);
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (key) headers.Authorization = `Bearer ${key}`;
  const res = await fetch(p.endpoint, {
    method: "POST",
    headers,
    body: JSON.stringify({ tool: input.toolName, capability: input.capability, params: input.params, prompt: input.prompt, system: input.systemPrompt }),
    signal: AbortSignal.timeout(p.timeout_ms || 120000),
  });
  if (!res.ok) throw new ProviderError("PROVIDER_ERROR", `Provider HTTP ${res.status}`);
  const json: any = await res.json().catch(() => null);
  if (json?.url) {
    const mime = String(json.mime || (String(json.url).endsWith(".png") ? "image/png" : "video/mp4"));
    return { kind: mime.startsWith("video") ? "video" : mime.startsWith("audio") ? "audio" : "image", url: json.url, mime, providerName: p.name, model: p.model };
  }
  if (json?.b64) {
    const mime = String(json.mime || "application/octet-stream");
    const ext = mime.includes("png") ? "png" : mime.includes("webm") ? "webm" : mime.includes("mp4") ? "mp4" : mime.includes("mpeg") ? "mp3" : mime.includes("wav") ? "wav" : "bin";
    return { kind: mime.startsWith("video") ? "video" : mime.startsWith("audio") ? "audio" : "image", url: saveBuffer(Buffer.from(json.b64, "base64"), ext), mime, providerName: p.name, model: p.model };
  }
  if (json?.text) return { kind: "text", text: String(json.text), providerName: p.name, model: p.model };
  throw new ProviderError("PROVIDER_ERROR", "Provider response missing url/b64/text");
}

/* ── Demo adapter — honest, clearly-watermarked placeholders ────────── */

const DEMO_GRADIENTS: [string, string][] = [
  ["#2b1e6b", "#6d5efc"], ["#0e7490", "#22d3ee"], ["#4a1d96", "#ec4899"],
  ["#065f46", "#34d399"], ["#92400e", "#fbbf24"], ["#7f1d1d", "#f87171"],
];

async function demoAdapter(p: ProviderRow, input: GenerateInput): Promise<GenerateResult> {
  const note = "[DEMO OUTPUT — no real AI provider is connected. This placeholder was generated locally so you can test the full flow. Connect a real provider in Admin → AI Providers.]";
  await new Promise((r) => setTimeout(r, 1200 + Math.random() * 1800)); // simulate latency

  if (input.capability === "text") {
    const text = buildDemoText(input);
    return { kind: "text", text: `${note}\n\n${text}`, providerName: p.name, model: "demo" };
  }
  if (input.capability === "image") {
    const n = Math.min(Math.max(1, Number(input.params.count) || 1), 4);
    const urls = Array.from({ length: n }, (_, i) => saveBuffer(Buffer.from(demoImageSvg(input, i), "utf8"), "svg"));
    return {
      kind: "image", url: urls[0], mime: "image/svg+xml",
      ...(n > 1 ? { text: JSON.stringify(urls) } : {}),
      providerName: p.name, model: "demo",
    } as GenerateResult;
  }
  if (input.capability === "audio") {
    const requested = Number(input.params.duration) || 0;
    const estimated = Math.max(2, Math.round(input.prompt.length / 15));
    const seconds = Math.min(Math.max(requested || estimated, 2), 30);
    const wav = demoWav(seconds);
    return { kind: "audio", url: saveBuffer(wav, "wav"), mime: "audio/wav", providerName: p.name, model: "demo" };
  }
  // video demo: real animated GIF (playable + downloadable). Real providers return mp4/webm URLs.
  const { encodeDemoVideoGif } = await import("./gif");
  const gif = encodeDemoVideoGif(String(input.params.aspect || "16:9"), input.prompt, Number(input.params.duration) || 0);
  return { kind: "video", url: saveBuffer(gif, "gif"), mime: "image/gif", providerName: p.name, model: "demo" };
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function wrapWords(text: string, maxChars: number, maxLines: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    if ((cur + " " + w).trim().length > maxChars) { lines.push(cur.trim()); cur = w; if (lines.length >= maxLines) break; }
    else cur = (cur + " " + w).trim();
  }
  if (lines.length < maxLines && cur) lines.push(cur.trim());
  return lines;
}

function demoImageSvg(input: GenerateInput, variant = 0): string {
  const [w, h] = String(input.params.aspect || "1:1") === "16:9" ? [1024, 576] : String(input.params.aspect) === "9:16" ? [576, 1024] : [768, 768];
  const [c1, c2] = DEMO_GRADIENTS[variant % DEMO_GRADIENTS.length];
  const lines = wrapWords(input.prompt, 30, 4).map((l, i) =>
    `<text x="50" y="${h / 2 - 40 + i * 46}" font-family="Inter,system-ui,sans-serif" font-size="34" font-weight="600" fill="rgba(255,255,255,.92)">${esc(l)}</text>`).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset=".5" stop-color="${c2}"/><stop offset="1" stop-color="${c1}"/></linearGradient></defs>
<rect width="${w}" height="${h}" fill="url(#g)"/>
<circle cx="${w * 0.82}" cy="${h * 0.2}" r="${h * 0.3}" fill="rgba(255,255,255,.08)"/>
<circle cx="${w * 0.18}" cy="${h * 0.85}" r="${h * 0.35}" fill="rgba(0,0,0,.14)"/>
${lines}
<text x="50" y="${h - 44}" font-family="Inter,system-ui,sans-serif" font-size="22" fill="rgba(255,255,255,.75)">DEMO · AI IMAGE PLACEHOLDER · style: ${esc(String(input.params.preset || input.params.style || "any"))} · variant ${variant + 1}</text>
<g transform="rotate(-18 ${w / 2} ${h / 2})" opacity="0.06"><text x="${w / 2}" y="${h / 2 + 8}" text-anchor="middle" font-size="${Math.min(w, h) / 4}" font-weight="800" font-family="Inter,sans-serif" fill="#fff">DEMO</text></g>
</svg>`;
}

function demoVideoSvg(input: GenerateInput): string {
  const [w, h] = String(input.params.aspect || "16:9") === "9:16" ? [576, 1024] : String(input.params.aspect) === "1:1" ? [768, 768] : [1024, 576];
  const lines = wrapWords(input.prompt, 34, 3).map((l, i) =>
    `<text x="50" y="${h / 2 - 70 + i * 48}" font-family="Inter,system-ui,sans-serif" font-size="36" font-weight="600" fill="rgba(255,255,255,.94)">${esc(l)}</text>`).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#140f2e"/><stop offset="1" stop-color="#1d1445"/></linearGradient>
<linearGradient id="orb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6d5efc"/><stop offset="1" stop-color="#22d3ee"/></linearGradient>
</defs>
<style>
@keyframes drift1 { 0%,100% { transform: translate(0,0);} 50% { transform: translate(60px,30px);} }
@keyframes drift2 { 0%,100% { transform: translate(0,0);} 50% { transform: translate(-70px,-20px);} }
.o1 { animation: drift1 6s ease-in-out infinite; } .o2 { animation: drift2 8s ease-in-out infinite; }
</style>
<rect width="${w}" height="${h}" fill="url(#bg)"/>
<circle class="o1" cx="${w * 0.2}" cy="${h * 0.25}" r="${h * 0.28}" fill="url(#orb)" opacity="0.5"/>
<circle class="o2" cx="${w * 0.85}" cy="${h * 0.75}" r="${h * 0.33}" fill="url(#orb)" opacity="0.35"/>
<rect x="40" y="${h / 2 - 130}" width="${w - 80}" height="${lines ? 190 : 100}" rx="18" fill="rgba(0,0,0,.35)"/>
${lines}
<text x="50" y="${h - 60}" font-family="Inter,system-ui,sans-serif" font-size="24" fill="rgba(255,255,255,.8)">DEMO · ANIMATED PREVIEW · style: ${esc(String(input.params.style || "cinematic"))} · ${esc(String(input.params.duration || 5))}s</text>
</svg>`;
}

/** Simple WAV buffer: soft chord arpeggio with fade. Clearly a demo tone, not speech. */
function demoWav(seconds: number): Buffer {
  const rate = 22050;
  const n = Math.floor(rate * seconds);
  const data = Buffer.alloc(n * 2);
  const notes = [261.63, 329.63, 392.0, 523.25]; // C major
  for (let i = 0; i < n; i++) {
    const t = i / rate;
    const seg = Math.min(Math.floor(t / (seconds / notes.length)), notes.length - 1);
    const f = notes[seg];
    const env = Math.min(1, t * 4) * Math.max(0, 1 - t / seconds);
    const v = (Math.sin(2 * Math.PI * f * t) * 0.5 + Math.sin(2 * Math.PI * f * 2 * t) * 0.15) * env * 0.35;
    data.writeInt16LE(Math.round(v * 32767), i * 2);
  }
  const header = Buffer.alloc(44);
  header.write("RIFF", 0); header.writeUInt32LE(36 + data.length, 4); header.write("WAVE", 8);
  header.write("fmt ", 12); header.writeUInt32LE(16, 16); header.writeUInt16LE(1, 20); header.writeUInt16LE(1, 22);
  header.writeUInt32LE(rate, 24); header.writeUInt32LE(rate * 2, 28); header.writeUInt16LE(2, 32); header.writeUInt16LE(16, 34);
  header.write("data", 36); header.writeUInt32LE(data.length, 40);
  return Buffer.concat([header, data]);
}

/** Deterministic, honest text assembly used by the demo text provider. */
function buildDemoText(input: GenerateInput): string {
  const p = input.params as Record<string, string>;
  const mode = String(p.mode || "generate");
  const previous = String(p.previousOutput || "");

  // refine modes operate on the previous output
  if (previous && (mode === "shorten" || mode === "improve" || mode === "expand")) {
    const clean = previous.replace(/^\[DEMO OUTPUT[^\]]*\]\s*/i, "").trim();
    const sentences = clean.split(/(?<=[.!?])\s+/).filter((s) => s.trim().length > 2);
    if (mode === "shorten") {
      const kept = sentences.slice(0, Math.max(1, Math.ceil(sentences.length / 3))).join(" ");
      return `**Shortened version**\n\n${kept}${kept.endsWith(".") ? "" : "."}\n\n*(Demo refinement — connect a real provider for genuine shortening.)*`;
    }
    if (mode === "improve") {
      return `**Improved version**\n\n${sentences.slice(0, 4).join(" ")}\n\n**Why this is stronger**\n- Tightened wording and removed filler\n- Sharper, more specific phrasing\n- Clear next step at the end\n\n*(Demo refinement — connect a real provider for genuine improvements.)*`;
    }
    return `**Expanded version**\n\n${clean}\n\n**Additional angles to consider**\n- A concrete example or mini case study\n- A common mistake and how to avoid it\n- A short checklist the reader can act on\n\n*(Demo expansion — connect a real provider for genuine expansion.)*`;
  }

  const prompt = input.prompt.trim();
  if (input.systemPrompt.includes("prompt") || input.toolName.toLowerCase().includes("prompt")) {
    const platform = p.platform || "ChatGPT";
    const tone = p.tone || "professional";
    const audience = p.audience || "a general audience";
    const type = p.contentType || "content";
    const core = prompt || p.topic || "the topic";
    return `**Optimized ${type} prompt for ${platform}**

---
You are an expert ${type} creator. Produce ${type.toLowerCase()} about: "${core}".
Target audience: ${audience}. Tone: ${tone}. Length: ${p.length || "medium"}.
${p.instructions ? "Additional instructions: " + p.instructions : ""}

Requirements:
1. Open with a strong, specific angle — not a generic intro.
2. Structure the output with clear sections.
3. Keep language concrete; prefer examples over adjectives.
4. End with a clear next step for the reader.
---

*Generated deterministically by the demo provider so you can test the flow. Connect a real AI provider for genuinely model-written prompts.*`;
  }
  const fieldSummary = Object.entries(p).filter(([, v]) => v && typeof v === "string").map(([k, v]) => `- **${k}**: ${v}`).join("\n");
  return `**${input.toolName} — demo draft**

**Your input**
${fieldSummary || "(none)"}
**Idea:** ${prompt || "(no prompt provided)"}

A real AI provider would now write your ${input.toolName.toLowerCase().includes("story") ? "story" : "content"} here, using the system instructions configured for this tool in the admin panel. Connect one in **Admin → AI Providers** (any OpenAI-compatible API works, or use the custom HTTP adapter for other services).`;
}
