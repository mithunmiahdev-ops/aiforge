import { getDb, get, run } from "@/db";
import { uuid } from "./crypto";
import { generateWithProviders, ProviderError, GenerateResult } from "./providers";

/**
 * Generation job system. States: queued → processing → completed | failed | cancelled.
 * Jobs are created by POST /api/generate/[slug] and processed asynchronously
 * in-process. GET /api/jobs/[id] polls status (and self-heals stuck jobs).
 * For heavy production load, point a worker at the generation_jobs table instead —
 * the API contract stays identical (see README → Job queue).
 */

export interface JobRow {
  id: string;
  tool_id: number | null;
  tool_slug: string;
  tool_name: string;
  capability: string;
  anon_id: string;
  status: string;
  params: string;
  result: string;
  provider: string;
  model: string;
  error_code: string;
  error_message: string;
  internal_error: string;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export function createJob(opts: {
  toolId: number | null; toolSlug: string; toolName: string; capability: string;
  anonId: string; ip: string; params: Record<string, unknown>;
}): string {
  const db = getDb();
  const id = uuid();
  run(db, `INSERT INTO generation_jobs (id, tool_id, tool_slug, tool_name, capability, anon_id, ip, status, params)
    VALUES (?,?,?,?,?,?,?, 'queued', ?)`,
    id, opts.toolId, opts.toolSlug, opts.toolName, opts.capability, opts.anonId, opts.ip,
    JSON.stringify(opts.params).slice(0, 8000));
  return id;
}

/** Fire-and-forget processing. Errors are captured in the job row, never thrown to caller. */
export function processJobAsync(jobId: string) {
  void processJob(jobId).catch(async (err) => {
    try {
      const db = getDb();
      run(db, "UPDATE generation_jobs SET status='failed', error_code='INTERNAL', error_message=?, internal_error=?, completed_at=datetime('now') WHERE id=?",
        "Something went wrong. Please try again.", String(err).slice(0, 400), jobId);
    } catch {}
  });
}

export async function processJob(jobId: string): Promise<void> {
  const db = getDb();
  const job = get<JobRow & { system_prompt?: string; provider_id?: number | null }>(db,
    `SELECT j.*, t.config AS tool_config, t.provider_id FROM generation_jobs j LEFT JOIN tools t ON t.id = j.tool_id WHERE j.id = ?`, jobId);
  if (!job || job.status === "completed" || job.status === "cancelled") return;
  run(db, "UPDATE generation_jobs SET status='processing', started_at=datetime('now') WHERE id=?", jobId);

  let config: any = {};
  try { config = JSON.parse((job as any).tool_config || "{}"); } catch {}
  const params = JSON.parse(job.params || "{}");
  const prompt = String(params.prompt || "");
  const systemPrompt = String(config.systemPrompt || "").replace(/\{\{(\w+)\}\}/g, (_, k) => String(params[k] ?? ""));

  try {
    const result: GenerateResult = await generateWithProviders(
      { capability: job.capability as any, toolName: job.tool_name, systemPrompt, prompt, params },
      (job as any).provider_id ?? null
    );
    // multi-image support: adapter may smuggle extra urls in result.text as JSON
    let resultPayload: any = { kind: result.kind, text: result.text, url: result.url, mime: result.mime };
    if (result.kind === "image" && result.text && result.text.startsWith("[") && result.text.endsWith("]")) {
      try { resultPayload.images = JSON.parse(result.text); } catch {}
      resultPayload.text = undefined;
    }
    run(db, "UPDATE generation_jobs SET status='completed', result=?, provider=?, model=?, completed_at=datetime('now') WHERE id=?",
      JSON.stringify(resultPayload).slice(0, 100_000), result.providerName, result.model, jobId);
  } catch (err) {
    let code = "PROVIDER_ERROR";
    let publicMsg = "Generation is temporarily unavailable. Please try again in a moment.";
    if (err instanceof ProviderError) {
      code = err.code;
      if (code === "NOT_CONFIGURED") publicMsg = "AI service is not configured yet. The site administrator needs to connect an AI provider — your prompt has been kept safe below.";
      if (code === "PROVIDER_LIMIT") publicMsg = "Generation is temporarily unavailable. Please try again later.";
    } else if (err instanceof Error && err.name === "TimeoutError") {
      code = "TIMEOUT";
      publicMsg = "The AI service took too long to respond. Please try again.";
    }
    run(db, "UPDATE generation_jobs SET status='failed', error_code=?, error_message=?, internal_error=?, completed_at=datetime('now') WHERE id=?",
      code, publicMsg, String(err).slice(0, 400), jobId);
    const { logEvent } = await import("./audit");
    logEvent({ type: "error", action: "generation.failed", object: `${job.tool_slug}:${jobId}`, detail: { code } });
  }
}

/** Public-safe job view (never leaks internal_error / ip / anon rows). */
export function publicJob(job: JobRow, anonId: string) {
  if (job.anon_id !== anonId) return null;
  let result: any = null;
  try { result = job.result ? JSON.parse(job.result) : null; } catch {}
  return {
    id: job.id,
    tool: job.tool_slug,
    status: job.status as "queued" | "processing" | "completed" | "failed" | "cancelled",
    result,
    error: job.status === "failed" ? { code: job.error_code, message: job.error_message } : null,
    createdAt: job.created_at,
    completedAt: job.completed_at,
  };
}

/** Requeue jobs stuck in queued/processing for > 5 minutes (e.g., server restart). */
export function healStuckJobs() {
  try {
    const db = getDb();
    const rows = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM generation_jobs WHERE status IN ('queued','processing') AND created_at < datetime('now','-5 minutes')");
    if ((rows?.c ?? 0) > 0) {
      run(db, "UPDATE generation_jobs SET status='failed', error_code='TIMEOUT', error_message='Generation is temporarily unavailable. Please try again.', completed_at=datetime('now') WHERE status IN ('queued','processing') AND created_at < datetime('now','-5 minutes')");
    }
  } catch {}
}
