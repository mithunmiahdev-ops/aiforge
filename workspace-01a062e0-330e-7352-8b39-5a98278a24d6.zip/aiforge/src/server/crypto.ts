import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { DATA_DIR } from "@/db";

/**
 * APP_SECRET is used for (a) AES-256-GCM encryption of AI provider API keys at rest
 * and (b) hashing admin session tokens. In production set the APP_SECRET env var.
 * For local dev we persist a generated secret to data/.app-secret so restarts don't
 * invalidate encrypted keys. Format: env var wins; hex string is used directly.
 */
let cachedKey: Buffer | null = null;
export function getAppSecret(): Buffer {
  if (cachedKey) return cachedKey;
  const env = process.env.APP_SECRET;
  if (env && /^[0-9a-f]{64}$/i.test(env)) {
    cachedKey = Buffer.from(env, "hex");
    return cachedKey;
  }
  if (env && env.length >= 32) {
    cachedKey = crypto.createHash("sha256").update(env).digest();
    return cachedKey;
  }
  const file = path.join(DATA_DIR, ".app-secret");
  try {
    const existing = fs.readFileSync(file, "utf8").trim();
    if (/^[0-9a-f]{64}$/i.test(existing)) {
      cachedKey = Buffer.from(existing, "hex");
      return cachedKey;
    }
  } catch {}
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const generated = crypto.randomBytes(32).toString("hex");
  fs.writeFileSync(file, generated, { mode: 0o600 });
  cachedKey = Buffer.from(generated, "hex");
  return cachedKey;
}

/** Encrypt a secret string for storage. Output: v1:<iv>:<tag>:<ciphertext> (base64 parts). */
export function encryptSecret(plain: string): string {
  if (!plain) return "";
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getAppSecret(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

/** Decrypt a value produced by encryptSecret. Returns "" if it cannot be decrypted. */
export function decryptSecret(stored: string): string {
  if (!stored) return "";
  try {
    const [v, ivB64, tagB64, dataB64] = stored.split(":");
    if (v !== "v1") return "";
    const decipher = crypto.createDecipheriv("aes-256-gcm", getAppSecret(), Buffer.from(ivB64, "base64"));
    decipher.setAuthTag(Buffer.from(tagB64, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(dataB64, "base64")), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

export const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString("base64url");
export const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
export const uuid = () => crypto.randomUUID();

/** scrypt password hashing — salt$hash, timing-safe verification. Lives here (pure node)
 *  so the DB seed can use it without importing next/headers. */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}$${hash}`;
}
export function verifyPasswordHash(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split("$");
    const candidate = crypto.scryptSync(password, salt, 64);
    return crypto.timingSafeEqual(candidate, Buffer.from(hash, "hex"));
  } catch {
    return false;
  }
}
