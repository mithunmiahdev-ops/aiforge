import { getDb, get, all, likeEscape } from "@/db";
import { getSettings } from "./settings";

/* Public-site data access. All queries are parameterized (SQL-injection safe). */

export interface ToolRow {
  id: number; name: string; slug: string; tagline: string; description: string;
  category_id: number | null; icon: string; type: string; capability: string; config: string;
  provider_id: number | null; is_featured: number; is_popular: number; is_new: number;
  enabled: number; sort: number; daily_limit: number; cooldown_seconds: number;
  max_prompt_chars: number; max_duration_seconds: number; seo_title: string;
  seo_description: string; noindex: number; created_at: string;
}
export interface CategoryRow { id: number; name: string; slug: string; description: string; icon: string; sort: number }
export interface NavRow { id: number; location: string; parent_id: number | null; footer_group: string; label: string; url: string; sort: number; enabled: number; is_button: number; button_style: string }

export function parseToolConfig(tool: ToolRow): any {
  try { return JSON.parse(tool.config || "{}"); } catch { return {}; }
}

export function getTools(onlyEnabled = true): (ToolRow & { category_name?: string | null; category_slug?: string | null })[] {
  const db = getDb();
  const rows = all<ToolRow & { category_name: string | null; category_slug: string | null }>(
    db,
    `SELECT t.*, c.name AS category_name, c.slug AS category_slug FROM tools t
     LEFT JOIN tool_categories c ON c.id = t.category_id
     ${onlyEnabled ? "WHERE t.enabled = 1" : ""}
     ORDER BY t.sort ASC, t.name ASC`
  );
  return rows;
}

export function getToolBySlug(slug: string): (ToolRow & { category_name: string | null; category_slug: string | null }) | null {
  const db = getDb();
  return get(db, `SELECT t.*, c.name AS category_name, c.slug AS category_slug FROM tools t
    LEFT JOIN tool_categories c ON c.id = t.category_id WHERE t.slug = ? AND t.enabled = 1`, slug);
}

export function getCategories(): CategoryRow[] {
  return all(getDb(), "SELECT * FROM tool_categories ORDER BY sort, name");
}

export function getNavigation(location: string) {
  return all<NavRow>(getDb(), "SELECT * FROM navigation_items WHERE location = ? AND enabled = 1 ORDER BY sort, id", location);
}

export function getHomepageSections(onlyEnabled = true) {
  return all<{ id: number; key: string; type: string; title: string; subtitle: string; content: string; enabled: number; sort: number }>(
    getDb(), `SELECT * FROM homepage_sections ${onlyEnabled ? "WHERE enabled = 1" : ""} ORDER BY sort, id`
  );
}

export function getFaqs(section: string) {
  return all<{ id: number; question: string; answer: string }>(
    getDb(), "SELECT id, question, answer FROM faqs WHERE section = ? AND enabled = 1 ORDER BY sort, id", section
  );
}

export function getPublishedPosts(opts: { categorySlug?: string; q?: string; page?: number; perPage?: number; featuredFirst?: boolean } = {}) {
  const db = getDb();
  const page = Math.max(1, opts.page ?? 1);
  const perPage = opts.perPage ?? 9;
  const where: string[] = ["p.status = 'published'", "COALESCE(p.publish_at, p.published_at, p.created_at, '9999') <= datetime('now')"];
  const args: any[] = [];
  if (opts.categorySlug) { where.push("c.slug = ?"); args.push(opts.categorySlug); }
  if (opts.q) {
    where.push("(p.title LIKE ? ESCAPE '\\' OR p.excerpt LIKE ? ESCAPE '\\' OR p.tags LIKE ? ESCAPE '\\')");
    const like = `%${likeEscape(opts.q)}%`;
    args.push(like, like, like);
  }
  const whereSql = where.join(" AND ");
  const total = (get<{ c: number }>(db, `SELECT COUNT(*) AS c FROM blog_posts p LEFT JOIN blog_categories c ON c.id = p.category_id WHERE ${whereSql}`, ...args)?.c) ?? 0;
  const rows = all<any>(
    db,
    `SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM blog_posts p
     LEFT JOIN blog_categories c ON c.id = p.category_id
     WHERE ${whereSql}
     ORDER BY ${opts.featuredFirst ? "(p.featured_image != '') DESC," : ""} COALESCE(p.publish_at, p.created_at) DESC
     LIMIT ? OFFSET ?`,
    ...args, perPage, (page - 1) * perPage
  );
  return { rows, total, page, perPage, pages: Math.max(1, Math.ceil(total / perPage)) };
}

export function getPostBySlug(slug: string) {
  return get<any>(getDb(), `SELECT p.*, c.name AS category_name, c.slug AS category_slug FROM blog_posts p
    LEFT JOIN blog_categories c ON c.id = p.category_id
    WHERE p.slug = ? AND p.status = 'published' AND COALESCE(p.publish_at, p.published_at, p.created_at, '9999') <= datetime('now')`, slug);
}

export function getRelatedPosts(post: any, limit = 3) {
  const db = getDb();
  return all<any>(db, `SELECT p.id, p.title, p.slug, p.excerpt, p.featured_image, p.reading_minutes, p.published_at
    FROM blog_posts p LEFT JOIN blog_categories c ON c.id = p.category_id
    WHERE p.status='published' AND COALESCE(p.publish_at, p.published_at, p.created_at, '9999') <= datetime('now') AND p.id != ?
      ${post.category_id ? "AND p.category_id = ?" : ""}
    ORDER BY COALESCE(p.publish_at, p.created_at) DESC LIMIT ?`,
    ...(post.category_id ? [post.id, post.category_id, limit] : [post.id, limit]));
}

export function getBlogCategories() {
  return all<any>(getDb(), `SELECT c.*, (SELECT COUNT(*) FROM blog_posts p WHERE p.category_id = c.id AND p.status='published' AND COALESCE(p.publish_at, p.published_at, p.created_at, '9999') <= datetime('now')) AS post_count FROM blog_categories c ORDER BY c.name`);
}

export function getPromptTemplates() {
  return all<{ id: number; name: string; description: string; platform: string; content: string }>(
    getDb(), "SELECT id, name, description, platform, content FROM prompt_templates WHERE enabled = 1 ORDER BY sort, id"
  );
}

export function getPageBySlug(slug: string) {
  return get<{ id: number; slug: string; title: string; content: string; seo_title: string; meta_description: string; noindex: number; enabled: number; updated_at: string }>(
    getDb(), "SELECT * FROM pages WHERE slug = ? AND enabled = 1", slug
  );
}

export interface SearchHit { type: "tool" | "blog" | "category" | "template" | "page"; title: string; url: string; description: string }

export function searchAll(q: string, limitPerType = 5): SearchHit[] {
  const db = getDb();
  const like = `%${likeEscape(q)}%`;
  const hits: SearchHit[] = [];
  for (const t of all<any>(db, "SELECT name, slug, tagline FROM tools WHERE enabled = 1 AND (name LIKE ? ESCAPE '\\' OR tagline LIKE ? ESCAPE '\\') LIMIT ?", like, like, limitPerType))
    hits.push({ type: "tool", title: t.name, url: `/tools/${t.slug}`, description: t.tagline });
  for (const p of all<any>(db, "SELECT title, slug, excerpt FROM blog_posts WHERE status='published' AND COALESCE(publish_at,'9999') <= datetime('now') AND (title LIKE ? ESCAPE '\\' OR excerpt LIKE ? ESCAPE '\\') LIMIT ?", like, like, limitPerType))
    hits.push({ type: "blog", title: p.title, url: `/blog/${p.slug}`, description: p.excerpt });
  for (const c of all<any>(db, "SELECT name, slug, description FROM tool_categories WHERE name LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\' LIMIT ?", like, like, limitPerType))
    hits.push({ type: "category", title: `${c.name} tools`, url: `/tools?category=${c.slug}`, description: c.description });
  for (const t of all<any>(db, "SELECT name, platform, description FROM prompt_templates WHERE enabled = 1 AND (name LIKE ? ESCAPE '\\' OR content LIKE ? ESCAPE '\\') LIMIT ?", like, like, limitPerType))
    hits.push({ type: "template", title: `${t.name} (${t.platform})`, url: "/tools/ai-prompt-generator", description: t.description });
  for (const p of all<any>(db, "SELECT title, slug FROM pages WHERE enabled = 1 AND title LIKE ? ESCAPE '\\' LIMIT ?", like, limitPerType))
    hits.push({ type: "page", title: p.title, url: `/${p.slug}`, description: "" });
  return hits;
}

export function siteName() {
  return getSettings("site").siteName;
}
