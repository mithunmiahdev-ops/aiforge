import fs from "node:fs";
import path from "node:path";
import { STORAGE_DIR } from "@/db";
import { uuid } from "./crypto";

/** Local storage abstraction. Swap `saveBuffer`/`readFile` for S3 calls in production
 *  (see README → Storage). Paths returned are public URLs served by /api/media. */

const SUBDIRS: Record<string, string> = { uploads: "uploads", generated: "generated" };

export function saveBuffer(buf: Buffer, ext: string, subdir: keyof typeof SUBDIRS = "generated"): string {
  const dir = path.join(STORAGE_DIR, SUBDIRS[subdir]);
  fs.mkdirSync(dir, { recursive: true });
  const safeExt = ext.replace(/[^a-z0-9]/gi, "").slice(0, 5) || "bin";
  const filename = `${uuid()}.${safeExt}`;
  fs.writeFileSync(path.join(dir, filename), buf);
  return `/api/media/${SUBDIRS[subdir]}/${filename}`;
}

export function readStoredFile(subdir: string, filename: string): Buffer | null {
  if (!/^[a-zA-Z0-9-]+\.[a-z0-9]{1,5}$/.test(filename) || !SUBDIRS[subdir]) return null;
  const full = path.join(STORAGE_DIR, subdir, filename);
  if (!full.startsWith(path.join(STORAGE_DIR))) return null; // traversal guard
  try {
    return fs.readFileSync(full);
  } catch {
    return null;
  }
}

export function deleteStoredFile(url: string) {
  try {
    const m = url.match(/^\/api\/media\/(uploads|generated)\/([a-zA-Z0-9-.]+)$/);
    if (!m) return;
    const full = path.join(STORAGE_DIR, m[1], m[2]);
    if (full.startsWith(STORAGE_DIR)) fs.unlinkSync(full);
  } catch {}
}

const MIME: Record<string, string> = {
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp",
  gif: "image/gif", svg: "image/svg+xml", mp3: "audio/mpeg", wav: "audio/wav",
  ogg: "audio/ogg", mp4: "video/mp4", webm: "video/webm", txt: "text/plain; charset=utf-8",
};
export const mimeFor = (ext: string) => MIME[ext.toLowerCase()] ?? "application/octet-stream";

export function storageStats() {
  let files = 0, bytes = 0;
  for (const sub of Object.values(SUBDIRS)) {
    const dir = path.join(STORAGE_DIR, sub);
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir)) {
      try { files++; bytes += fs.statSync(path.join(dir, f)).size; } catch {}
    }
  }
  return { files, bytes };
}
