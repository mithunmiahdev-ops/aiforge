import { getDb, all } from "@/db";
import { encryptSecret, hashPassword } from "@/server/crypto";

/* NOTE: resource defs include server-only transform functions. When passing a def
   to a client component, strip them (see `clientDef`). Actions look the full
   definition back up server-side by key, so transforms never cross the wire. */

export function clientDef(def: ResourceDef) {
  const { transform, deletable, ...rest } = def as any;
  return { ...rest, hasTransform: !!transform, systemLocked: false };
}

/* Generic resource registry: powers admin CRUD with allow-listed columns,
   server-side validation and permission checks. UI + validation share these defs. */

export type FieldType = "text" | "textarea" | "md" | "number" | "select" | "boolean" | "json" | "password" | "color";

export interface FieldDef {
  name: string;
  label: string;
  type: FieldType;
  options?: { value: string; label: string }[];
  required?: boolean;
  placeholder?: string;
  hint?: string;
  min?: number;
  max?: number;
  inTable?: boolean;   // show in the list table (default true for first few)
  half?: boolean;      // half-width in form grid
  optional?: boolean;  // select with empty option
}

export interface ResourceDef {
  key: string;
  table: string;
  label: string;
  singular: string;
  permission: string;
  fields: FieldDef[];
  orderBy: string;
  searchCols: string[];
  /** server-side transform applied after validation (encrypt keys, hash passwords…) */
  transform?: (values: Record<string, any>, existing: Record<string, any> | null) => Record<string, any> | Promise<Record<string, any>>;
  deletable?: (row: Record<string, any>) => boolean;
}

const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 80);

export function getResources(): Record<string, ResourceDef> {
  const db = getDb();
  const cats = all<{ id: number; name: string }>(db, "SELECT id, name FROM tool_categories ORDER BY name").map((c) => ({ value: String(c.id), label: c.name }));
  const providers = all<{ id: number; name: string; capability: string }>(db, "SELECT id, name, capability FROM ai_providers ORDER BY name").map((p) => ({ value: String(p.id), label: `${p.name} (${p.capability})` }));
  const roles = all<{ id: number; name: string }>(db, "SELECT id, name FROM admin_roles ORDER BY id").map((r) => ({ value: String(r.id), label: r.name }));
  const navParents = all<{ id: number; label: string }>(db, "SELECT id, label FROM navigation_items WHERE location='header' AND parent_id IS NULL ORDER BY sort").map((n) => ({ value: String(n.id), label: `${n.label} (dropdown)` }));

  return {
    tools: {
      key: "tools", table: "tools", label: "AI Tools", singular: "Tool", permission: "tools.manage",
      orderBy: "sort, name", searchCols: ["name", "slug", "tagline"],
      fields: [
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "slug", label: "Slug", type: "text", required: true, hint: "URL: /tools/<slug>", placeholder: "ai-emoji-generator", inTable: true },
        { name: "tagline", label: "Tagline", type: "text", inTable: true },
        { name: "description", label: "Description (markdown)", type: "md", hint: "Shown on the tool page below the generator" },
        { name: "category_id", label: "Category", type: "select", options: cats, optional: true, inTable: true, half: true },
        { name: "icon", label: "Icon", type: "select", options: ICON_OPTIONS, half: true },
        { name: "type", label: "Tool type (UI)", type: "select", options: [
          { value: "video", label: "Video generator UI" }, { value: "image", label: "Image generator UI" },
          { value: "prompt", label: "Prompt generator UI" }, { value: "audio", label: "Audio generator UI" },
          { value: "text", label: "Schema-driven form (fields in config)" },
        ], half: true, hint: "Determines the generator interface" },
        { name: "capability", label: "AI capability", type: "select", options: [
          { value: "video", label: "video" }, { value: "image", label: "image" }, { value: "text", label: "text" }, { value: "audio", label: "audio / TTS" },
        ], half: true },
        { name: "provider_id", label: "Preferred provider", type: "select", options: providers, optional: true, half: true, hint: "Empty = use priority chain for the capability" },
        { name: "config", label: "Config (JSON)", type: "json", half: false, hint: 'video: {styles,aspects,durations,qualities} · image: {presets,aspects,qualities,maxImages} · prompt: {platforms,contentTypes,tones,lengths} · audio: {moods,defaultDuration} · text: {systemPrompt, fields:[{name,label,type,options}]}' },
        { name: "is_featured", label: "Featured", type: "boolean", half: true, inTable: true },
        { name: "is_popular", label: "Popular", type: "boolean", half: true, inTable: true },
        { name: "is_new", label: "Show “New” badge", type: "boolean", half: true },
        { name: "enabled", label: "Enabled", type: "boolean", half: true, inTable: true },
        { name: "sort", label: "Sort order", type: "number", half: true, min: 0 },
        { name: "daily_limit", label: "Daily generations (per visitor)", type: "number", half: true, min: 1, inTable: true },
        { name: "cooldown_seconds", label: "Cooldown between generations (s)", type: "number", half: true, min: 0 },
        { name: "max_prompt_chars", label: "Max prompt characters", type: "number", half: true, min: 50 },
        { name: "max_duration_seconds", label: "Max duration (s, video/audio)", type: "number", half: true, min: 5 },
        { name: "seo_title", label: "SEO title", type: "text", half: true },
        { name: "seo_description", label: "SEO description", type: "textarea" },
        { name: "noindex", label: "noindex (hide from search engines)", type: "boolean", half: true },
      ],
      transform: (v) => ({ ...v, slug: slugify(v.slug || v.name), updated_at: new Date().toISOString() }),
    },

    categories: {
      key: "categories", table: "tool_categories", label: "Tool Categories", singular: "Category", permission: "tools.manage",
      orderBy: "sort, name", searchCols: ["name", "slug"],
      fields: [
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "slug", label: "Slug", type: "text", required: true, inTable: true },
        { name: "description", label: "Description", type: "textarea", inTable: true },
        { name: "icon", label: "Icon", type: "select", options: ICON_OPTIONS },
        { name: "sort", label: "Sort order", type: "number", half: true, min: 0 },
        { name: "seo_title", label: "SEO title", type: "text", half: true },
        { name: "seo_description", label: "SEO description", type: "textarea" },
      ],
      transform: (v) => ({ ...v, slug: slugify(v.slug || v.name) }),
      deletable: (row) => String(row.id) !== "1",
    },

    navigation: {
      key: "navigation", table: "navigation_items", label: "Navigation", singular: "Menu item", permission: "content.manage",
      orderBy: "location, sort, id", searchCols: ["label", "url"],
      fields: [
        { name: "label", label: "Label", type: "text", required: true, inTable: true },
        { name: "url", label: "URL", type: "text", required: true, inTable: true, placeholder: "/tools or https://…" },
        { name: "location", label: "Location", type: "select", options: [
          { value: "header", label: "Header menu" }, { value: "header_cta", label: "Header CTA buttons" }, { value: "footer", label: "Footer column" },
        ], inTable: true, half: true },
        { name: "parent_id", label: "Dropdown parent (header only)", type: "select", options: navParents, optional: true, half: true },
        { name: "footer_group", label: "Footer column name", type: "text", half: true, hint: "e.g. AI Tools / Legal — groups footer items" },
        { name: "sort", label: "Sort order", type: "number", half: true },
        { name: "is_button", label: "Style as button (CTA)", type: "boolean", half: true },
        { name: "button_style", label: "Button style", type: "select", options: [{ value: "primary", label: "Primary" }, { value: "ghost", label: "Ghost / subtle" }], half: true },
        { name: "enabled", label: "Enabled", type: "boolean", half: true, inTable: true },
      ],
    },

    homepage_sections: {
      key: "homepage_sections", table: "homepage_sections", label: "Homepage Sections", singular: "Section", permission: "content.manage",
      orderBy: "sort, id", searchCols: ["key", "title"],
      fields: [
        { name: "key", label: "Key (unique)", type: "text", required: true, inTable: true },
        { name: "type", label: "Type", type: "select", options: ["hero", "categories", "popular_tools", "featured_tools", "how_it_works", "why_us", "blog_latest", "faq", "cta", "stats"].map((t) => ({ value: t, label: t })), inTable: true, half: true },
        { name: "sort", label: "Order on page", type: "number", half: true, inTable: true },
        { name: "title", label: "Title", type: "text", inTable: true },
        { name: "subtitle", label: "Subtitle", type: "textarea" },
        { name: "content", label: "Content (JSON)", type: "json", hint: 'hero: {badge,headline,subheadline,ctaPrimaryLabel,ctaPrimaryHref,ctaSecondaryLabel,ctaSecondaryHref} · how_it_works: {steps:[{title,desc,icon}]} · why_us: {items:[…]} · cta: {title,sub,ctaLabel,ctaHref} · stats: {items:[{value,label}]}' },
        { name: "enabled", label: "Enabled", type: "boolean", inTable: true },
      ],
    },

    faqs: {
      key: "faqs", table: "faqs", label: "FAQs", singular: "FAQ", permission: "content.manage",
      orderBy: "section, sort, id", searchCols: ["question", "answer"],
      fields: [
        { name: "question", label: "Question", type: "text", required: true, inTable: true },
        { name: "answer", label: "Answer", type: "textarea", required: true },
        { name: "section", label: "Section", type: "text", required: true, inTable: true, hint: "home · general · a tool slug (e.g. ai-video-generator)" },
        { name: "sort", label: "Sort", type: "number", half: true },
        { name: "enabled", label: "Enabled", type: "boolean", half: true, inTable: true },
      ],
    },

    prompt_templates: {
      key: "prompt_templates", table: "prompt_templates", label: "Prompt Templates", singular: "Template", permission: "templates.manage",
      orderBy: "sort, id", searchCols: ["name", "platform", "content"],
      fields: [
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "platform", label: "Platform", type: "text", inTable: true, half: true },
        { name: "sort", label: "Sort", type: "number", half: true },
        { name: "description", label: "Description", type: "textarea", inTable: true },
        { name: "content", label: "Template", type: "md", required: true, hint: "Supports {{topic}}, {{audience}}, {{tone}}… placeholders" },
        { name: "enabled", label: "Enabled", type: "boolean", inTable: true },
      ],
    },

    providers: {
      key: "providers", table: "ai_providers", label: "AI Providers", singular: "Provider", permission: "providers.manage",
      orderBy: "capability, priority", searchCols: ["name", "model", "endpoint"],
      fields: [
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "capability", label: "Capability", type: "select", options: [
          { value: "video", label: "Video" }, { value: "image", label: "Image" }, { value: "text", label: "Text" }, { value: "audio", label: "Audio / TTS" },
        ], required: true, inTable: true, half: true },
        { name: "type", label: "Adapter", type: "select", options: [
          { value: "openai", label: "OpenAI-compatible API" }, { value: "custom-http", label: "Custom HTTP endpoint" }, { value: "demo", label: "Demo (watermarked placeholders)" },
        ], inTable: true, half: true },
        { name: "endpoint", label: "API endpoint", type: "text", placeholder: "https://api.openai.com/v1", half: true },
        { name: "model", label: "Model", type: "text", placeholder: "gpt-4o-mini / dall-e-3 / tts-1", half: true, inTable: true },
        { name: "api_key", label: "API key", type: "password", placeholder: "leave blank to keep existing", hint: "Encrypted (AES-256-GCM) at rest. Never shown or sent to the browser." },
        { name: "enabled", label: "Enabled", type: "boolean", inTable: true, half: true },
        { name: "priority", label: "Priority (lower = first)", type: "number", half: true, inTable: true },
        { name: "timeout_ms", label: "Timeout (ms)", type: "number", half: true, min: 1000 },
        { name: "max_requests", label: "Max total requests (0 = ∞)", type: "number", half: true, min: 0 },
        { name: "notes", label: "Notes", type: "textarea" },
      ],
      transform: (v, existing) => {
        const out = { ...v };
        const key = String(out.api_key ?? "").trim();
        if (key) out.api_key_encrypted = encryptSecret(key);
        else out.api_key_encrypted = existing?.api_key_encrypted ?? "";
        delete out.api_key;
        out.updated_at = new Date().toISOString();
        return out;
      },
    },

    users: {
      key: "users", table: "admin_users", label: "Admins & Roles", singular: "Admin user", permission: "users.manage",
      orderBy: "id", searchCols: ["email", "name"],
      fields: [
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "email", label: "Email", type: "text", required: true, inTable: true },
        { name: "password", label: "Password", type: "password", hint: "Leave blank when editing to keep the current password. Min 10 characters." },
        { name: "role_id", label: "Role", type: "select", options: roles, required: true, inTable: true, half: true },
        { name: "is_active", label: "Active", type: "boolean", half: true, inTable: true },
      ],
      transform: (v, existing) => {
        const out: Record<string, any> = { name: v.name, email: String(v.email).toLowerCase().trim(), role_id: v.role_id, is_active: v.is_active };
        const pw = String(v.password ?? "");
        if (pw) {
          if (pw.length < 10) throw new Error("Password must be at least 10 characters.");
          out.password_hash = hashPassword(pw);
        } else if (!existing) {
          throw new Error("Password is required for new users.");
        }
        out.updated_at = new Date().toISOString();
        return out;
      },
      deletable: (row) => Number(row.id) !== 1,
    },

    ads: {
      key: "ads", table: "ad_placements", label: "Ad Placements", singular: "Placement", permission: "ads.manage",
      orderBy: "sort, id", searchCols: ["key", "name"],
      fields: [
        { name: "key", label: "Key (unique)", type: "text", required: true, inTable: true },
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "slot_id", label: "AdSense slot ID", type: "text", half: true, inTable: true },
        { name: "format", label: "Format", type: "select", options: [{ value: "auto", label: "Responsive (auto)" }, { value: "vertical", label: "Vertical" }], half: true },
        { name: "exclude_pages", label: "Exclude pages (JSON array)", type: "json", hint: 'e.g. ["/tools/ai-video-generator", "/contact"]' },
        { name: "enabled", label: "Enabled", type: "boolean", inTable: true, half: true },
        { name: "sort", label: "Sort", type: "number", half: true },
      ],
    },

    pages: {
      key: "pages", table: "pages", label: "Legal & Site Pages", singular: "Page", permission: "content.manage",
      orderBy: "slug", searchCols: ["slug", "title"],
      fields: [
        { name: "title", label: "Title", type: "text", required: true, inTable: true },
        { name: "slug", label: "Slug", type: "text", required: true, inTable: true, hint: "URL: /<slug> — e.g. privacy-policy" },
        { name: "content", label: "Content (markdown)", type: "md" },
        { name: "seo_title", label: "SEO title", type: "text", half: true },
        { name: "meta_description", label: "Meta description", type: "textarea" },
        { name: "noindex", label: "noindex", type: "boolean", half: true },
        { name: "enabled", label: "Enabled", type: "boolean", half: true, inTable: true },
        { name: "is_system", label: "System page", type: "boolean", half: true },
      ],
      transform: (v) => ({ ...v, slug: slugify(v.slug || v.title), updated_at: new Date().toISOString() }),
      deletable: (row) => !row.is_system,
    },

    blog_categories: {
      key: "blog_categories", table: "blog_categories", label: "Blog Categories", singular: "Blog category", permission: "blog.manage",
      orderBy: "name", searchCols: ["name", "slug"],
      fields: [
        { name: "name", label: "Name", type: "text", required: true, inTable: true },
        { name: "slug", label: "Slug", type: "text", required: true, inTable: true },
        { name: "description", label: "Description", type: "textarea" },
      ],
      transform: (v) => ({ ...v, slug: slugify(v.slug || v.name) }),
    },
  };
}

const ICON_OPTIONS = [
  "sparkles", "clapperboard", "image", "pen-line", "audio-lines", "megaphone", "search",
  "book-open", "youtube", "package", "share-2", "layout-template", "user-round", "scan-eye",
  "film", "heading", "text", "hash", "wand-sparkles", "gift", "shield-check", "layout-grid",
  "zap", "mouse-pointer-click", "download",
].map((i) => ({ value: i, label: i }));

export function validateAndCoerce(def: ResourceDef, formData: FormData, existing: Record<string, any> | null): Record<string, any> {
  const out: Record<string, any> = {};
  for (const field of def.fields) {
    const raw = formData.get(field.name);
    switch (field.type) {
      case "boolean":
        out[field.name] = raw === "on" || raw === "true" || raw === "1" ? 1 : 0;
        break;
      case "number": {
        const n = Number(raw);
        if (raw === "" || raw === null || !Number.isFinite(n)) {
          if (field.required && !existing) throw new Error(`${field.label} is required.`);
          out[field.name] = field.min ?? 0;
        } else out[field.name] = Math.round(n);
        break;
      }
      case "json": {
        const s = String(raw ?? "").trim();
        if (!s) { out[field.name] = "{}"; break; }
        try { JSON.parse(s); out[field.name] = s; } catch { throw new Error(`${field.label}: invalid JSON.`); }
        break;
      }
      case "password":
        out[field.name] = String(raw ?? "");
        break;
      default: {
        let s = String(raw ?? "").trim();
        if (field.required && !s) {
          throw new Error(`${field.label} is required.`);
        }
        if (field.max && s.length > field.max) s = s.slice(0, field.max);
        out[field.name] = s;
      }
    }
  }
  // select validation against allow-list
  for (const field of def.fields.filter((f) => f.type === "select" && f.options)) {
    if (out[field.name] === "" || out[field.name] == null) continue;
    if (!field.options!.some((o) => o.value === String(out[field.name]))) {
      throw new Error(`${field.label}: invalid value.`);
    }
  }
  return out;
}
