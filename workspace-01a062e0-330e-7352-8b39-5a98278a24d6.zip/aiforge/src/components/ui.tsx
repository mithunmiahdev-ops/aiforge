"use client";
import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Check, ChevronDown, Loader2, X, AlertTriangle, Info, CheckCircle2, XCircle } from "lucide-react";

/* ── Buttons / links ────────────────────────────────────────────── */
type BtnVariant = "primary" | "secondary" | "ghost" | "danger";
export function Btn({
  variant = "primary", size, className = "", loading, children, ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: "sm"; loading?: boolean }) {
  return (
    <button className={`${variant === "primary" ? "btn-primary" : variant === "secondary" ? "btn-secondary" : variant === "ghost" ? "btn-ghost" : "btn-danger"} ${size === "sm" ? "btn-sm" : ""} ${className}`} {...rest}>
      {loading && <Loader2 size={16} className="animate-spin" aria-hidden />}
      {children}
    </button>
  );
}
export function BtnLink({ variant = "primary", size, className = "", href, children, ...rest }: { variant?: BtnVariant; size?: "sm"; href: string; className?: string; children: React.ReactNode } & Omit<React.ComponentProps<typeof Link>, "href" | "className" | "children">) {
  return (
    <Link href={href} className={`${variant === "primary" ? "btn-primary" : variant === "secondary" ? "btn-secondary" : variant === "ghost" ? "btn-ghost" : "btn-danger"} ${size === "sm" ? "btn-sm" : ""} ${className}`} {...rest}>
      {children}
    </Link>
  );
}

/* ── Alerts ─────────────────────────────────────────────────────── */
export function Alert({ kind = "info", title, children, className = "" }: { kind?: "info" | "success" | "warn" | "danger"; title?: string; children?: React.ReactNode; className?: string }) {
  const map = {
    info: { cls: "border-brand/30 bg-brand/5 text-fg", icon: <Info size={16} className="text-brand shrink-0 mt-0.5" /> },
    success: { cls: "border-ok/30 bg-ok/5 text-fg", icon: <CheckCircle2 size={16} className="text-ok shrink-0 mt-0.5" /> },
    warn: { cls: "border-warn/30 bg-warn/5 text-fg", icon: <AlertTriangle size={16} className="text-warn shrink-0 mt-0.5" /> },
    danger: { cls: "border-danger/30 bg-danger/5 text-fg", icon: <XCircle size={16} className="text-danger shrink-0 mt-0.5" /> },
  }[kind];
  return (
    <div role={kind === "danger" ? "alert" : "status"} className={`flex gap-2.5 rounded-xl border p-3.5 text-sm ${map.cls} ${className}`}>
      {map.icon}
      <div className="min-w-0">
        {title && <div className="font-semibold">{title}</div>}
        {children && <div className={title ? "mt-0.5 text-muted" : "text-muted"}>{children}</div>}
      </div>
    </div>
  );
}

/* ── Form fields ────────────────────────────────────────────────── */
export function Field({ label, hint, children, className = "" }: { label?: string; hint?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      {label && <label className="label">{label}</label>}
      {children}
      {hint && <p className="mt-1 text-xs text-faint">{hint}</p>}
    </div>
  );
}
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(function Input({ className = "", ...rest }, ref) {
  return <input ref={ref} className={`input ${className}`} {...rest} />;
});
export function Textarea({ className = "", ...rest }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={`input min-h-[110px] resize-y leading-6 ${className}`} {...rest} />;
}
export function Select({ className = "", children, ...rest }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="relative">
      <select className={`input appearance-none pr-9 ${className}`} {...rest}>{children}</select>
      <ChevronDown size={15} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
    </div>
  );
}
export function Toggle({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label?: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-40 ${checked ? "bg-brand" : "bg-border2"}`}>
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? "left-[22px]" : "left-0.5"}`} />
    </button>
  );
}

/* ── Spinner / empty / error states ─────────────────────────────── */
export function Spinner({ className = "" }: { className?: string }) {
  return <Loader2 className={`animate-spin text-brand ${className}`} size={20} aria-hidden />;
}
export function Loading({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2.5 py-14 text-sm text-muted" role="status">
      <Spinner /> {label}
    </div>
  );
}
export function EmptyState({ icon, title, children }: { icon?: React.ReactNode; title: string; children?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border2 px-6 py-14 text-center">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-surface2 text-faint">{icon ?? <Info size={20} />}</div>
      <div className="font-semibold">{title}</div>
      {children && <div className="mt-1 max-w-sm text-sm text-muted">{children}</div>}
    </div>
  );
}

/* ── Modal (accessible, Esc to close, focus on open) ─────────────── */
export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    ref.current?.focus();
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center overflow-y-auto bg-black/55 p-4 pt-[8vh] backdrop-blur-sm"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()} aria-modal="true" role="dialog" aria-label={title}>
      <div ref={ref} tabIndex={-1} className={`card animate-fade-up w-full ${wide ? "max-w-3xl" : "max-w-lg"} p-6 outline-none`}>
        <div className="mb-4 flex items-center justify-between gap-4">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="btn-ghost !p-2" aria-label="Close dialog"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ── Toast-ish inline feedback ──────────────────────────────────── */
export function CopyButton({ text, size = "sm", label = "Copy" }: { text: string; size?: "sm" | undefined; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <Btn variant="secondary" size={size} onClick={async () => {
      try { await navigator.clipboard.writeText(text); } catch {
        const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
      }
      setDone(true); setTimeout(() => setDone(false), 1600);
    }} aria-live="polite">
      {done ? <><Check size={14} /> Copied</> : <>{label}</>}
    </Btn>
  );
}

export function Collapse({ question, answer, defaultOpen = false }: { question: string; answer: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="card overflow-hidden">
      <button onClick={() => setOpen(!open)} aria-expanded={open} className="flex w-full items-center justify-between gap-4 p-4 text-left text-[15px] font-semibold hover:text-brand sm:p-5">
        {question}
        <ChevronDown size={17} className={`shrink-0 text-faint transition-transform ${open ? "rotate-180" : ""}`} aria-hidden />
      </button>
      {open && <div className="prose-site border-t border-border px-4 pb-5 pt-4 sm:px-5">{answer}</div>}
    </div>
  );
}
