/** Lightweight dependency-free SVG charts for the admin dashboard. */

export function LineChart({ data, height = 160, labels }: { data: number[]; height?: number; labels?: string[] }) {
  const w = 560, h = height, pad = 8;
  const max = Math.max(1, ...data);
  const step = data.length > 1 ? (w - pad * 2) / (data.length - 1) : 0;
  const pts = data.map((v, i) => [pad + i * step, h - pad - (v / max) * (h - pad * 2 - 14)] as const);
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area = `${path} L${pts.length ? pts[pts.length - 1][0] : pad},${h - pad} L${pad},${h - pad} Z`;
  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full" role="img" aria-label="Usage over time chart">
        <defs>
          <linearGradient id="lc-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgb(var(--c-brand))" stopOpacity="0.25" />
            <stop offset="100%" stopColor="rgb(var(--c-brand))" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((f) => (
          <line key={f} x1={pad} x2={w - pad} y1={h - pad - f * (h - pad * 2)} y2={h - pad - f * (h - pad * 2)} stroke="rgb(var(--c-border))" strokeDasharray="3 5" strokeWidth="1" />
        ))}
        <path d={area} fill="url(#lc-fill)" />
        <path d={path} fill="none" stroke="rgb(var(--c-brand))" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3" fill="rgb(var(--c-brand))" />)}
      </svg>
      {labels && (
        <div className="mt-1 flex justify-between text-[10px] text-faint">
          <span>{labels[0]}</span><span>{labels[Math.floor(labels.length / 2)]}</span><span>{labels[labels.length - 1]}</span>
        </div>
      )}
    </div>
  );
}

export function BarList({ items }: { items: { label: string; value: number; hint?: string }[] }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return (
    <div className="flex flex-col gap-3">
      {items.length === 0 && <div className="text-sm text-faint">No data yet.</div>}
      {items.map((it) => (
        <div key={it.label}>
          <div className="mb-1 flex items-baseline justify-between gap-3 text-[13px]">
            <span className="truncate font-medium">{it.label}</span>
            <span className="shrink-0 text-faint">{it.value}{it.hint ? ` · ${it.hint}` : ""}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-surface2">
            <div className="h-full rounded-full bg-gradient-to-r from-brand to-brand2" style={{ width: `${(it.value / max) * 100}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function Donut({ parts }: { parts: { label: string; value: number; color: string }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0) || 1;
  let acc = 0;
  const r = 38, c = 2 * Math.PI * r;
  return (
    <div className="flex items-center gap-5">
      <svg viewBox="0 0 100 100" className="h-32 w-32 shrink-0 -rotate-90" role="img" aria-label="Status distribution">
        <circle cx="50" cy="50" r={r} fill="none" stroke="rgb(var(--c-surface2))" strokeWidth="12" />
        {parts.map((p) => {
          const frac = p.value / total;
          const el = <circle key={p.label} cx="50" cy="50" r={r} fill="none" stroke={p.color} strokeWidth="12"
            strokeDasharray={`${frac * c} ${c}`} strokeDashoffset={-acc * c} strokeLinecap="butt" />;
          acc += frac;
          return el;
        })}
      </svg>
      <div className="flex flex-col gap-1.5 text-[13px]">
        {parts.map((p) => (
          <div key={p.label} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />
            <span className="text-muted">{p.label}</span>
            <span className="font-semibold">{p.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
