"use client";
import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

export function ThemeToggle({ defaultTheme = "dark" }: { defaultTheme?: string }) {
  const [dark, setDark] = useState<boolean>(defaultTheme !== "light");

  useEffect(() => {
    const stored = typeof localStorage !== "undefined" ? localStorage.getItem("theme") : null;
    setDark(stored ? stored === "dark" : defaultTheme !== "light");
  }, [defaultTheme]);

  return (
    <button
      onClick={() => {
        const next = !dark;
        setDark(next);
        document.documentElement.classList.toggle("dark", next);
        try { localStorage.setItem("theme", next ? "dark" : "light"); } catch {}
      }}
      className="btn-ghost !rounded-xl !p-2.5"
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
    >
      {dark ? <Sun size={17} /> : <Moon size={17} />}
    </button>
  );
}
