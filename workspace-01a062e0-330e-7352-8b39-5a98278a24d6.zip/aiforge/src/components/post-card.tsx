import Link from "next/link";
import { Sparkles, Clock } from "lucide-react";

export function PostCard({ post }: { post: any }) {
  return (
    <Link href={`/blog/${post.slug}`} className="card-hover group flex flex-col overflow-hidden">
      <div className="relative aspect-[16/9] overflow-hidden bg-gradient-to-br from-brand/20 to-brand2/20">
        {post.featured_image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={post.featured_image} alt={post.featured_image_alt || post.title} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
        ) : (
          <div className="grid h-full place-items-center text-brand/50"><Sparkles size={28} aria-hidden /></div>
        )}
        {post.category_name && <span className="badge-brand absolute left-3 top-3 !bg-surface/90">{post.category_name}</span>}
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-center gap-2 text-xs text-faint">
          {post.reading_minutes ? <span className="flex items-center gap-1"><Clock size={12} /> {post.reading_minutes} min read</span> : null}
          {post.published_at && <span>· {new Date(String(post.published_at).includes("T") ? post.published_at : post.published_at + "Z").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>}
        </div>
        <h3 className="mt-2 font-semibold leading-snug group-hover:text-brand">{post.title}</h3>
        <p className="mt-1.5 line-clamp-2 text-sm leading-relaxed text-muted">{post.excerpt}</p>
      </div>
    </Link>
  );
}
