"use client";
import { useEffect, useState } from "react";
import Script from "next/script";
import Link from "next/link";
import { Cookie } from "lucide-react";

export interface AnalyticsConfig {
  gaEnabled: boolean; gaMeasurementId: string;
  gtmEnabled: boolean; gtmContainerId: string;
  requireConsent: boolean;
}

/** GA4 + GTM loaders. Rendered only when the admin has enabled them, and
 *  (optionally) only after cookie consent. IDs come from server settings. */
export function AnalyticsScripts({ config }: { config: AnalyticsConfig }) {
  const [consented, setConsented] = useState(!config.requireConsent);

  useEffect(() => {
    const check = () => setConsented(document.cookie.includes("aiforge_consent=granted") || !config.requireConsent);
    check();
    window.addEventListener("aiforge-consent-changed", check);
    return () => window.removeEventListener("aiforge-consent-changed", check);
  }, [config.requireConsent]);

  const gaOn = config.gaEnabled && /^G-[A-Z0-9]+$/.test(config.gaMeasurementId);
  const gtmOn = config.gtmEnabled && /^GTM-[A-Z0-9]+$/.test(config.gtmContainerId);
  if (!consented || (!gaOn && !gtmOn)) return null;

  return (
    <>
      {gaOn && (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${config.gaMeasurementId}`} strategy="afterInteractive" />
          <Script id="ga-init" strategy="afterInteractive">{`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${config.gaMeasurementId}', { anonymize_ip: true });
          `}</Script>
        </>
      )}
      {gtmOn && (
        <Script id="gtm-init" strategy="afterInteractive">{`
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
          var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';
          j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','${config.gtmContainerId}');
        `}</Script>
      )}
    </>
  );
}

/** EU-friendly cookie consent banner. Choice stored in a cookie + localStorage. */
export function CookieConsent({ requireConsent }: { requireConsent: boolean }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!requireConsent) return;
    const stored = document.cookie.includes("aiforge_consent=");
    if (!stored) setVisible(true);
  }, [requireConsent]);

  const choose = (value: "granted" | "denied") => {
    const maxAge = 60 * 60 * 24 * 180;
    document.cookie = `aiforge_consent=${value}; path=/; max-age=${maxAge}; SameSite=Lax`;
    try { localStorage.setItem("aiforge_consent", value); } catch {}
    window.dispatchEvent(new Event("aiforge-consent-changed"));
    setVisible(false);
  };

  if (!visible) return null;
  return (
    <div role="dialog" aria-label="Cookie consent" className="fixed bottom-4 left-4 right-4 z-[80] mx-auto max-w-xl">
      <div className="card animate-fade-up flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
        <Cookie size={20} className="shrink-0 text-brand" aria-hidden />
        <p className="flex-1 text-[13px] leading-5 text-muted">
          We use one strictly-necessary cookie for fair-use limits. Optional analytics/advertising cookies
          are only used if you allow them.{" "}
          <Link href="/cookie-policy" className="font-medium text-brand hover:underline">Cookie Policy</Link>
        </p>
        <div className="flex shrink-0 gap-2">
          <button onClick={() => choose("denied")} className="btn-ghost btn-sm">Decline</button>
          <button onClick={() => choose("granted")} className="btn-primary btn-sm">Allow</button>
        </div>
      </div>
    </div>
  );
}
