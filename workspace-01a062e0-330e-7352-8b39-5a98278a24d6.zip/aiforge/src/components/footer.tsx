import Link from "next/link";
import { Sparkles, Twitter, Youtube, Github, Linkedin, Instagram, Facebook } from "lucide-react";
import { ToolIcon } from "./icon";

export interface FooterColumn { group: string; items: { label: string; url: string }[] }

export function Footer({ siteName, logoUrl, description, copyright, columns, socials }: {
  siteName: string; logoUrl?: string; description: string; copyright: string;
  columns: FooterColumn[]; socials: Record<string, string>;
}) {
  const socialIcons: Record<string, { icon: typeof Twitter; label: string }> = {
    twitter: { icon: Twitter, label: "X / Twitter" },
    youtube: { icon: Youtube, label: "YouTube" },
    github: { icon: Github, label: "GitHub" },
    linkedin: { icon: Linkedin, label: "LinkedIn" },
    instagram: { icon: Instagram, label: "Instagram" },
    facebook: { icon: Facebook, label: "Facebook" },
  };
  return (
    <footer className="border-t border-border bg-surface/50">
      <div className="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-6">
        <div className="lg:col-span-2">
          <Link href="/" className="flex items-center gap-2 font-bold">
            {logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logoUrl} alt={`${siteName} logo`} className="h-8 w-8 rounded-lg object-contain" />
            ) : (
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-brand2 text-white">
                <Sparkles size={16} aria-hidden />
              </span>
            )}
            {siteName}
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-6 text-muted">{description}</p>
          <div className="mt-5 flex gap-2">
            {Object.entries(socials).filter(([, url]) => url).map(([key, url]) => {
              const s = socialIcons[key];
              if (!s) return null;
              const Ico = s.icon;
              return (
                <a key={key} href={url} target="_blank" rel="noopener noreferrer" aria-label={s.label}
                  className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted transition-colors hover:border-brand/50 hover:text-brand">
                  <Ico size={16} aria-hidden />
                </a>
              );
            })}
          </div>
        </div>
        {columns.map((col) => (
          <nav key={col.group} aria-label={col.group}>
            <h3 className="text-[13px] font-bold uppercase tracking-wider text-faint">{col.group}</h3>
            <ul className="mt-4 flex flex-col gap-2.5">
              {col.items.map((item) => (
                <li key={item.url + item.label}>
                  <Link href={item.url} className="text-sm text-muted transition-colors hover:text-brand">{item.label}</Link>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <div className="border-t border-border">
        <div className="container-x flex flex-col items-center justify-between gap-3 py-5 text-[13px] text-faint sm:flex-row">
          <p>© {new Date().getFullYear()} {copyright}</p>
          <p className="flex items-center gap-1.5">
            <ToolIcon name="sparkles" size={13} /> Free AI tools — no signup required
          </p>
        </div>
      </div>
    </footer>
  );
}
