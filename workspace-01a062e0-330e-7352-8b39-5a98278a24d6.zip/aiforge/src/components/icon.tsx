import {
  Sparkles, Clapperboard, Image as ImageIcon, PenLine, AudioLines, Megaphone, Search,
  BookOpen, Youtube, Package, Share2, LayoutTemplate, UserRound, ScanEye, Film,
  Heading, Text, Hash, WandSparkles, Gift, ShieldCheck, LayoutGrid, Zap,
  MousePointerClick, Download, ArrowRight, type LucideIcon,
} from "lucide-react";

/** Maps icon names stored in the database to Lucide components. */
const ICONS: Record<string, LucideIcon> = {
  sparkles: Sparkles, clapperboard: Clapperboard, image: ImageIcon, "pen-line": PenLine,
  "audio-lines": AudioLines, megaphone: Megaphone, search: Search, "book-open": BookOpen,
  youtube: Youtube, package: Package, "share-2": Share2, "layout-template": LayoutTemplate,
  "user-round": UserRound, "scan-eye": ScanEye, film: Film, heading: Heading, text: Text,
  hash: Hash, "wand-sparkles": WandSparkles, gift: Gift, "shield-check": ShieldCheck,
  "layout-grid": LayoutGrid, zap: Zap, "mouse-pointer-click": MousePointerClick, download: Download,
};

export function ToolIcon({ name, size = 20, className = "" }: { name: string; size?: number; className?: string }) {
  const Cmp = ICONS[name] ?? Sparkles;
  return <Cmp size={size} className={className} aria-hidden />;
}

export function hasIcon(name: string) {
  return name in ICONS;
}
