"use client";
import { useState } from "react";
import { Alert, Btn, CopyButton, Field, Select, Textarea } from "@/components/ui";
import { Sparkles, WandSparkles, Minimize2, Maximize2, RefreshCw, Rocket } from "lucide-react";
import { JobError, JobStatus, LimitsNote, useGenerationJob, type ToolLimits } from "./job";

export interface PromptTemplate { id: number; name: string; description: string; platform: string; content: string }

export function PromptToolClient({ slug, name, config, limits, configured, templates }: {
  slug: string; name: string; config: any; limits: ToolLimits; configured: boolean; templates: PromptTemplate[];
}) {
  const { job, submitting, submitError, generate, cooldownLeft, clearSubmitError } = useGenerationJob(slug);
  const [topic, setTopic] = useState("");
  const [platform, setPlatform] = useState(config.platforms?.[0] ?? "ChatGPT");
  const [contentType, setContentType] = useState(config.contentTypes?.[0] ?? "Blog post");
  const [style, setStyle] = useState("");
  const [audience, setAudience] = useState("");
  const [tone, setTone] = useState(config.tones?.[0] ?? "Professional");
  const [length, setLength] = useState(config.lengths?.[1] ?? "Medium");
  const [instructions, setInstructions] = useState("");
  const tooLong = topic.length > limits.maxPromptChars;

  const buildParams = (mode?: "improve" | "shorten" | "expand", currentOutput?: string) => ({
    topic: topic.trim(),
    platform, contentType, style, audience, tone, length,
    instructions: instructions.trim(),
    prompt: topic.trim(), // prompt field carries the primary input
    mode: mode ?? "generate",
    previousOutput: currentOutput ?? "",
  });

  const run = async (mode?: "improve" | "shorten" | "expand") => {
    if (topic.trim().length < 3) return;
    clearSubmitError();
    await generate(buildParams(mode, job?.result?.text ?? ""), limits.cooldownSeconds);
  };

  const applyTemplate = (t: PromptTemplate) => {
    setPlatform(t.platform || platform);
    setTopic((cur) => cur || t.content.replace(/\{\{(\w+)\}\}/g, (_m, k) =>
      ({ topic: "your topic here", audience: audience || "your audience", tone: tone.toLowerCase(), length, aspect: "16:9", product: "your product", subject: "your subject" } as any)[k] ?? k));
  };

  const output = job?.status === "completed" ? job.result?.text ?? "" : "";

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
      <section className="card h-fit p-5 sm:p-6" aria-label={`${name} controls`}>
        <Field label="Topic or task" hint={`What should the prompt be about? ${topic.length}/${limits.maxPromptChars}`}>
          <Textarea value={topic} onChange={(e) => setTopic(e.target.value)} maxLength={limits.maxPromptChars + 100}
            placeholder="e.g. A YouTube video about budget travel in Japan for first-timers" />
        </Field>
        {tooLong && <Alert kind="info" className="mt-2">Your request is too long — please keep it under {limits.maxPromptChars.toLocaleString()} characters.</Alert>}

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Platform">
            <Select value={platform} onChange={(e) => setPlatform(e.target.value)}>
              {(config.platforms ?? []).map((p: string) => <option key={p}>{p}</option>)}
            </Select>
          </Field>
          <Field label="Content type">
            <Select value={contentType} onChange={(e) => setContentType(e.target.value)}>
              {(config.contentTypes ?? []).map((c: string) => <option key={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="Tone">
            <Select value={tone} onChange={(e) => setTone(e.target.value)}>
              {(config.tones ?? []).map((t: string) => <option key={t}>{t}</option>)}
            </Select>
          </Field>
          <Field label="Length">
            <Select value={length} onChange={(e) => setLength(e.target.value)}>
              {(config.lengths ?? []).map((l: string) => <option key={l}>{l}</option>)}
            </Select>
          </Field>
          <Field label="Style (optional)"><input className="input" value={style} onChange={(e) => setStyle(e.target.value)} placeholder="e.g. storytelling, data-driven" /></Field>
          <Field label="Audience (optional)"><input className="input" value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="e.g. beginner photographers" /></Field>
        </div>
        <Field label="Additional instructions (optional)" className="mt-4">
          <Textarea className="!min-h-[80px]" value={instructions} onChange={(e) => setInstructions(e.target.value)} placeholder="Anything specific to include or avoid…" />
        </Field>

        {templates.length > 0 && (
          <div className="mt-4">
            <div className="label">Start from a template</div>
            <div className="flex flex-wrap gap-2">
              {templates.slice(0, 6).map((t) => (
                <button key={t.id} type="button" onClick={() => applyTemplate(t)} className="chip" title={t.description}>{t.name}</button>
              ))}
            </div>
          </div>
        )}

        {!configured && <Alert kind="warn" className="mt-4">AI service is not configured yet — you can fill the brief now; generation works once the administrator connects a text provider.</Alert>}

        <Btn className="mt-5 w-full" onClick={() => run()} loading={submitting} disabled={cooldownLeft > 0 || submitting || tooLong || topic.trim().length < 3}>
          <Sparkles size={16} />{cooldownLeft > 0 ? `Cooldown — ${cooldownLeft}s` : "Generate Prompt"}
        </Btn>
        <div className="mt-3"><LimitsNote limits={limits} configured={configured} /></div>
      </section>

      <section aria-label="Result" className="flex flex-col gap-4">
        <JobError error={submitError} />
        <JobStatus job={job} submitting={submitting} />
        {output ? (
          <div className="card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border bg-surface2/50 px-4 py-2.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-faint">Optimized prompt</span>
              <div className="flex flex-wrap gap-2">
                <CopyButton text={output} />
                <Btn variant="secondary" size="sm" onClick={() => run("improve")} disabled={submitting} title="Ask the AI to improve the current output"><Rocket size={13} /> Improve</Btn>
                <Btn variant="secondary" size="sm" onClick={() => run("shorten")} disabled={submitting}><Minimize2 size={13} /> Shorten</Btn>
                <Btn variant="secondary" size="sm" onClick={() => run("expand")} disabled={submitting}><Maximize2 size={13} /> Expand</Btn>
                <Btn variant="secondary" size="sm" onClick={() => run()} disabled={submitting}><RefreshCw size={13} /> Regenerate</Btn>
              </div>
            </div>
            <div className="max-h-[520px] overflow-y-auto whitespace-pre-wrap p-4 text-sm leading-6">{output}</div>
          </div>
        ) : (
          (!job || job.status === "failed") && !submitting && (
            <div className="grid place-items-center rounded-2xl border border-dashed border-border2 p-10 text-center">
              <WandSparkles size={28} className="mb-3 text-faint" aria-hidden />
              <div className="max-w-xs text-sm text-faint">Your optimized prompt will appear here. Fill the brief on the left and press <span className="font-semibold text-muted">Generate Prompt</span>.</div>
            </div>
          )
        )}
      </section>
    </div>
  );
}
