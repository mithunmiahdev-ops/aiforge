"use client";
import { useState } from "react";
import { Alert, Btn, Field, Select, Textarea } from "@/components/ui";
import { Sparkles } from "lucide-react";
import { ImageGallery, JobError, JobStatus, LimitsNote, MediaResult, ResultActions, useGenerationJob, type ToolLimits } from "./job";

export function ImageToolClient({ slug, name, config, limits, configured }: {
  slug: string; name: string; config: any; limits: ToolLimits; configured: boolean;
}) {
  const { job, submitting, submitError, generate, cooldownLeft, clearSubmitError } = useGenerationJob(slug);
  const [prompt, setPrompt] = useState("");
  const [negative, setNegative] = useState("");
  const [preset, setPreset] = useState(config.presets?.[0] ?? "Photorealistic");
  const [aspect, setAspect] = useState(config.aspects?.[0] ?? "1:1");
  const [quality, setQuality] = useState(config.qualities?.[0] ?? "Standard");
  const [count, setCount] = useState(1);
  const maxImages = Math.min(config.maxImages ?? 4, 4);
  const tooLong = prompt.length > limits.maxPromptChars;

  const onSubmit = async () => {
    if (prompt.trim().length < 3) return;
    clearSubmitError();
    await generate({ prompt: prompt.trim(), negative: negative.trim(), preset, aspect, quality, count }, limits.cooldownSeconds);
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <section className="card h-fit p-5 sm:p-6" aria-label={`${name} controls`}>
        <Field label="Prompt" hint={`${prompt.length}/${limits.maxPromptChars} characters`}>
          <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={limits.maxPromptChars + 100}
            placeholder="A serene mountain lake at sunrise, mist over the water, ultra detailed…" />
        </Field>
        {tooLong && <Alert kind="info" className="mt-2">Your request is too long — please keep it under {limits.maxPromptChars.toLocaleString()} characters.</Alert>}
        <Field label="Negative prompt (optional)" className="mt-4" hint="Things to avoid: blurry, text, watermark…">
          <input className="input" value={negative} onChange={(e) => setNegative(e.target.value)} placeholder="blurry, distorted, text" />
        </Field>

        <Field label="Preset" className="mt-4">
          <div className="flex flex-wrap gap-2">
            {(config.presets ?? []).map((p: string) => (
              <button key={p} type="button" onClick={() => setPreset(p)} className={`chip ${preset === p ? "chip-active" : ""} `} aria-pressed={preset === p}>{p}</button>
            ))}
          </div>
        </Field>

        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          <Field label="Aspect">
            <Select value={aspect} onChange={(e) => setAspect(e.target.value)}>
              {(config.aspects ?? ["1:1"]).map((a: string) => <option key={a}>{a}</option>)}
            </Select>
          </Field>
          <Field label="Quality">
            <Select value={quality} onChange={(e) => setQuality(e.target.value)}>
              {(config.qualities ?? ["Standard", "High"]).map((q: string) => <option key={q}>{q}</option>)}
            </Select>
          </Field>
          <Field label="Images">
            <Select value={String(count)} onChange={(e) => setCount(Number(e.target.value))}>
              {Array.from({ length: maxImages }, (_, i) => i + 1).map((n) => <option key={n} value={n}>{n}</option>)}
            </Select>
          </Field>
        </div>

        {!configured && <Alert kind="warn" className="mt-4">AI service is not configured yet — compose your prompt now; generation will work once the administrator connects an image provider.</Alert>}

        <Btn className="mt-5 w-full" onClick={onSubmit} loading={submitting} disabled={cooldownLeft > 0 || submitting || tooLong || prompt.trim().length < 3}>
          <Sparkles size={16} />{cooldownLeft > 0 ? `Cooldown — ${cooldownLeft}s` : "Generate Images"}
        </Btn>
        <div className="mt-3"><LimitsNote limits={limits} configured={configured} /></div>
      </section>

      <section aria-label="Result" className="flex flex-col gap-4">
        <JobError error={submitError} />
        <JobStatus job={job} submitting={submitting} />
        {job?.status === "completed" && job.result && (
          <>
            {job.result.images && job.result.images.length > 1 ? (
              <ImageGallery urls={job.result.images} />
            ) : (
              <MediaResult url={job.result.url ?? job.result.text ?? ""} mime={job.result.mime} kind="image" />
            )}
            <ResultActions prompt={prompt + (negative ? ` (avoid: ${negative})` : "")} url={job.result.images?.[0] ?? job.result.url} mime={job.result.mime} regenerate={onSubmit} />
          </>
        )}
        {(!job || job.status === "failed") && !submitting && (
          <div className="grid min-h-[280px] grid-cols-2 gap-4">
            {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton aspect-square" />)}
            <div className="col-span-2 -mt-2 text-center text-sm text-faint">Your generated images will appear here</div>
          </div>
        )}
      </section>
    </div>
  );
}
