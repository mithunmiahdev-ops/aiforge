"use client";
import { useState } from "react";
import { Alert, Btn, Field, Select, Textarea } from "@/components/ui";
import { Sparkles } from "lucide-react";
import { JobError, JobStatus, LimitsNote, TextResult, ResultActions, useGenerationJob, type ToolLimits } from "./job";

export interface CustomField { name: string; label: string; type: "select" | "text" | "textarea"; options?: string[]; placeholder?: string }

/** Schema-driven client used by every text/custom tool — admins define the fields
 *  in the tool config (Admin → AI Tools), no code changes needed. */
export function TextToolClient({ slug, name, fields, limits, configured }: {
  slug: string; name: string; fields: CustomField[]; limits: ToolLimits; configured: boolean;
}) {
  const { job, submitting, submitError, generate, cooldownLeft, clearSubmitError } = useGenerationJob(slug);
  const [prompt, setPrompt] = useState("");
  const [values, setValues] = useState<Record<string, string>>({});
  const tooLong = prompt.length > limits.maxPromptChars;

  const set = (k: string, v: string) => setValues((s) => ({ ...s, [k]: v }));

  const onSubmit = async () => {
    if (prompt.trim().length < 3) return;
    clearSubmitError();
    await generate({ prompt: prompt.trim(), ...values }, limits.cooldownSeconds);
  };

  const selects = fields.filter((f) => f.type === "select");
  const texts = fields.filter((f) => f.type === "text");

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
      <section className="card h-fit p-5 sm:p-6" aria-label={`${name} controls`}>
        <Field label="Your idea / topic" hint={`${prompt.length}/${limits.maxPromptChars} characters`}>
          <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={limits.maxPromptChars + 100}
            placeholder="Describe what you want to create…" />
        </Field>
        {tooLong && <Alert kind="info" className="mt-2">Your request is too long — please keep it under {limits.maxPromptChars.toLocaleString()} characters.</Alert>}

        {selects.length > 0 && (
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {selects.map((f) => (
              <Field key={f.name} label={f.label}>
                <Select value={values[f.name] ?? f.options?.[0] ?? ""} onChange={(e) => set(f.name, e.target.value)}>
                  {(f.options ?? []).map((o) => <option key={o}>{o}</option>)}
                </Select>
              </Field>
            ))}
          </div>
        )}
        {texts.length > 0 && (
          <div className={`mt-4 grid gap-4 ${texts.length > 1 ? "sm:grid-cols-2" : ""}`}>
            {texts.map((f) => (
              <Field key={f.name} label={f.label}>
                <input className="input" value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
              </Field>
            ))}
          </div>
        )}
        {fields.filter((f) => f.type === "textarea").map((f) => (
          <Field key={f.name} label={f.label} className="mt-4">
            <Textarea value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
          </Field>
        ))}

        {!configured && <Alert kind="warn" className="mt-4">AI service is not configured yet — you can prepare your input now; generation works once the administrator connects a text provider.</Alert>}

        <Btn className="mt-5 w-full" onClick={onSubmit} loading={submitting} disabled={cooldownLeft > 0 || submitting || tooLong || prompt.trim().length < 3}>
          <Sparkles size={16} />{cooldownLeft > 0 ? `Cooldown — ${cooldownLeft}s` : `Generate with ${name}`}
        </Btn>
        <div className="mt-3"><LimitsNote limits={limits} configured={configured} /></div>
      </section>

      <section aria-label="Result" className="flex flex-col gap-4">
        <JobError error={submitError} />
        <JobStatus job={job} submitting={submitting} />
        {job?.status === "completed" && job.result?.text && (
          <>
            <TextResult text={job.result.text} />
            <ResultActions prompt={prompt} regenerate={onSubmit} />
          </>
        )}
        {(!job || job.status === "failed") && !submitting && (
          <div className="grid place-items-center rounded-2xl border border-dashed border-border2 p-10 text-center">
            <div className="max-w-xs text-sm text-faint">Your generated content will appear here, ready to copy or download.</div>
          </div>
        )}
      </section>
    </div>
  );
}
