"use client";
import { useState } from "react";
import { Alert, Btn, Field, Select, Textarea } from "@/components/ui";
import { Sparkles } from "lucide-react";
import { JobError, JobStatus, LimitsNote, MediaResult, ResultActions, useGenerationJob, type ToolLimits } from "./job";

export function AudioToolClient({ slug, name, config, limits, configured, languages, voices }: {
  slug: string; name: string; config: any; limits: ToolLimits; configured: boolean;
  languages: { code: string; label: string }[]; voices: { id: string; label: string }[];
}) {
  const { job, submitting, submitError, generate, cooldownLeft, clearSubmitError } = useGenerationJob(slug);
  const [script, setScript] = useState("");
  const [voice, setVoice] = useState(voices[0]?.id ?? "alloy");
  const [language, setLanguage] = useState(languages[0]?.code ?? "en");
  const [mood, setMood] = useState(config.moods?.[0] ?? "Neutral");
  const [duration, setDuration] = useState(config.defaultDuration ?? 30);
  const tooLong = script.length > limits.maxPromptChars;

  const onSubmit = async () => {
    if (script.trim().length < 3) return;
    clearSubmitError();
    await generate({ prompt: script.trim(), script: script.trim(), voice, language, mood, duration }, limits.cooldownSeconds);
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <section className="card h-fit p-5 sm:p-6" aria-label={`${name} controls`}>
        <Field label="Text / script" hint={`${script.length}/${limits.maxPromptChars} characters · ≈${Math.max(1, Math.round(script.length / 15))}s of speech`}>
          <Textarea className="!min-h-[160px]" value={script} onChange={(e) => setScript(e.target.value)} maxLength={limits.maxPromptChars + 100}
            placeholder="Paste or write the text you want converted to speech…" />
        </Field>
        {tooLong && <Alert kind="info" className="mt-2">Your request is too long — please keep it under {limits.maxPromptChars.toLocaleString()} characters.</Alert>}

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Voice">
            <Select value={voice} onChange={(e) => setVoice(e.target.value)}>
              {voices.map((v) => <option key={v.id} value={v.id}>{v.label}</option>)}
            </Select>
          </Field>
          <Field label="Language">
            <Select value={language} onChange={(e) => setLanguage(e.target.value)}>
              {languages.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
            </Select>
          </Field>
          <Field label="Mood">
            <Select value={mood} onChange={(e) => setMood(e.target.value)}>
              {(config.moods ?? ["Neutral"]).map((m: string) => <option key={m}>{m}</option>)}
            </Select>
          </Field>
          <Field label={`Target duration (max ${limits.maxDurationSeconds}s)`}>
            <input type="number" min={5} max={limits.maxDurationSeconds} value={duration}
              onChange={(e) => setDuration(Math.min(Number(e.target.value) || 5, limits.maxDurationSeconds))} className="input" />
          </Field>
        </div>

        {!configured && <Alert kind="warn" className="mt-4">AI service is not configured yet — you can write your script now; generation works once the administrator connects an audio/TTS provider.</Alert>}

        <Btn className="mt-5 w-full" onClick={onSubmit} loading={submitting} disabled={cooldownLeft > 0 || submitting || tooLong || script.trim().length < 3}>
          <Sparkles size={16} />{cooldownLeft > 0 ? `Cooldown — ${cooldownLeft}s` : "Generate Audio"}
        </Btn>
        <div className="mt-3"><LimitsNote limits={limits} configured={configured} /></div>
      </section>

      <section aria-label="Result" className="flex flex-col gap-4">
        <JobError error={submitError} />
        <JobStatus job={job} submitting={submitting} />
        {job?.status === "completed" && job.result && (
          <>
            {job.result.kind === "audio" ? (
              <MediaResult url={job.result.url!} mime={job.result.mime} kind="audio" />
            ) : job.result.text ? (
              <div className="card whitespace-pre-wrap p-4 text-sm">{job.result.text}</div>
            ) : null}
            <ResultActions prompt={script} url={job.result.url} mime={job.result.mime} regenerate={onSubmit} />
          </>
        )}
        {(!job || job.status === "failed") && !submitting && (
          <div className="grid place-items-center rounded-2xl border border-dashed border-border2 p-10 text-center">
            <div className="max-w-xs text-sm text-faint">Your generated audio will appear here with a player and download button.</div>
          </div>
        )}
      </section>
    </div>
  );
}
