"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Alert, Btn, CopyButton, Spinner } from "@/components/ui";
import { Download, RefreshCw, ExternalLink } from "lucide-react";

export interface JobView {
  id: string;
  tool?: string;
  status: "queued" | "processing" | "completed" | "failed" | "cancelled";
  result: { kind: "text" | "image" | "audio" | "video"; text?: string; url?: string; mime?: string; images?: string[] } | null;
  error: { code: string; message: string } | null;
  createdAt?: string;
  completedAt?: string | null;
}

export interface ToolLimits { dailyLimit: number; cooldownSeconds: number; maxPromptChars: number; maxDurationSeconds: number }

export interface SubmitError { code: string; message: string; retryAfter?: number }

/** Shared generation lifecycle: submit → poll → result/error. */
export function useGenerationJob(slug: string) {
  const [job, setJob] = useState<JobView | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<SubmitError | null>(null);
  const [cooldownLeft, setCooldownLeft] = useState(0);
  const cooldownTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const startCooldown = useCallback((seconds: number) => {
    if (cooldownTimer.current) clearInterval(cooldownTimer.current);
    if (seconds <= 0) return;
    setCooldownLeft(seconds);
    cooldownTimer.current = setInterval(() => {
      setCooldownLeft((s) => {
        if (s <= 1) { if (cooldownTimer.current) clearInterval(cooldownTimer.current); return 0; }
        return s - 1;
      });
    }, 1000);
  }, []);

  useEffect(() => () => { if (cooldownTimer.current) clearInterval(cooldownTimer.current); }, []);

  const poll = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/jobs/${id}`, { cache: "no-store" });
      if (!res.ok) throw new Error("poll failed");
      const data: JobView = await res.json();
      setJob(data);
      return data;
    } catch {
      return null;
    }
  }, []);

  const generate = useCallback(async (params: Record<string, unknown>, cooldownSeconds: number) => {
    setSubmitError(null);
    setSubmitting(true);
    setJob(null);
    try {
      const res = await fetch(`/api/generate/${slug}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setSubmitError({ code: data.code ?? "ERROR", message: data.message ?? "Something went wrong. Please try again.", retryAfter: data.retryAfter });
        if (res.status === 429 && data.retryAfter) startCooldown(Math.min(data.retryAfter, 3600));
        return false;
      }
      startCooldown(cooldownSeconds);
      const id: string = data.jobId;
      // poll until terminal state — resilient to transient network misses,
      // and gives up with a clear message if a job is stuck processing
      let misses = 0;
      const startedAt = Date.now();
      const tick = async () => {
        if (Date.now() - startedAt > 5 * 60_000) {
          setJob({ id, tool: slug, status: "failed", result: null, error: { code: "TIMEOUT", message: "This generation is taking unusually long. Please try again." }, createdAt: new Date().toISOString(), completedAt: new Date().toISOString() });
          return;
        }
        const j = await poll(id);
        if (!j) {
          if (++misses > 8) {
            setJob({ id, tool: slug, status: "failed", result: null, error: { code: "NETWORK", message: "Lost connection to the server. Please check your connection and try again." }, createdAt: new Date().toISOString(), completedAt: new Date().toISOString() });
            return;
          }
          setTimeout(tick, 1800);
          return;
        }
        misses = 0;
        if (j.status === "queued" || j.status === "processing") setTimeout(tick, 1400);
      };
      void tick();
      return true;
    } catch {
      setSubmitError({ code: "NETWORK", message: "Network error — please check your connection and try again." });
      return false;
    } finally {
      setSubmitting(false);
    }
  }, [slug, poll, startCooldown]);

  return { job, submitting, submitError, clearSubmitError: () => setSubmitError(null), generate, cooldownLeft, setJob };
}

/* ── Status / progress banner ────────────────────────────────────── */
export function JobStatus({ job, submitting }: { job: JobView | null; submitting: boolean }) {
  if (submitting) return <StatusLine label="Submitting your generation…" />;
  if (!job) return null;
  if (job.status === "queued") return <StatusLine label="Queued — waiting for a free slot…" />;
  if (job.status === "processing") {
    return (
      <div role="status" aria-live="polite" className="rounded-xl border border-brand/30 bg-brand/5 p-4">
        <div className="mb-2 flex items-center gap-2 text-sm font-medium"><Spinner className="!h-4 !w-4" /> Generating… this can take a moment</div>
        <div className="h-1.5 overflow-hidden rounded-full bg-surface2">
          <div className="h-full w-1/3 animate-shimmer rounded-full bg-gradient-to-r from-brand via-brand2 to-brand" style={{ backgroundSize: "400px 100%" }} />
        </div>
      </div>
    );
  }
  return null;
}
function StatusLine({ label }: { label: string }) {
  return (
    <div role="status" aria-live="polite" className="flex items-center gap-2.5 rounded-xl border border-brand/30 bg-brand/5 p-4 text-sm font-medium">
      <Spinner className="!h-4 !w-4" /> {label}
    </div>
  );
}

export function JobError({ error }: { error: { code: string; message: string } | null }) {
  if (!error) return null;
  const kind = error.code === "NOT_CONFIGURED" ? "warn" : error.code === "RATE_LIMITED" || error.code === "COOLDOWN" || error.code === "TOO_LONG" ? "info" : "danger";
  return <Alert kind={kind as any} title={kind === "warn" ? "AI service is not configured" : undefined}>{error.message}</Alert>;
}

/* ── Result renderers ────────────────────────────────────────────── */
export function ResultActions({ prompt, url, mime, regenerate }: { prompt: string; url?: string; mime?: string; regenerate: () => void }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <CopyButton text={prompt} label="Copy prompt" />
      {url && (
        <a href={url} download className="btn-secondary btn-sm" rel="noopener">
          <Download size={14} /> Download
        </a>
      )}
      <Btn variant="secondary" size="sm" onClick={regenerate}><RefreshCw size={14} /> Regenerate</Btn>
      {url && mime && !mime.startsWith("image/svg") && (
        <a href={url} target="_blank" rel="noopener" className="btn-ghost btn-sm"><ExternalLink size={14} /> Open</a>
      )}
    </div>
  );
}

export function TextResult({ text }: { text: string }) {
  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between border-b border-border bg-surface2/50 px-4 py-2.5">
        <span className="text-xs font-semibold uppercase tracking-wider text-faint">Generated text</span>
        <CopyButton text={text} />
      </div>
      <div className="max-h-[480px] overflow-y-auto whitespace-pre-wrap p-4 text-sm leading-6 text-fg">{text}</div>
    </div>
  );
}

export function MediaResult({ url, mime, kind }: { url: string; mime?: string; kind: "image" | "audio" | "video" }) {
  if (kind === "audio") {
    return (
      <div className="card p-4">
        <audio controls preload="metadata" className="w-full" src={url}>Your browser does not support audio playback.</audio>
      </div>
    );
  }
  const isVideo = (mime ?? "").startsWith("video/");
  if (kind === "video" && isVideo) {
    return (
      <div className="card overflow-hidden">
        <video controls preload="metadata" className="w-full" src={url}>Your browser does not support video playback.</video>
      </div>
    );
  }
  // image (or demo GIF video preview)
  return (
    <div className="card overflow-hidden">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={url} alt="AI generated result" className="w-full" loading="lazy" />
      {kind === "video" && !isVideo && (
        <div className="border-t border-border bg-warn/5 px-4 py-2 text-xs text-warn">
          Demo preview (animated GIF, watermarked) — connect a real video provider for full MP4/WebM video files.
        </div>
      )}
    </div>
  );
}

export function ImageGallery({ urls }: { urls: string[] }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {urls.map((u, i) => (
        <figure key={u + i} className="card group relative overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={u} alt={`Generated image ${i + 1}`} className="w-full transition-transform duration-300 group-hover:scale-[1.02]" loading="lazy" />
          <figcaption className="absolute inset-x-0 bottom-0 flex justify-end gap-2 bg-gradient-to-t from-black/60 to-transparent p-3 opacity-100 transition-opacity sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100">
            <a href={u} download className="btn-secondary btn-sm !bg-surface/90"><Download size={13} /> Download</a>
          </figcaption>
        </figure>
      ))}
    </div>
  );
}

export function LimitsNote({ limits, configured }: { limits: ToolLimits; configured: boolean }) {
  const items = [
    `${limits.dailyLimit} free generations / day`,
    limits.cooldownSeconds > 0 ? `${limits.cooldownSeconds}s cooldown` : null,
    `prompts up to ${limits.maxPromptChars.toLocaleString()} characters`,
  ].filter(Boolean);
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-faint">
      {items.map((t, i) => <span key={i} className="flex items-center gap-1.5"><span className="h-1 w-1 rounded-full bg-brand2" />{t}</span>)}
      <span className={`badge ${configured ? "badge-ok" : "badge-warn"}`}>{configured ? "AI service online" : "AI service not configured"}</span>
    </div>
  );
}
