"use client";
import { useMemo, useState } from "react";
import { Alert, Btn, Field, Select, Textarea } from "@/components/ui";
import { Sparkles } from "lucide-react";
import { JobError, JobStatus, LimitsNote, MediaResult, ResultActions, useGenerationJob, type ToolLimits } from "./job";

export function VideoToolClient({ slug, name, config, limits, configured }: {
  slug: string; name: string; config: any; limits: ToolLimits; configured: boolean;
}) {
  const { job, submitting, submitError, generate, cooldownLeft, clearSubmitError } = useGenerationJob(slug);
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState(config.styles?.[0] ?? "Cinematic");
  const [customStyle, setCustomStyle] = useState("");
  const [aspect, setAspect] = useState(config.aspects?.[0] ?? "16:9");
  const [duration, setDuration] = useState(config.durations?.[0] ?? 5);
  const [quality, setQuality] = useState(config.qualities?.[0] ?? "Standard");
  const [touched, setTouched] = useState(false);

  const tooLong = prompt.length > limits.maxPromptChars;
  const invalid = touched && (prompt.trim().length < 3 || tooLong);
  const durations = useMemo(() => (config.durations ?? [5, 10, 15]).filter((d: number) => d <= limits.maxDurationSeconds), [config.durations, limits.maxDurationSeconds]);
  const finalStyle = style === "Custom" ? customStyle : style;

  const onSubmit = async () => {
    setTouched(true);
    if (prompt.trim().length < 3 || tooLong) return;
    clearSubmitError();
    await generate({ prompt: prompt.trim(), style: finalStyle || "Cinematic", aspect, duration, quality }, limits.cooldownSeconds);
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_1.1fr]">
      <section className="card h-fit p-5 sm:p-6" aria-label={`${name} controls`}>
        <Field label="Prompt" hint={`Describe your video scene. ${prompt.length}/${limits.maxPromptChars} characters`}>
          <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={limits.maxPromptChars + 100}
            placeholder="A drone shot flying over a neon-lit city at night, rain reflections, cinematic mood…"
            aria-invalid={invalid ? true : undefined} aria-describedby="prompt-error" />
        </Field>
        {prompt.trim().length > 0 && prompt.trim().length < 3 && <Alert kind="danger" className="mt-2">Please write a slightly longer prompt.</Alert>}
        {tooLong && <Alert kind="info" className="mt-2">Your request is too long — please keep it under {limits.maxPromptChars.toLocaleString()} characters.</Alert>}

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Style">
            <Select value={style} onChange={(e) => setStyle(e.target.value)}>
              {(config.styles ?? []).map((s: string) => <option key={s} value={s}>{s}</option>)}
            </Select>
          </Field>
          {style === "Custom" ? (
            <Field label="Custom style"><input className="input" value={customStyle} onChange={(e) => setCustomStyle(e.target.value)} placeholder="e.g. Vintage 80s VHS look" /></Field>
          ) : (
            <Field label="Quality">
              <Select value={quality} onChange={(e) => setQuality(e.target.value)}>
                {(config.qualities ?? ["Standard", "High"]).map((q: string) => <option key={q}>{q}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Aspect ratio">
            <div className="flex gap-2" role="radiogroup" aria-label="Aspect ratio">
              {(config.aspects ?? ["16:9"]).map((a: string) => (
                <button key={a} type="button" role="radio" aria-checked={aspect === a} onClick={() => setAspect(a)} className={`chip flex-1 ${aspect === a ? "chip-active" : ""}`}>{a}</button>
              ))}
            </div>
          </Field>
          <Field label={`Duration (max ${limits.maxDurationSeconds}s)`}>
            <div className="flex gap-2" role="radiogroup" aria-label="Duration">
              {durations.map((d: number) => (
                <button key={d} type="button" role="radio" aria-checked={duration === d} onClick={() => setDuration(d)} className={`chip flex-1 ${duration === d ? "chip-active" : ""}`}>{d}s</button>
              ))}
            </div>
          </Field>
        </div>

        {!configured && <Alert kind="warn" className="mt-4">AI service is not configured yet — you can compose and save your prompt now; generation will work once the administrator connects a video provider.</Alert>}

        <Btn className="mt-5 w-full" onClick={onSubmit} loading={submitting}
          disabled={cooldownLeft > 0 || submitting || tooLong || prompt.trim().length < 3}>
          <Sparkles size={16} />{cooldownLeft > 0 ? `Cooldown — ${cooldownLeft}s` : "Generate Video"}
        </Btn>
        <div className="mt-3"><LimitsNote limits={limits} configured={configured} /></div>
      </section>

      <section aria-label="Result" className="flex flex-col gap-4">
        <JobError error={submitError} />
        <JobStatus job={job} submitting={submitting} />
        {job?.status === "completed" && job.result && (
          <>
            <MediaResult url={job.result.url ?? job.result.text ?? ""} mime={job.result.mime} kind="video" />
            <ResultActions prompt={prompt} url={job.result.url} mime={job.result.mime} regenerate={onSubmit} />
          </>
        )}
        {(!job || job.status === "failed") && !submitting && (
          <div className="grid place-items-center rounded-2xl border border-dashed border-border2 p-10 text-center">
            <div className="max-w-xs text-sm text-faint">Your generated video will appear here. Describe a scene on the left and press <span className="font-semibold text-muted">Generate Video</span>.</div>
          </div>
        )}
      </section>
    </div>
  );
}
