import Link from "next/link";
import { ArrowRight, Flame, Star } from "lucide-react";
import { ToolIcon } from "./icon";

export interface ToolCardData {
  name: string; slug: string; tagline: string; icon: string;
  category_name?: string | null; is_featured: number; is_popular: number; is_new: number;
}

export function ToolCard({ tool }: { tool: ToolCardData }) {
  return (
    <Link href={`/tools/${tool.slug}`} className="card-hover group flex flex-col p-5">
      <div className="flex items-start justify-between gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand/15 to-brand2/15 text-brand">
          <ToolIcon name={tool.icon} size={20} />
        </span>
        <span className="flex gap-1.5">
          {tool.is_new ? <span className="badge-new">New</span> : null}
          {tool.is_popular ? <span className="badge-warn"><Flame size={10} /> Popular</span> : null}
          {tool.is_featured ? <span className="badge-brand"><Star size={10} /> Featured</span> : null}
        </span>
      </div>
      <h3 className="mt-4 font-semibold leading-snug group-hover:text-brand">{tool.name}</h3>
      <p className="mt-1.5 line-clamp-2 flex-1 text-sm leading-relaxed text-muted">{tool.tagline}</p>
      <div className="mt-4 flex items-center justify-between">
        {tool.category_name ? <span className="text-[11px] font-semibold uppercase tracking-wider text-faint">{tool.category_name}</span> : <span />}
        <span className="inline-flex items-center gap-1 text-[13px] font-semibold text-brand opacity-0 transition-opacity group-hover:opacity-100">
          Open <ArrowRight size={13} />
        </span>
      </div>
    </Link>
  );
}
