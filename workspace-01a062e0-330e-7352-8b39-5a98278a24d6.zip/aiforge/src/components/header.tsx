"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronDown, Menu, Search, Sparkles, X, Lock, ArrowRight, FileText, FolderOpen, Wrench, Newspaper } from "lucide-react";
import { ThemeToggle } from "./theme";
import { Spinner } from "./ui";

export interface HeaderNav { label: string; url: string; children: { label: string; url: string }[] }
export interface HeaderCta { label: string; url: string; style: string }

export function Header({ siteName, logoUrl, nav, ctas, defaultTheme }: {
  siteName: string; logoUrl?: string; nav: HeaderNav[]; ctas: HeaderCta[]; defaultTheme?: string;
}) {
  const [open, setOpen] = useState(false);          // mobile drawer
  const [moreOpen, setMoreOpen] = useState(false);  // "More Tools" dropdown
  const [q, setQ] = useState("");
  const [results, setResults] = useState<{ title: string; url: string; description: string; type: string }[] | null>(null);
  const [searching, setSearching] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const path = usePathname();

  useEffect(() => { setOpen(false); setMoreOpen(false); setResults(null); }, [path]);
  useEffect(() => {
    const onDoc = (e: MouseEvent) => { if (!searchRef.current?.contains(e.target as Node)) setResults(null); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  useEffect(() => {
    if (q.trim().length < 2) { setResults(null); return; }
    setSearching(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q.trim())}`);
        const json = await res.json();
        setResults(json.results?.slice(0, 6) ?? []);
      } catch { setResults([]); }
      setSearching(false);
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  const typeIcon = (t: string) => t === "tool" ? <Wrench size={13} /> : t === "blog" ? <Newspaper size={13} /> : t === "template" ? <FileText size={13} /> : <FolderOpen size={13} />;

  const primary = nav.filter((n) => n.children.length === 0);
  const withChildren = nav.filter((n) => n.children.length > 0);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-bg/85 backdrop-blur-xl">
      <div className="container-x flex h-16 items-center gap-3">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-bold tracking-tight" aria-label={`${siteName} home`}>
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoUrl} alt={`${siteName} logo`} className="h-8 w-8 rounded-lg object-contain" />
          ) : (
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-brand2 text-white shadow-glow">
              <Sparkles size={16} aria-hidden />
            </span>
          )}
          <span className="hidden text-[17px] sm:block">{siteName}</span>
        </Link>

        {/* Desktop nav */}
        <nav className="ml-4 hidden items-center gap-0.5 xl:flex" aria-label="Main">
          {primary.slice(0, 7).map((item) => (
            <Link key={item.url + item.label} href={item.url}
              className={`rounded-lg px-3 py-2 text-[13.5px] font-medium transition-colors hover:text-brand ${path === item.url ? "text-brand" : "text-muted"}`}>
              {item.label}
            </Link>
          ))}
          {withChildren.map((item) => (
            <div key={item.label} className="relative"
              onMouseEnter={() => setMoreOpen(true)} onMouseLeave={() => setMoreOpen(false)}>
              <button onClick={() => setMoreOpen(!moreOpen)} aria-expanded={moreOpen} aria-haspopup="true"
                className="flex items-center gap-1 rounded-lg px-3 py-2 text-[13.5px] font-medium text-muted transition-colors hover:text-brand">
                {item.label} <ChevronDown size={13} className={`transition-transform ${moreOpen ? "rotate-180" : ""}`} aria-hidden />
              </button>
              {moreOpen && (
                <div className="absolute left-0 top-full w-60 pt-2">
                  <div className="card animate-fade-up p-1.5">
                    {item.children.map((c) => (
                      <Link key={c.url + c.label} href={c.url} className="flex items-center justify-between rounded-lg px-3 py-2 text-[13.5px] font-medium text-muted hover:bg-surface2 hover:text-brand">
                        {c.label} <ArrowRight size={13} className="opacity-40" aria-hidden />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="flex-1" />

        {/* Search */}
        <div ref={searchRef} className="relative hidden w-52 md:block lg:w-64">
          <form action="/search" role="search">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
            <input value={q} onChange={(e) => setQ(e.target.value)} name="q"
              className="input !py-2 !pl-9 !pr-3 !text-[13px]" placeholder="Search tools & articles…" aria-label="Search the site" autoComplete="off" />
          </form>
          {searching && <div className="absolute right-3 top-1/2 -translate-y-1/2"><Spinner className="!h-4 !w-4" /></div>}
          {results && (
            <div className="absolute left-0 top-full z-50 mt-2 w-full min-w-[300px]">
              <div className="card animate-fade-up overflow-hidden p-1.5">
                {results.length === 0 ? (
                  <div className="px-3 py-3 text-[13px] text-muted">No matches for “{q}”</div>
                ) : results.map((r) => (
                  <Link key={r.url + r.title} href={r.url} className="flex items-start gap-2.5 rounded-lg px-3 py-2 hover:bg-surface2">
                    <span className="mt-0.5 text-brand">{typeIcon(r.type)}</span>
                    <span className="min-w-0">
                      <span className="block truncate text-[13px] font-semibold">{r.title}</span>
                      {r.description && <span className="block truncate text-xs text-faint">{r.description}</span>}
                    </span>
                  </Link>
                ))}
                <Link href={`/search?q=${encodeURIComponent(q)}`} className="block rounded-lg px-3 py-2 text-xs font-semibold text-brand hover:bg-surface2">
                  See all results →
                </Link>
              </div>
            </div>
          )}
        </div>

        {/* CTAs */}
        <div className="hidden items-center gap-2 lg:flex">
          {ctas.map((c) => (
            <Link key={c.label} href={c.url} className={c.style === "primary" ? "btn-primary btn-sm !px-4 !py-2.5 !text-[13px]" : "btn-ghost btn-sm !text-[13px]"}>
              {c.style !== "primary" && <Lock size={13} aria-hidden />}
              {c.label}
            </Link>
          ))}
        </div>

        <ThemeToggle defaultTheme={defaultTheme} />

        {/* Mobile hamburger */}
        <button className="btn-ghost !p-2 xl:hidden" onClick={() => setOpen(!open)} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open}>
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile slide-out */}
      {open && (
        <div className="fixed inset-x-0 bottom-0 top-16 z-40 overflow-y-auto border-t border-border bg-bg xl:hidden">
          <div className="container-x flex flex-col gap-1 py-5">
            <form action="/search" className="relative mb-3" role="search">
              <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
              <input name="q" className="input !pl-9" placeholder="Search tools & articles…" aria-label="Search the site" />
            </form>
            {nav.map((item) => (
              <div key={item.label + item.url}>
                <Link href={item.url} className={`flex items-center justify-between rounded-xl px-3 py-3 text-[15px] font-medium hover:bg-surface2 ${path === item.url ? "text-brand" : ""}`}>
                  {item.label} {item.children.length > 0 && <ChevronDown size={15} className="text-faint" aria-hidden />}
                </Link>
                {item.children.length > 0 && (
                  <div className="ml-3 flex flex-col gap-0.5 border-l border-border pl-3">
                    {item.children.map((c) => (
                      <Link key={c.url + c.label} href={c.url} className="rounded-lg px-3 py-2 text-sm text-muted hover:bg-surface2 hover:text-brand">{c.label}</Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="mt-3 flex flex-col gap-2 border-t border-border pt-4">
              {ctas.map((c) => (
                <Link key={c.label} href={c.url} className={c.style === "primary" ? "btn-primary w-full" : "btn-secondary w-full"}>
                  {c.style !== "primary" && <Lock size={14} aria-hidden />} {c.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
