"use client";
import { useEffect } from "react";

/** Registers the service worker in production builds only (opt-in PWA). */
export function SwRegistrar() {
  useEffect(() => {
    if (process.env.NODE_ENV === "production" && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
  }, []);
  return null;
}
