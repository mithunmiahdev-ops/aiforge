import Script from "next/script";
import { getSettings } from "@/server/settings";
import { getDb, get } from "@/db";

/**
 * Policy-compliant ad rendering.
 * - Renders nothing unless the admin enabled ads globally AND this placement.
 * - Test mode renders an outlined placeholder so the admin can verify placement
 *   without serving live ads.
 * - Ads are clearly labeled and never placed inside generation control areas.
 */
export function AdSlot({ placement, currentPath, className = "" }: { placement: string; currentPath?: string; className?: string }) {
  const ads = getSettings("ads");
  if (!ads.enabled || !ads.publisherId.startsWith("ca-pub-")) return null;

  const db = getDb();
  const p = get<{ enabled: number; slot_id: string; format: string; exclude_pages: string; name: string }>(
    db, "SELECT enabled, slot_id, format, exclude_pages, name FROM ad_placements WHERE key = ?", placement
  );
  if (!p || !p.enabled || !p.slot_id) return null;

  let excluded: string[] = [];
  try { excluded = JSON.parse(p.exclude_pages || "[]"); } catch {}
  if (currentPath && excluded.some((prefix) => currentPath.startsWith(prefix))) return null;

  if (ads.testMode) {
    return (
      <div className={`my-6 flex min-h-[90px] items-center justify-center rounded-xl border border-dashed border-border2 bg-surface2/50 text-center ${className}`}
        role="note" aria-label="Ad placement preview">
        <div className="p-4 text-xs text-faint">
          <span className="badge-warn mr-2">Test mode</span>
          Ad placement: {p.name} · slot {p.slot_id}
        </div>
      </div>
    );
  }

  return (
    <div className={`my-6 ${className}`}>
      <div className="mb-1 text-center text-[10px] uppercase tracking-widest text-faint">Advertisement</div>
      <div className="overflow-hidden rounded-xl border border-border bg-surface2/40">
        <Script id={`adsense-${placement}`} src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ads.publisherId}"
          crossOrigin="anonymous" strategy="afterInteractive" />
        <ins className="adsbygoogle block" style={{ display: "block", minHeight: 90 }}
          data-ad-client={ads.publisherId} data-ad-slot={p.slot_id}
          data-ad-format={p.format === "vertical" ? "vertical" : "auto"}
          data-full-width-responsive={p.format !== "vertical" ? "true" : "false"} />
        <Script id={`adsense-push-${placement}`} strategy="afterInteractive">{`(adsbygoogle = window.adsbygoogle || []).push({});`}</Script>
      </div>
    </div>
  );
}
