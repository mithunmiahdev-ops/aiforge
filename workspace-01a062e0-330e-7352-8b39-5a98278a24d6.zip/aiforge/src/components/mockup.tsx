import { Play, Download, Sparkles, Wand2, ImageIcon, Video, AudioLines } from "lucide-react";

/** Pure CSS/SVG product illustration of the generation interface (not real data). */
export function HeroMockup() {
  return (
    <div className="relative" aria-hidden>
      <div className="card relative overflow-hidden !rounded-2xl p-0 shadow-glow">
        {/* window chrome */}
        <div className="flex items-center gap-1.5 border-b border-border bg-surface2/60 px-4 py-2.5">
          <span className="h-2.5 w-2.5 rounded-full bg-danger/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-warn/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-ok/70" />
          <span className="ml-3 rounded-md bg-surface px-3 py-1 text-[10px] font-medium text-faint">aivideo — generate</span>
        </div>

        <div className="space-y-4 p-4 sm:p-5">
          {/* prompt bar */}
          <div className="flex items-center gap-2.5 rounded-xl border border-border2 bg-surface2 px-3.5 py-3">
            <Wand2 size={15} className="shrink-0 text-brand" />
            <div className="h-2 w-full max-w-[58%] rounded-full bg-fg/20" />
            <div className="h-2 w-[14%] rounded-full bg-fg/10" />
            <span className="ml-auto flex h-7 shrink-0 items-center gap-1 rounded-lg bg-gradient-to-r from-brand to-brand2 px-2.5 text-[10px] font-bold text-white">
              <Sparkles size={11} /> Generate
            </span>
          </div>

          {/* option chips */}
          <div className="flex flex-wrap gap-1.5">
            {["Cinematic", "16:9", "10s", "High"].map((c, i) => (
              <span key={c} className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${i === 0 ? "bg-brand/15 text-brand" : "bg-surface2 text-faint"}`}>{c}</span>
            ))}
          </div>

          {/* progress */}
          <div>
            <div className="mb-1.5 flex items-center justify-between text-[10px] font-medium text-faint">
              <span className="flex items-center gap-1"><Video size={11} className="text-brand2" /> Generating video…</span>
              <span>87%</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-surface2">
              <div className="h-full w-[87%] rounded-full bg-gradient-to-r from-brand to-brand2" />
            </div>
          </div>

          {/* results grid */}
          <div className="grid grid-cols-4 gap-2.5">
            {[
              { cls: "from-violet-500/70 to-fuchsia-500/50", Ico: Video },
              { cls: "from-cyan-400/60 to-blue-500/50", Ico: ImageIcon },
              { cls: "from-emerald-400/50 to-teal-500/40", Ico: AudioLines },
              { cls: "from-amber-400/50 to-orange-500/40", Ico: Play },
            ].map(({ cls, Ico }, i) => (
              <div key={i} className={`relative aspect-square overflow-hidden rounded-xl bg-gradient-to-br ${cls}`}>
                <Ico size={16} className="absolute left-2 top-2 text-white/80" />
                {i === 3 && (
                  <span className="absolute bottom-1.5 right-1.5 grid h-5 w-5 place-items-center rounded-md bg-black/40 text-white backdrop-blur">
                    <Download size={10} />
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* floating chips */}
      <div className="animate-float absolute -left-4 -top-5 hidden rounded-xl border border-border bg-surface px-3.5 py-2.5 shadow-card sm:block">
        <div className="flex items-center gap-2 text-xs font-semibold"><ImageIcon size={13} className="text-brand2" /> Image ready</div>
        <div className="mt-1 text-[10px] text-faint">4 variants · 1024²</div>
      </div>
      <div className="animate-float absolute -bottom-5 -right-3 hidden rounded-xl border border-border bg-surface px-3.5 py-2.5 shadow-card sm:block" style={{ animationDelay: "1.4s" }}>
        <div className="flex items-center gap-2 text-xs font-semibold"><AudioLines size={13} className="text-brand" /> Voiceover generated</div>
        <div className="mt-1 text-[10px] text-faint">English · 32s</div>
      </div>
    </div>
  );
}
