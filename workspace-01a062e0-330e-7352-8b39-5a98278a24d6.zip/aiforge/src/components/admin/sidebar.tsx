"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, Globe, Home, Menu as MenuIcon, Wrench, FolderTree, Plug, FileCode2,
  Newspaper, Image as ImageIcon, Search, Megaphone, BarChart3, Users, Activity, ScrollText,
  Scale, Settings, ShieldCheck, Cpu, ChevronDown, LogOut, Sparkles, ExternalLink,
} from "lucide-react";

const GROUPS: { label: string; items: { href: string; label: string; icon: any }[] }[] = [
  { label: "Overview", items: [{ href: "/admin", label: "Dashboard", icon: LayoutDashboard }] },
  {
    label: "Website",
    items: [
      { href: "/admin/website", label: "Site & Branding", icon: Globe },
      { href: "/admin/homepage", label: "Homepage", icon: Home },
      { href: "/admin/navigation", label: "Navigation", icon: MenuIcon },
      { href: "/admin/legal", label: "Legal Pages", icon: Scale },
    ],
  },
  {
    label: "AI",
    items: [
      { href: "/admin/tools", label: "AI Tools", icon: Wrench },
      { href: "/admin/categories", label: "Tool Categories", icon: FolderTree },
      { href: "/admin/providers", label: "AI Providers", icon: Plug },
      { href: "/admin/usage", label: "Usage & Jobs", icon: Activity },
    ],
  },
  {
    label: "Content",
    items: [
      { href: "/admin/blog", label: "Blog", icon: Newspaper },
      { href: "/admin/media", label: "Media Library", icon: ImageIcon },
      { href: "/admin/templates", label: "Prompt Templates", icon: FileCode2 },
      { href: "/admin/faqs", label: "FAQs", icon: ScrollText },
    ],
  },
  {
    label: "Growth",
    items: [
      { href: "/admin/seo", label: "SEO", icon: Search },
      { href: "/admin/ads", label: "Ads (AdSense)", icon: Megaphone },
      { href: "/admin/analytics", label: "Analytics", icon: BarChart3 },
    ],
  },
  {
    label: "System",
    items: [
      { href: "/admin/users", label: "Admins & Roles", icon: Users },
      { href: "/admin/logs", label: "Audit Logs", icon: ScrollText },
      { href: "/admin/security", label: "Security", icon: ShieldCheck },
      { href: "/admin/settings", label: "General Settings", icon: Settings },
      { href: "/admin/system", label: "System Status", icon: Cpu },
    ],
  },
];

export function AdminSidebar({ userName, userRole, siteName, logout }: {
  userName: string; userRole: string; siteName: string;
  logout: () => Promise<void>;
}) {
  const path = usePathname();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    for (const g of GROUPS) {
      const open = g.items.some((i) => i.href === path);
      if (!open && g.label !== "Overview") init[g.label] = true;
    }
    return init;
  });

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-border bg-surface" aria-label="Admin navigation">
      <div className="flex h-16 items-center gap-2 border-b border-border px-5">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-brand2 text-white"><Sparkles size={15} aria-hidden /></span>
        <div className="min-w-0">
          <div className="truncate text-sm font-bold">{siteName}</div>
          <div className="text-[10px] uppercase tracking-widest text-faint">Admin Panel</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {GROUPS.map((group) => {
          const isCollapsed = collapsed[group.label];
          const groupActive = group.items.some((i) => i.href === path);
          return (
            <div key={group.label} className="mb-1">
              {group.label !== "Overview" ? (
                <button onClick={() => setCollapsed((c) => ({ ...c, [group.label]: !c[group.label] }))}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-[11px] font-bold uppercase tracking-wider transition-colors ${groupActive ? "text-brand" : "text-faint"} hover:text-muted`}
                  aria-expanded={!isCollapsed}>
                  {group.label}
                  <ChevronDown size={13} className={`transition-transform ${isCollapsed ? "-rotate-90" : ""}`} aria-hidden />
                </button>
              ) : (
                <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-faint">{group.label}</div>
              )}
              {!isCollapsed && (
                <div className="mb-2 flex flex-col gap-0.5">
                  {group.items.map((item) => {
                    const active = item.href === path;
                    const Icon = item.icon;
                    return (
                      <Link key={item.href} href={item.href}
                        className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors ${
                          active ? "bg-brand/10 text-brand" : "text-muted hover:bg-surface2 hover:text-fg"}`}
                        aria-current={active ? "page" : undefined}>
                        <Icon size={15} aria-hidden /> {item.label}
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="border-t border-border p-3">
        <Link href="/" target="_blank" className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs text-muted hover:bg-surface2 hover:text-fg">
          <ExternalLink size={13} aria-hidden /> View live site
        </Link>
        <div className="mt-1 flex items-center justify-between rounded-lg px-3 py-2">
          <div className="min-w-0">
            <div className="truncate text-xs font-semibold">{userName}</div>
            <div className="text-[10px] text-faint">{userRole}</div>
          </div>
          <form action={logout}>
            <button type="submit" className="btn-ghost !p-2" aria-label="Log out" title="Log out">
              <LogOut size={15} aria-hidden />
            </button>
          </form>
        </div>
      </div>
    </aside>
  );
}
