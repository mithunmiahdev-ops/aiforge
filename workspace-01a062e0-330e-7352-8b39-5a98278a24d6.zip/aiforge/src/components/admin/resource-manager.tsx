"use client";
import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Alert, Btn, Field, Input, Modal, Select, Textarea, Toggle } from "@/components/ui";
import type { FieldDef } from "@/server/resources";
import { Pencil, Plus, Search, Trash2, Loader2 } from "lucide-react";

export interface ClientResourceDef {
  key: string; label: string; singular: string; fields: FieldDef[]; hasTransform?: boolean;
}
type Row = Record<string, any>;

export function ResourceManager({ def, rows, save, del, canDelete = true }: {
  def: ClientResourceDef;
  rows: Row[];
  save: (resourceKey: string, formData: FormData) => Promise<{ ok: boolean; message: string }>;
  del: (resourceKey: string, id: number) => Promise<{ ok: boolean; message: string }>;
  canDelete?: boolean;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState<Row | "new" | null>(null);
  const [deleting, setDeleting] = useState<Row | null>(null);
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const [search, setSearch] = useState("");
  const [pending, startTransition] = useTransition();

  const filtered = useMemo(() => {
    if (!search.trim()) return rows;
    const q = search.toLowerCase();
    return rows.filter((r) => Object.values(r).some((v) => String(v ?? "").toLowerCase().includes(q)));
  }, [rows, search]);

  const tableFields = def.fields.filter((f) => f.inTable).slice(0, 5);

  const onSubmit = async (formData: FormData) => {
    const result = await save(def.key, formData);
    setFeedback(result);
    if (result.ok) { setEditing(null); startTransition(() => router.refresh()); }
    return result;
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    const result = await del(def.key, Number(deleting.id));
    setFeedback(result);
    setDeleting(null);
    if (result.ok) startTransition(() => router.refresh());
  };

  return (
    <div>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={`Search ${def.label.toLowerCase()}…`} className="!pl-9" aria-label={`Search ${def.label}`} />
        </div>
        <Btn onClick={() => setEditing("new")}><Plus size={16} /> New {def.singular}</Btn>
      </div>

      {feedback && <div className="mb-4"><Alert kind={feedback.ok ? "success" : "danger"}>{feedback.message}</Alert></div>}

      <div className="card overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead>
            <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-faint">
              {tableFields.map((f) => <th key={f.name} className="px-4 py-3 font-semibold">{f.label}</th>)}
              <th className="px-4 py-3 text-right font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={tableFields.length + 1} className="px-4 py-10 text-center text-muted">
                No {def.label.toLowerCase()} found. {search ? "Try a different search." : `Click “New ${def.singular}” to create one.`}
              </td></tr>
            )}
            {filtered.map((row) => (
              <tr key={row.id} className="border-b border-border/60 last:border-0 hover:bg-surface2/40">
                {tableFields.map((f) => (
                  <td key={f.name} className="max-w-[260px] px-4 py-3">
                    {f.type === "boolean" ? (
                      <span className={row[f.name] ? "badge-ok" : "badge !bg-surface2 !text-faint"}>{row[f.name] ? "Yes" : "No"}</span>
                    ) : (
                      <span className="block truncate text-muted" title={String(row[f.name] ?? "")}>{String(row[f.name] ?? "") || <span className="text-faint">—</span>}</span>
                    )}
                  </td>
                ))}
                <td className="whitespace-nowrap px-4 py-3 text-right">
                  <button onClick={() => setEditing(row)} className="btn-ghost btn-sm mr-1" aria-label={`Edit ${row.name ?? row.label ?? row.id}`}><Pencil size={14} /></button>
                  {canDelete && <button onClick={() => setDeleting(row)} className="btn-danger btn-sm" aria-label={`Delete ${row.name ?? row.label ?? row.id}`}><Trash2 size={14} /></button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-faint">{filtered.length} item{filtered.length === 1 ? "" : "s"}</p>

      {/* editor modal */}
      <Modal open={editing !== null} onClose={() => setEditing(null)} title={editing === "new" ? `New ${def.singular}` : `Edit ${def.singular}`} wide>
        {editing !== null && (
          <ResourceForm def={def} row={editing === "new" ? null : editing} onSubmit={onSubmit} onCancel={() => setEditing(null)} />
        )}
      </Modal>

      {/* delete confirm */}
      <Modal open={deleting !== null} onClose={() => setDeleting(null)} title={`Delete ${def.singular}`}>
        <p className="text-sm text-muted">
          Delete <span className="font-semibold text-fg">{String(deleting?.name ?? deleting?.label ?? deleting?.title ?? deleting?.slug ?? deleting?.key ?? "")}</span>? This cannot be undone.
        </p>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setDeleting(null)}>Cancel</Btn>
          <Btn variant="danger" onClick={confirmDelete} disabled={pending}>{pending ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />} Delete</Btn>
        </div>
      </Modal>
    </div>
  );
}

function ResourceForm({ def, row, onSubmit, onCancel }: {
  def: ClientResourceDef; row: Row | null;
  onSubmit: (formData: FormData) => Promise<{ ok: boolean; message: string }>;
  onCancel: () => void;
}) {
  const [values, setValues] = useState<Record<string, any>>(() => {
    const init: Record<string, any> = {};
    for (const f of def.fields) {
      if (f.type === "password") init[f.name] = "";
      else if (f.type === "boolean") init[f.name] = row ? Number(row[f.name]) === 1 : f.name === "enabled" ? 1 : 0;
      else if (f.type === "json") init[f.name] = row ? pretty(row[f.name]) : f.name === "exclude_pages" || f.name === "content" && false ? "{}" : "{}";
      else if (f.type === "number") init[f.name] = row?.[f.name] ?? (f.min ?? 0);
      else init[f.name] = row?.[f.name] ?? (f.options?.length && !f.optional ? f.options[0].value : "");
    }
    return init;
  });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const set = (name: string, value: any) => setValues((v) => ({ ...v, [name]: value }));

  const submit = async () => {
    setError(null);
    const fd = new FormData();
    if (row?.id) fd.set("__id", String(row.id));
    for (const f of def.fields) {
      const v = values[f.name];
      if (f.type === "boolean") { if (v) fd.set(f.name, "on"); }
      else fd.set(f.name, v ?? "");
    }
    setSaving(true);
    const result = await onSubmit(fd);
    setSaving(false);
    if (!result.ok) setError(result.message);
  };

  return (
    <form onSubmit={(e) => { e.preventDefault(); void submit(); }}>
      <div className="grid gap-4 sm:grid-cols-2">
        {def.fields.map((f) => (
          <div key={f.name} className={f.half ? "" : "sm:col-span-2"}>
            {f.type === "boolean" ? (
              <div className="flex items-center justify-between rounded-xl border border-border bg-surface2/40 px-4 py-3">
                <div>
                  <div className="text-sm font-semibold">{f.label}</div>
                  {f.hint && <div className="text-xs text-faint">{f.hint}</div>}
                </div>
                <Toggle checked={!!values[f.name]} onChange={(v) => set(f.name, v ? 1 : 0)} label={f.label} />
              </div>
            ) : (
              <Field label={f.label + (f.required ? " *" : "")} hint={f.hint}>
                {f.type === "select" ? (
                  <Select value={String(values[f.name] ?? "")} onChange={(e) => set(f.name, e.target.value)}>
                    {f.optional && <option value="">— none —</option>}
                    {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </Select>
                ) : f.type === "textarea" || f.type === "md" ? (
                  <Textarea className={f.type === "md" ? "!min-h-[200px] font-mono !text-[13px]" : ""} value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
                ) : f.type === "json" ? (
                  <Textarea className="!min-h-[140px] font-mono !text-[13px]" value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} spellCheck={false} />
                ) : f.type === "password" ? (
                  <Input type="password" value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} autoComplete="new-password" />
                ) : f.type === "number" ? (
                  <Input type="number" value={values[f.name] ?? 0} min={f.min} max={f.max} onChange={(e) => set(f.name, e.target.value)} />
                ) : (
                  <Input value={values[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
                )}
              </Field>
            )}
          </div>
        ))}
      </div>
      {error && <div className="mt-4"><Alert kind="danger">{error}</Alert></div>}
      <div className="mt-6 flex justify-end gap-2">
        <Btn variant="ghost" type="button" onClick={onCancel}>Cancel</Btn>
        <Btn type="submit" loading={saving}>Save {def.singular}</Btn>
      </div>
    </form>
  );
}

function pretty(v: any): string {
  if (v == null || v === "") return "{}";
  const s = String(v);
  try { return JSON.stringify(JSON.parse(s), null, 2); } catch { return s; }
}
