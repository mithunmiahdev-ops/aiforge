"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Alert, Btn, Field, Input, Select, Textarea, Toggle } from "@/components/ui";
import { Save } from "lucide-react";

export interface SettingsField {
  name: string; label: string;
  type: "text" | "textarea" | "password" | "number" | "color" | "toggle" | "select" | "json";
  options?: { value: string; label: string }[];
  hint?: string; placeholder?: string; half?: boolean; min?: number;
}

export function SettingsForm({ group, title, description, fields, values, save }: {
  group: string; title: string; description?: string;
  fields: SettingsField[];
  values: Record<string, any>;
  save: (group: string, formData: FormData) => Promise<{ ok: boolean; message: string }>;
}) {
  const router = useRouter();
  const [state, setValues] = useState<Record<string, any>>(() => {
    const init: Record<string, any> = {};
    for (const f of fields) init[f.name] = values[f.name] ?? (f.type === "toggle" ? false : "");
    return init;
  });
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [, startTransition] = useTransition();

  const set = (name: string, value: any) => setValues((v) => ({ ...v, [name]: value }));

  const onSubmit = async () => {
    setSaving(true);
    const fd = new FormData();
    for (const f of fields) {
      if (f.type === "toggle") { if (state[f.name]) fd.set(`__bool__${f.name}`, "1"); }
      else if (f.type === "json") {
        try { JSON.parse(state[f.name] || "{}"); } catch { setFeedback({ ok: false, message: `${f.label}: invalid JSON.` }); setSaving(false); return; }
        fd.set(f.name, state[f.name]);
      }
      else fd.set(f.name, state[f.name] ?? "");
    }
    const result = await save(group, fd);
    setFeedback(result);
    setSaving(false);
    if (result.ok) startTransition(() => router.refresh());
  };

  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }}>
      <div className="mb-6">
        <h1 className="text-xl font-bold tracking-tight">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted">{description}</p>}
      </div>
      {feedback && <div className="mb-4"><Alert kind={feedback.ok ? "success" : "danger"}>{feedback.message}</Alert></div>}

      <div className="card grid gap-5 p-6 sm:grid-cols-2">
        {fields.map((f) => (
          <div key={f.name} className={f.half ? "" : "sm:col-span-2"}>
            {f.type === "toggle" ? (
              <div className="flex items-center justify-between rounded-xl border border-border bg-surface2/40 px-4 py-3">
                <div><div className="text-sm font-semibold">{f.label}</div>{f.hint && <div className="text-xs text-faint">{f.hint}</div>}</div>
                <Toggle checked={!!state[f.name]} onChange={(v) => set(f.name, v)} label={f.label} />
              </div>
            ) : (
              <Field label={f.label} hint={f.hint}>
                {f.type === "textarea" ? (
                  <Textarea value={state[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
                ) : f.type === "json" ? (
                  <Textarea className="!min-h-[160px] font-mono !text-[13px]" value={state[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} spellCheck={false} />
                ) : f.type === "select" ? (
                  <Select value={String(state[f.name] ?? "")} onChange={(e) => set(f.name, e.target.value)}>
                    {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </Select>
                ) : f.type === "number" ? (
                  <Input type="number" min={f.min} value={state[f.name] ?? 0} onChange={(e) => set(f.name, e.target.value)} />
                ) : f.type === "password" ? (
                  <Input type="password" value={state[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} autoComplete="new-password" />
                ) : f.type === "color" ? (
                  <div className="flex items-center gap-3">
                    <input type="color" className="h-10 w-14 cursor-pointer rounded-lg border border-border bg-surface2"
                      value={rgbToHex(String(state[f.name] ?? "109 94 252"))}
                      onChange={(e) => set(f.name, hexToRgb(e.target.value))} aria-label={f.label} />
                    <Input value={state[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder="109 94 252" />
                  </div>
                ) : (
                  <Input value={state[f.name] ?? ""} onChange={(e) => set(f.name, e.target.value)} placeholder={f.placeholder} />
                )}
              </Field>
            )}
          </div>
        ))}
      </div>
      <div className="mt-5">
        <Btn type="submit" loading={saving}><Save size={15} /> Save changes</Btn>
      </div>
    </form>
  );
}

function rgbToHex(rgb: string): string {
  const [r, g, b] = rgb.split(/\s+/).map((n) => Number(n) || 0);
  return "#" + [r, g, b].map((n) => Math.min(255, Math.max(0, n)).toString(16).padStart(2, "0")).join("");
}
function hexToRgb(hex: string): string {
  const m = hex.match(/^#?([0-9a-f]{6})$/i);
  if (!m) return hex;
  const n = parseInt(m[1], 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}
