import type { MetadataRoute } from "next";
import { getDb, all } from "@/db";
import { getTools, getBlogCategories } from "@/server/cms";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = (process.env.PUBLIC_BASE_URL || "http://localhost:3000").replace(/\/$/, "");
  const db = getDb();
  const now = new Date();

  const entries: MetadataRoute.Sitemap = [
    { url: base, lastModified: now, changeFrequency: "daily", priority: 1 },
    { url: `${base}/tools`, lastModified: now, changeFrequency: "daily", priority: 0.9 },
    { url: `${base}/blog`, lastModified: now, changeFrequency: "daily", priority: 0.8 },
    { url: `${base}/pricing`, changeFrequency: "monthly", priority: 0.5 },
    { url: `${base}/about`, changeFrequency: "monthly", priority: 0.4 },
    { url: `${base}/contact`, changeFrequency: "yearly", priority: 0.3 },
  ];

  for (const tool of getTools()) {
    if (tool.noindex) continue;
    entries.push({ url: `${base}/tools/${tool.slug}`, lastModified: now, changeFrequency: "weekly", priority: 0.9 });
  }
  for (const cat of getBlogCategories()) {
    entries.push({ url: `${base}/blog/category/${cat.slug}`, lastModified: now, changeFrequency: "weekly", priority: 0.6 });
  }
  for (const post of all<{ slug: string; updated_at: string; noindex: number }>(db, "SELECT slug, updated_at, noindex, published_at, created_at FROM blog_posts WHERE status='published' AND COALESCE(publish_at, published_at, created_at, '9999') <= datetime('now')")) {
    if (post.noindex) continue;
    entries.push({ url: `${base}/blog/${post.slug}`, lastModified: new Date(post.updated_at + "Z"), changeFrequency: "monthly", priority: 0.7 });
  }
  for (const page of all<{ slug: string; noindex: number }>(db, "SELECT slug, noindex FROM pages WHERE enabled = 1")) {
    if (page.noindex) continue;
    entries.push({ url: `${base}/${page.slug}`, lastModified: now, changeFrequency: "monthly", priority: 0.3 });
  }
  return entries;
}
