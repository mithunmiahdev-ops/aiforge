import type { MetadataRoute } from "next";
import { getSettings } from "@/server/settings";

export default function manifest(): MetadataRoute.Manifest {
  const site = getSettings("site");
  return {
    name: `${site.siteName} — ${site.tagline}`,
    short_name: site.siteName,
    description: site.description,
    start_url: "/?utm_source=pwa",
    display: "standalone",
    background_color: "#090a12",
    theme_color: "#090a12",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
    ],
  };
}
