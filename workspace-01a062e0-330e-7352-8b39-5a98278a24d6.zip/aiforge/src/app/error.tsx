"use client";
import { Btn } from "@/components/ui";
import { AlertTriangle } from "lucide-react";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="grid min-h-[70vh] place-items-center px-6 text-center">
      <div>
        <div className="mx-auto mb-6 grid h-16 w-16 place-items-center rounded-2xl bg-warn/10 text-warn"><AlertTriangle size={28} aria-hidden /></div>
        <h1 className="text-2xl font-black tracking-tight sm:text-3xl">Something went wrong</h1>
        <p className="mx-auto mt-3 max-w-sm text-muted">An unexpected error occurred. Please try again — if it keeps happening, come back a little later.</p>
        <Btn className="mt-8" onClick={reset}>Try again</Btn>
      </div>
    </div>
  );
}
