import Link from "next/link";
import { Compass } from "lucide-react";

export default function NotFound() {
  return (
    <div className="grid min-h-[70vh] place-items-center px-6 text-center">
      <div>
        <div className="mx-auto mb-6 grid h-16 w-16 place-items-center rounded-2xl bg-brand/10 text-brand"><Compass size={28} aria-hidden /></div>
        <p className="gradient-text text-sm font-bold uppercase tracking-widest">404</p>
        <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Page not found</h1>
        <p className="mx-auto mt-3 max-w-sm text-muted">The page you're looking for doesn't exist or may have moved.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/" className="btn-primary">Back to home</Link>
          <Link href="/tools" className="btn-secondary">Browse AI tools</Link>
        </div>
      </div>
    </div>
  );
}
