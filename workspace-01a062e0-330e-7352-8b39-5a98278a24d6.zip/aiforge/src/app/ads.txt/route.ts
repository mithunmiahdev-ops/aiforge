import { NextResponse } from "next/server";
import { getSettings } from "@/server/settings";

/** Authorized Digital Sellers file — generated from AdSense settings. */
export async function GET() {
  const ads = getSettings("ads");
  if (!ads.enabled || !ads.publisherId.startsWith("ca-pub-")) {
    return new NextResponse("", { headers: { "Content-Type": "text/plain; charset=utf-8" } });
  }
  const body = `google.com, ${ads.publisherId.replace("ca-pub-", "pub-")}, DIRECT, f08c47fec0942fa0\n`;
  return new NextResponse(body, { headers: { "Content-Type": "text/plain; charset=utf-8" } });
}
