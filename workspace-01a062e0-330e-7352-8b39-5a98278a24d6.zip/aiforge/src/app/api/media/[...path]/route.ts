import { NextRequest, NextResponse } from "next/server";
import { readStoredFile, mimeFor } from "@/server/storage";

export const dynamic = "force-dynamic";

/** GET /api/media/[subdir]/[filename] — serves stored media (uploads + generated assets). */
export async function GET(_req: NextRequest, { params }: { params: { path: string[] } }) {
  const [subdir, filename] = params.path;
  if (!subdir || !filename) return new NextResponse("Not found", { status: 404 });
  const file = readStoredFile(subdir, filename);
  if (!file) return new NextResponse("Not found", { status: 404 });
  const ext = filename.split(".").pop() ?? "";
  return new NextResponse(new Uint8Array(file), {
    headers: {
      "Content-Type": mimeFor(ext),
      "Content-Length": String(file.length),
      "X-Content-Type-Options": "nosniff",
    },
  });
}
