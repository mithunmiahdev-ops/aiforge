import { NextRequest, NextResponse } from "next/server";
import sharp from "sharp";
import { getDb, run } from "@/db";
import { getAdminUser, requestIp } from "@/server/auth";
import { logEvent } from "@/server/audit";
import { saveBuffer } from "@/server/storage";
import { uuid } from "@/server/crypto";

export const dynamic = "force-dynamic";
const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

/** POST /api/media/upload — admin-only media upload with sharp optimization. */
export async function POST(req: NextRequest) {
  const user = getAdminUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "No file provided" }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: "File too large (max 8 MB)" }, { status: 413 });
  if (!ALLOWED.has(file.type)) return NextResponse.json({ error: "Only JPEG, PNG, WebP and GIF are allowed" }, { status: 415 });

  const buf = Buffer.from(await file.arrayBuffer());
  let url: string, mime: string, width = 0, height = 0;

  if (file.type === "image/gif") {
    // keep GIFs intact (sharp would drop animation)
    url = saveBuffer(buf, "gif", "uploads");
    mime = "image/gif";
  } else {
    const optimized = await sharp(buf).rotate().resize(1920, 1920, { fit: "inside", withoutEnlargement: true }).webp({ quality: 82 }).toBuffer({ resolveWithObject: true });
    url = saveBuffer(optimized.data, "webp", "uploads");
    mime = "image/webp";
    width = optimized.info.width;
    height = optimized.info.height;
  }

  const db = getDb();
  const filename = url.split("/").pop()!;
  run(db, "INSERT INTO media (filename, original_name, path, mime, size, width, height) VALUES (?,?,?,?,?,?,?)",
    filename, file.name.slice(0, 200), url, mime, buf.length, width, height);

  logEvent({ type: "admin_action", actor: user.email, action: "media.upload", object: filename, ip: await requestIp() });
  return NextResponse.json({ url, filename, width, height });
}
