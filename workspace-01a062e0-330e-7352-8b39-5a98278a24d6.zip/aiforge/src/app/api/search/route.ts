import { NextRequest, NextResponse } from "next/server";
import { searchAll } from "@/server/cms";

export const dynamic = "force-dynamic";

/** GET /api/search?q= — autocomplete endpoint (tools, blog, categories, templates). */
export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get("q") ?? "").trim();
  if (q.length < 2) return NextResponse.json({ results: [] });
  const results = searchAll(q.slice(0, 80), 5);
  return NextResponse.json({ results }, { headers: { "Cache-Control": "public, max-age=30" } });
}
