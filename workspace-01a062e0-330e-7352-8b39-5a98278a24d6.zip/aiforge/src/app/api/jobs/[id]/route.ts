import { NextRequest, NextResponse } from "next/server";
import { getDb, get } from "@/db";
import { publicJob, type JobRow } from "@/server/jobs";

export const dynamic = "force-dynamic";

/** GET /api/jobs/[id] — poll job status. Only the owning anonymous session can read it. */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const anon = req.cookies.get("aiforge_anon")?.value ?? "";
  if (!/^[0-9a-f-]{36}$/i.test(params.id)) {
    return NextResponse.json({ code: "INVALID", message: "Invalid job id." }, { status: 400 });
  }
  const db = getDb();
  const job = get<JobRow>(db, "SELECT * FROM generation_jobs WHERE id = ?", params.id);
  if (!job) return NextResponse.json({ code: "NOT_FOUND", message: "Job not found." }, { status: 404 });
  const view = publicJob(job, anon);
  if (!view) return NextResponse.json({ code: "NOT_FOUND", message: "Job not found." }, { status: 404 });
  return NextResponse.json(view, { headers: { "Cache-Control": "no-store" } });
}
