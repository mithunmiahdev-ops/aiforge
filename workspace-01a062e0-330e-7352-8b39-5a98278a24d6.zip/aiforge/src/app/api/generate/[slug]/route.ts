import { NextRequest, NextResponse } from "next/server";
import { getToolBySlug, parseToolConfig } from "@/server/cms";
import { getSettings } from "@/server/settings";
import { checkRate } from "@/server/ratelimit";
import { createJob, processJobAsync, healStuckJobs } from "@/server/jobs";
import { uuid } from "@/server/crypto";

export const dynamic = "force-dynamic";

const ANON_COOKIE = "aiforge_anon";

/** POST /api/generate/[slug] — anonymous generation with server-side limits. */
export async function POST(req: NextRequest, { params }: { params: { slug: string } }) {
  healStuckJobs();
  const ip = (req.headers.get("x-forwarded-for") || "").split(",")[0].trim() || "local";

  // Same-origin check for mutation (CSRF defense)
  const origin = req.headers.get("origin");
  const host = req.headers.get("host");
  if (origin && host && !origin.endsWith(host)) {
    return NextResponse.json({ code: "INVALID", message: "Invalid request origin." }, { status: 403 });
  }

  const system = getSettings("system");
  if (system.maintenanceOn) {
    return NextResponse.json({ code: "MAINTENANCE", message: "The service is temporarily in maintenance. Please check back soon." }, { status: 503 });
  }

  const tool = getToolBySlug(params.slug);
  if (!tool) {
    return NextResponse.json({ code: "NOT_FOUND", message: "This tool does not exist." }, { status: 404 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ code: "INVALID", message: "Invalid request body." }, { status: 400 });
  }

  // ── Server-side validation (never trust the client) ──
  const prompt = String(body.prompt ?? body.topic ?? "").trim();
  const config = parseToolConfig(tool);
  const security = getSettings("security");

  if (prompt.length < 3) {
    return NextResponse.json({ code: "INVALID", message: "Please describe what you want to create." }, { status: 400 });
  }
  if (prompt.length > tool.max_prompt_chars) {
    return NextResponse.json({ code: "TOO_LONG", message: `Your request is too long — please keep it under ${tool.max_prompt_chars.toLocaleString()} characters.` }, { status: 413 });
  }
  const duration = Number(body.duration) || 0;
  if (duration > tool.max_duration_seconds) {
    return NextResponse.json({ code: "INVALID", message: `Duration exceeds the maximum of ${tool.max_duration_seconds}s.` }, { status: 400 });
  }
  const allowedAspects: string[] = (tool.type === "video" ? config.aspects : tool.type === "image" ? config.aspects : []);
  const aspect = String(body.aspect ?? "");
  if (allowedAspects.length > 0 && aspect && !allowedAspects.includes(aspect)) {
    return NextResponse.json({ code: "INVALID", message: "Invalid aspect ratio." }, { status: 400 });
  }
  const count = Number(body.count) || 1;
  if (tool.type === "image" && (count < 1 || count > Math.min(config.maxImages ?? 4, 4))) {
    return NextResponse.json({ code: "INVALID", message: "Invalid image count." }, { status: 400 });
  }

  // sanitize params copy (drop enormous values)
  const sanitized: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(body)) {
    if (typeof v === "string") sanitized[k] = v.slice(0, 2000);
    else if (typeof v === "number" && Number.isFinite(v)) sanitized[k] = v;
  }
  sanitized.prompt = prompt;

  // ── Anonymous session + rate limits ──
  const res = (data: any, status = 200) => {
    const r = NextResponse.json(data, { status });
    if (!req.cookies.get(ANON_COOKIE)?.value) r.cookies.set(ANON_COOKIE, anonId, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 86400 * 180 });
    return r;
  };
  let anonId = req.cookies.get(ANON_COOKIE)?.value ?? "";
  if (!/^[0-9a-f-]{36}$/i.test(anonId)) anonId = uuid();

  const dayKey = `day:${new Date().toISOString().slice(0, 10)}`;
  const ipGlobal = checkRate(`gen:global-ip:${ip}:${dayKey}`, security.globalDailyLimitPerIp, 86400);
  if (!ipGlobal.ok) {
    return res({ code: "RATE_LIMITED", message: "Daily limit reached. Please come back tomorrow — limits reset every 24 hours.", retryAfter: ipGlobal.retryAfter }, 429);
  }
  const daily = checkRate(`gen:tool:${tool.slug}:${anonId}:${dayKey}`, tool.daily_limit, 86400);
  if (!daily.ok) {
    return res({ code: "RATE_LIMITED", message: `You've used all ${tool.daily_limit} free generations for this tool today. Limits reset daily.`, retryAfter: daily.retryAfter }, 429);
  }
  if (tool.cooldown_seconds > 0) {
    const cool = checkRate(`gen:cool:${tool.slug}:${anonId}`, 1, tool.cooldown_seconds);
    if (!cool.ok) {
      return res({ code: "COOLDOWN", message: "Please wait before creating another generation.", retryAfter: cool.retryAfter }, 429);
    }
  }

  const jobId = createJob({
    toolId: tool.id, toolSlug: tool.slug, toolName: tool.name,
    capability: tool.capability, anonId, ip, params: sanitized,
  });
  processJobAsync(jobId);
  return res({ jobId });
}
