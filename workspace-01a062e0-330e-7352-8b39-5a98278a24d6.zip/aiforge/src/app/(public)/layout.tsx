import Link from "next/link";
import { Sparkles, Wrench } from "lucide-react";
import { Header, type HeaderNav } from "@/components/header";
import { Footer, type FooterColumn } from "@/components/footer";
import { getNavigation } from "@/server/cms";
import { getSettings } from "@/server/settings";
import { getAdminUser } from "@/server/auth";

/** Public site shell: header + footer + maintenance mode + JSON-LD identity. */
export default async function PublicLayout({ children }: { children: React.ReactNode }) {
  const site = getSettings("site");
  const system = getSettings("system");
  const admin = getAdminUser();

  if (system.maintenanceOn && !admin) {
    return (
      <div className="grid-bg flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <span className="mb-6 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand2 text-white shadow-glow">
          <Sparkles size={24} aria-hidden />
        </span>
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Coming back soon</h1>
        <p className="mt-4 max-w-md leading-relaxed text-muted">{system.maintenanceMessage}</p>
        <Link href="/admin/login" className="mt-8 text-xs text-faint underline underline-offset-4 hover:text-muted">
          Administrator sign in
        </Link>
      </div>
    );
  }

  const headerItems = getNavigation("header");
  const ctaItems = getNavigation("header_cta");
  const footerItems = getNavigation("footer");

  // attach children (dropdown) to parent nav items
  const byParent = new Map<number, HeaderNav["children"]>();
  for (const item of headerItems) {
    if (item.parent_id != null) {
      const list = byParent.get(item.parent_id) ?? [];
      list.push({ label: item.label, url: item.url });
      byParent.set(item.parent_id, list);
    }
  }
  const nav: HeaderNav[] = headerItems
    .filter((i) => i.parent_id == null)
    .map((i) => ({ label: i.label, url: i.url, children: byParent.get(i.id) ?? [] }));

  const footerMap = new Map<string, { label: string; url: string }[]>();
  for (const item of footerItems) {
    const list = footerMap.get(item.footer_group) ?? [];
    list.push({ label: item.label, url: item.url });
    footerMap.set(item.footer_group, list);
  }
  const columns: FooterColumn[] = [...footerMap.entries()].map(([group, items]) => ({ group, items }));

  const base = process.env.PUBLIC_BASE_URL || "http://localhost:3000";
  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": [
      { "@type": "WebSite", name: site.siteName, url: base, description: site.description, potentialAction: { "@type": "SearchAction", target: `${base}/search?q={search_term_string}`, "query-input": "required name=search_term_string" } },
      { "@type": "Organization", name: site.siteName, url: base, description: site.description },
    ],
  };

  return (
    <>
      <a href="#main" className="skip-link">Skip to main content</a>
      <Header siteName={site.siteName} logoUrl={site.logoUrl || undefined} nav={nav}
        ctas={ctaItems.map((c) => ({ label: c.label, url: c.url, style: c.button_style }))} defaultTheme={site.defaultTheme} />
      <main id="main">{children}</main>
      {footerItems.length > 0 ? (
        <Footer siteName={site.siteName} logoUrl={site.logoUrl || undefined} description={site.footerDescription}
          copyright={site.copyright} columns={columns} socials={site.socials} />
      ) : (
        <footer className="border-t border-border py-6 text-center text-sm text-faint">
          <span className="inline-flex items-center gap-2"><Wrench size={14} /> © {new Date().getFullYear()} {site.copyright}</span>
        </footer>
      )}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </>
  );
}
