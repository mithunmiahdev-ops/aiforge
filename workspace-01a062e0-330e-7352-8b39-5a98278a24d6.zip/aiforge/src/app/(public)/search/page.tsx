import type { Metadata } from "next";
import Link from "next/link";
import { Search, Wrench, Newspaper, FileText, FolderOpen, LayoutGrid } from "lucide-react";
import { searchAll } from "@/server/cms";
import { getSettings } from "@/server/settings";
import { EmptyState } from "@/components/ui";

export async function generateMetadata(): Promise<Metadata> {
  const seo = getSettings("seo");
  return {
    title: "Search",
    description: "Search AI tools, blog articles, categories and prompt templates.",
    robots: seo.noindexSearchPage ? "noindex,follow" : seo.robotsDefault,
    alternates: { canonical: "/search" },
  };
}

const ICONS = { tool: Wrench, blog: Newspaper, template: FileText, category: FolderOpen, page: LayoutGrid };

export default async function SearchPage({ searchParams }: { searchParams: { q?: string } }) {
  const q = (searchParams.q ?? "").trim();
  const results = q ? searchAll(q, 12) : [];

  return (
    <div className="container-x max-w-3xl pb-20 pt-14 sm:pt-20">
      <h1 className="text-3xl font-black tracking-tight sm:text-4xl">Search</h1>
      <form className="relative mt-6" role="search">
        <Search size={17} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
        <input name="q" defaultValue={q} className="input !py-3.5 !pl-10 !text-base" placeholder="Search tools, articles, templates…" aria-label="Search query" autoFocus />
      </form>

      {q && (
        <p className="mt-5 text-sm text-muted" role="status" aria-live="polite">
          {results.length} result{results.length === 1 ? "" : "s"} for <span className="font-semibold text-fg">“{q}”</span>
        </p>
      )}

      {q && results.length === 0 && (
        <div className="mt-8">
          <EmptyState icon={<Search size={20} />} title={`No results for “${q}”`}>
            Try different keywords, or <Link href="/tools" className="font-semibold text-brand hover:underline">browse all AI tools</Link>.
          </EmptyState>
        </div>
      )}

      <div className="mt-6 flex flex-col gap-3">
        {results.map((r) => {
          const Ico = ICONS[r.type as keyof typeof ICONS] ?? Wrench;
          return (
            <Link key={r.type + r.url + r.title} href={r.url} className="card-hover group flex items-start gap-4 p-4">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand/10 text-brand"><Ico size={17} /></span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate font-semibold group-hover:text-brand">{r.title}</span>
                  <span className="badge !bg-surface2 !text-faint capitalize">{r.type}</span>
                </span>
                {r.description && <span className="mt-0.5 block truncate text-sm text-muted">{r.description}</span>}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
