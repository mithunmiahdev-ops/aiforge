"use client";
import { useState } from "react";
import { Mail, Send, CheckCircle2 } from "lucide-react";
import { Alert, Btn, Field } from "@/components/ui";
import { submitContact, type ContactState } from "./actions";

export default function ContactPage() {
  const [state, setState] = useState<ContactState | null>(null);
  const [pending, setPending] = useState(false);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setPending(true);
    const fd = new FormData(e.currentTarget);
    try {
      const result = await submitContact(null, fd);
      setState(result);
    } catch {
      setState({ ok: false, message: "Something went wrong. Please try again." });
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="container-x max-w-3xl pb-20 pt-14 sm:pt-20">
      <h1 className="text-3xl font-black tracking-tight sm:text-4xl">Get in touch</h1>
      <p className="section-sub">Questions, feedback, tool ideas or partnership inquiries — we read everything.</p>

      <div className="mt-10 grid gap-8 md:grid-cols-[1fr_260px]">
        <div className="card p-6 sm:p-8">
          {state?.ok ? (
            <div className="flex flex-col items-center gap-3 py-10 text-center">
              <CheckCircle2 size={36} className="text-ok" aria-hidden />
              <div className="text-lg font-semibold">Message sent</div>
              <p className="max-w-sm text-sm text-muted">{state.message}</p>
            </div>
          ) : (
            <form onSubmit={onSubmit} className="flex flex-col gap-4">
              {state && !state.ok && <Alert kind="danger">{state.message}</Alert>}
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Name">
                  <input name="name" required maxLength={100} className="input" autoComplete="name" />
                </Field>
                <Field label="Email">
                  <input name="email" type="email" required maxLength={200} className="input" autoComplete="email" />
                </Field>
              </div>
              <Field label="Subject">
                <input name="subject" maxLength={200} className="input" placeholder="How can we help?" />
              </Field>
              <Field label="Message">
                <textarea name="message" required minLength={10} maxLength={4000} className="input !min-h-[140px]" placeholder="Tell us more…" />
              </Field>
              {/* honeypot — hidden from humans */}
              <div className="hidden" aria-hidden="true">
                <label>Leave this field empty<input name="website" tabIndex={-1} autoComplete="off" /></label>
              </div>
              <Btn type="submit" loading={pending} className="mt-1"><Send size={15} /> {pending ? "Sending…" : "Send message"}</Btn>
              <p className="text-xs text-faint">We only use your email to reply. No newsletters, no marketing lists.</p>
            </form>
          )}
        </div>

        <aside className="card h-fit p-6">
          <div className="flex items-center gap-2 font-semibold"><Mail size={16} className="text-brand" aria-hidden /> Email us directly</div>
          <p className="mt-3 text-sm leading-6 text-muted">
            Prefer email? Reach us at the address shown in the footer. We typically reply within 1–2 business days.
          </p>
        </aside>
      </div>
    </div>
  );
}
