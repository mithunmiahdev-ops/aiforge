"use server";
import { getDb, run } from "@/db";
import { checkRate } from "@/server/ratelimit";
import { requestIp } from "@/server/auth";
import { getSettings } from "@/server/settings";
import { logEvent } from "@/server/audit";

export interface ContactState { ok: boolean; message: string }

export async function submitContact(_prev: ContactState | null, formData: FormData): Promise<ContactState> {
  const name = String(formData.get("name") ?? "").trim().slice(0, 100);
  const email = String(formData.get("email") ?? "").trim().slice(0, 200);
  const subject = String(formData.get("subject") ?? "").trim().slice(0, 200);
  const message = String(formData.get("message") ?? "").trim().slice(0, 4000);
  const honeypot = String(formData.get("website") ?? ""); // bots fill hidden fields

  if (honeypot) return { ok: true, message: "Thanks! Your message has been received." };
  if (name.length < 2) return { ok: false, message: "Please enter your name." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, message: "Please enter a valid email address." };
  if (message.length < 10) return { ok: false, message: "Please write a slightly longer message (at least 10 characters)." };

  const ip = await requestIp();
  const security = getSettings("security");
  const limited = checkRate(`contact:${ip}`, security.contactPerHour || 5, 3600);
  if (!limited.ok) return { ok: false, message: "You've sent several messages recently. Please try again later." };

  const db = getDb();
  run(db, "INSERT INTO contact_messages (name, email, subject, message, ip) VALUES (?,?,?,?,?)", name, email, subject, message, ip);
  logEvent({ type: "system", action: "contact.message", object: email, ip });
  return { ok: true, message: "Thanks! Your message has been received — we'll reply to your email." };
}
