import type { Metadata } from "next";
import Link from "next/link";
import { Check, Sparkles } from "lucide-react";
import { getSettings } from "@/server/settings";

export const revalidate = 120;
export const metadata: Metadata = { title: "Pricing — Free AI Tools", description: "Free AI tools for everyone. No account, no credit card, no hidden trials.", alternates: { canonical: "/pricing" } };

export default function PricingPage() {
  const pricing = getSettings("pricing");
  const plans = pricing.plans.filter((p) => p.enabled);

  return (
    <div className="hero-glow relative">
      <div className="container-x relative pb-20 pt-14 sm:pt-20">
        <div className="mx-auto max-w-2xl text-center">
          <span className="badge-brand mb-4"><Sparkles size={11} /> Honest pricing</span>
          <h1 className="text-3xl font-black tracking-tight sm:text-5xl">Free. <span className="gradient-text">Really free.</span></h1>
          <p className="mt-4 text-muted sm:text-lg">No trials that expire, no “free” plans that need a credit card. Open a tool and create — sustainable through fair-use limits and unobtrusive ads.</p>
        </div>

        <div className={`mx-auto mt-12 grid max-w-4xl gap-6 ${plans.length > 1 ? "md:grid-cols-2 lg:grid-cols-3" : ""}`}>
          {plans.map((plan) => (
            <div key={plan.name} className={`card relative flex flex-col p-8 ${plan.highlight ? "border-brand/50 shadow-glow" : ""}`}>
              {plan.highlight && <span className="badge-brand absolute -top-3 left-1/2 -translate-x-1/2">Most popular</span>}
              <h2 className="text-lg font-bold">{plan.name}</h2>
              <div className="mt-3 flex items-baseline gap-1.5">
                <span className="gradient-text text-4xl font-black">{plan.price}</span>
                <span className="text-sm text-faint">/ {plan.period}</span>
              </div>
              <p className="mt-3 text-sm text-muted">{plan.description}</p>
              <ul className="mt-6 flex flex-1 flex-col gap-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm">
                    <Check size={16} className="mt-0.5 shrink-0 text-ok" aria-hidden /> <span className="text-muted">{f}</span>
                  </li>
                ))}
              </ul>
              <Link href={plan.ctaHref || "/tools"} className={`${plan.highlight ? "btn-primary" : "btn-secondary"} mt-8 w-full`}>{plan.ctaLabel}</Link>
            </div>
          ))}
        </div>

        <div className="mx-auto mt-14 max-w-2xl text-center text-sm leading-6 text-faint">
          Fair-use limits (configurable per tool) keep the service fast and available for everyone.
          Questions? <Link href="/contact" className="font-semibold text-brand hover:underline">Contact us</Link> — no account needed for that either.
        </div>
      </div>
    </div>
  );
}
