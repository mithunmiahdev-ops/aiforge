import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { marked } from "marked";
import { getPageBySlug } from "@/server/cms";
import { getSettings } from "@/server/settings";

export const revalidate = 120;

/** CMS-driven static pages: /privacy-policy, /terms, /cookie-policy, /disclaimer, /about and admin-created pages. */
export async function generateMetadata({ params }: { params: { page: string } }): Promise<Metadata> {
  const page = getPageBySlug(params.page);
  if (!page) return {};
  const seo = getSettings("seo");
  return {
    title: page.seo_title || page.title,
    description: page.meta_description,
    alternates: { canonical: `/${page.slug}` },
    robots: page.noindex ? "noindex,nofollow" : seo.robotsDefault,
  };
}

export default async function CmsPage({ params }: { params: { page: string } }) {
  const page = getPageBySlug(params.page);
  if (!page) notFound();
  const html = marked.parse(page.content || "", { async: false }) as string;

  return (
    <div className="container-x max-w-3xl pb-20 pt-14 sm:pt-20">
      <h1 className="text-3xl font-black tracking-tight sm:text-4xl">{page.title}</h1>
      {page.updated_at && (
        <p className="mt-3 text-[13px] text-faint">Last updated {new Date(page.updated_at + "Z").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</p>
      )}
      <div className="prose-site mt-8" dangerouslySetInnerHTML={{ __html: html }} />
    </div>
  );
}
