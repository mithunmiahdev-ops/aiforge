import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { marked } from "marked";
import { Calendar, Clock, RefreshCcw, Share2, Tag, ChevronRight } from "lucide-react";
import { getPostBySlug, getRelatedPosts, getBlogCategories } from "@/server/cms";
import { getSettings } from "@/server/settings";
import { PostCard } from "@/components/post-card";
import { Collapse } from "@/components/ui";
import { AdSlot } from "@/components/ad-slot";

export const revalidate = 120;

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = getPostBySlug(params.slug);
  if (!post) return {};
  const seo = getSettings("seo");
  return {
    title: post.seo_title || post.title,
    description: post.meta_description || post.excerpt,
    alternates: { canonical: post.canonical_url || `/blog/${post.slug}` },
    robots: post.noindex ? "noindex,nofollow" : seo.robotsDefault,
    openGraph: {
      type: "article",
      title: post.seo_title || post.title,
      description: post.meta_description || post.excerpt,
      url: `/blog/${post.slug}`,
      images: post.og_image || post.featured_image ? [post.og_image || post.featured_image] : undefined,
      publishedTime: post.published_at ?? undefined,
      modifiedTime: post.updated_at,
      authors: [post.author_name],
    },
  };
}

function buildToc(html: string) {
  const headings: { id: string; text: string; level: number }[] = [];
  let i = 0;
  const withIds = html.replace(/<(h2|h3)>(.*?)<\/\1>/g, (_m, tag, text) => {
    const id = `h-${i++}`;
    headings.push({ id, text: text.replace(/<[^>]+>/g, ""), level: tag === "h2" ? 2 : 3 });
    return `<${tag} id="${id}">${text}</${tag}>`;
  });
  return { html: withIds, headings };
}

export default async function ArticlePage({ params }: { params: { slug: string } }) {
  const post = getPostBySlug(params.slug);
  if (!post) notFound();
  const related = getRelatedPosts(post);
  const categories = getBlogCategories();
  const { html, headings } = buildToc(marked.parse(post.content || "", { async: false }) as string);
  let faq: { question: string; answer: string }[] = [];
  try { faq = JSON.parse(post.faq || "[]"); } catch {}
  let tags: string[] = [];
  try { tags = JSON.parse(post.tags || "[]"); } catch {}

  const base = process.env.PUBLIC_BASE_URL || "http://localhost:3000";
  const jsonLd: any = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Article",
        headline: post.title,
        description: post.meta_description || post.excerpt,
        image: post.og_image || post.featured_image || undefined,
        datePublished: post.published_at ?? post.created_at,
        dateModified: post.updated_at,
        author: { "@type": "Person", name: post.author_name },
        publisher: { "@type": "Organization", name: getSettings("site").siteName },
        mainEntityOfPage: `${base}/blog/${post.slug}`,
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: base },
          { "@type": "ListItem", position: 2, name: "Blog", item: `${base}/blog` },
          { "@type": "ListItem", position: 3, name: post.title, item: `${base}/blog/${post.slug}` },
        ],
      },
    ],
  };
  if (faq.length) jsonLd["@graph"].push({ "@type": "FAQPage", mainEntity: faq.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.answer } }) ) });

  const shareUrl = `${base}/blog/${post.slug}`;

  return (
    <div className="container-x pb-16 pt-10">
      <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1.5 text-[13px] text-faint">
        <Link href="/" className="hover:text-brand">Home</Link>
        <ChevronRight size={13} aria-hidden />
        <Link href="/blog" className="hover:text-brand">Blog</Link>
        {post.category_slug && (
          <>
            <ChevronRight size={13} aria-hidden />
            <Link href={`/blog/category/${post.category_slug}`} className="hover:text-brand">{post.category_name}</Link>
          </>
        )}
        <ChevronRight size={13} aria-hidden />
        <span className="text-muted">{post.title}</span>
      </nav>

      <div className="flex flex-col gap-10 lg:flex-row">
        <article className="min-w-0 flex-1 lg:max-w-3xl">
          <header>
            <h1 className="text-3xl font-black leading-tight tracking-tight sm:text-4xl">{post.title}</h1>
            <p className="mt-4 text-[15px] leading-7 text-muted">{post.excerpt}</p>
            <div className="mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 text-[13px] text-faint">
              <span className="font-semibold text-muted">{post.author_name}</span>
              {post.published_at && (
                <span className="flex items-center gap-1.5"><Calendar size={13} /> {new Date(post.published_at + "Z").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</span>
              )}
              <span className="flex items-center gap-1.5"><Clock size={13} /> {post.reading_minutes} min read</span>
              {post.updated_at && post.published_at && post.updated_at.slice(0, 10) !== post.published_at.slice(0, 10) && (
                <span className="flex items-center gap-1.5"><RefreshCcw size={13} /> Updated {new Date(post.updated_at + "Z").toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
              )}
            </div>
          </header>

          {post.featured_image && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={post.featured_image} alt={post.featured_image_alt || post.title} className="mt-8 aspect-[16/8] w-full rounded-2xl border border-border object-cover" />
          )}

          {headings.length >= 3 && (
            <nav className="card mt-8 p-5" aria-label="Table of contents">
              <h2 className="text-sm font-bold uppercase tracking-wider text-faint">On this page</h2>
              <ol className="mt-3 flex flex-col gap-1.5">
                {headings.map((h, i) => (
                  <li key={h.id} className={h.level === 3 ? "ml-4" : ""}>
                    <a href={`#${h.id}`} className="text-sm text-muted hover:text-brand">{i + 1}. {h.text}</a>
                  </li>
                ))}
              </ol>
            </nav>
          )}

          <div className="prose-site mt-8" dangerouslySetInnerHTML={{ __html: html }} />

          <AdSlot placement="blog_content" currentPath={`/blog/${post.slug}`} />

          {faq.length > 0 && (
            <section className="mt-10" aria-labelledby="article-faq">
              <h2 id="article-faq" className="section-title !text-xl">FAQ</h2>
              <div className="mt-4 flex flex-col gap-3">
                {faq.map((f, i) => <Collapse key={i} question={f.question} answer={<p>{f.answer}</p>} />)}
              </div>
            </section>
          )}

          {tags.length > 0 && (
            <div className="mt-8 flex flex-wrap items-center gap-2">
              <Tag size={14} className="text-faint" aria-hidden />
              {tags.map((t) => <span key={t} className="badge !bg-surface2 !text-muted">#{t}</span>)}
            </div>
          )}

          <div className="mt-8 flex flex-wrap items-center gap-2 border-t border-border pt-6">
            <span className="flex items-center gap-1.5 text-sm font-semibold text-muted"><Share2 size={14} /> Share</span>
            <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(post.title)}`} target="_blank" rel="noopener noreferrer" className="btn-ghost btn-sm">X / Twitter</a>
            <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer" className="btn-ghost btn-sm">Facebook</a>
            <a href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noopener noreferrer" className="btn-ghost btn-sm">LinkedIn</a>
          </div>
        </article>

        <aside className="w-full shrink-0 lg:w-80" aria-label="Sidebar">
          <div className="sticky top-20 flex flex-col gap-5">
            {categories.length > 0 && (
              <div className="card p-5">
                <h2 className="text-sm font-bold uppercase tracking-wider text-faint">Categories</h2>
                <div className="mt-3 flex flex-wrap gap-2">
                  {categories.map((c) => (
                    <Link key={c.slug} href={`/blog/category/${c.slug}`} className="chip">{c.name}</Link>
                  ))}
                </div>
              </div>
            )}
            <AdSlot placement="sidebar_desktop" currentPath={`/blog/${post.slug}`} className="hidden lg:block" />
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="mt-16" aria-labelledby="related">
          <h2 id="related" className="section-title">Related articles</h2>
          <div className="mt-6 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {related.map((p: any) => <PostCard key={p.id} post={p} />)}
          </div>
        </section>
      )}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </div>
  );
}
