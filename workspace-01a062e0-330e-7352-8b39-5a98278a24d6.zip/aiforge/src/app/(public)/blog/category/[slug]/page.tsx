import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getPublishedPosts, getBlogCategories } from "@/server/cms";
import { PostCard } from "@/components/post-card";
import { EmptyState } from "@/components/ui";

export const revalidate = 120;

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const cat = getBlogCategories().find((c) => c.slug === params.slug);
  if (!cat) return {};
  return {
    title: `${cat.name} — Articles`,
    description: cat.description || `AI articles in the ${cat.name} category.`,
    alternates: { canonical: `/blog/category/${cat.slug}` },
  };
}

export default async function BlogCategoryPage({ params, searchParams }: { params: { slug: string }; searchParams: { page?: string } }) {
  const categories = getBlogCategories();
  const cat = categories.find((c) => c.slug === params.slug);
  if (!cat) notFound();
  const page = Number(searchParams.page ?? "1") || 1;
  const { rows, pages } = getPublishedPosts({ categorySlug: cat.slug, page, perPage: 9 });

  return (
    <div className="container-x pb-16 pt-12 sm:pt-16">
      <nav aria-label="Breadcrumb" className="mb-4 text-[13px] text-faint">
        <Link href="/" className="hover:text-brand">Home</Link> / <Link href="/blog" className="hover:text-brand">Blog</Link> / <span className="text-muted">{cat.name}</span>
      </nav>
      <h1 className="text-3xl font-black tracking-tight sm:text-4xl">{cat.name}</h1>
      {cat.description && <p className="section-sub">{cat.description}</p>}

      <div className="mt-6 flex flex-wrap gap-2">
        {categories.map((c) => (
          <Link key={c.slug} href={c.slug === cat.slug ? `/blog/category/${c.slug}` : `/blog/category/${c.slug}`} className={`chip ${c.slug === cat.slug ? "chip-active" : ""}`}>{c.name}</Link>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="mt-10"><EmptyState title="No articles in this category yet" /></div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map((p: any) => <PostCard key={p.id} post={p} />)}
        </div>
      )}

      {pages > 1 && (
        <nav className="mt-10 flex justify-center gap-2" aria-label="Pagination">
          {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
            <Link key={n} href={`/blog/category/${cat.slug}${n === 1 ? "" : `?page=${n}`}`} className={`chip ${n === page ? "chip-active" : ""}`}>{n}</Link>
          ))}
        </nav>
      )}
    </div>
  );
}
