import type { Metadata } from "next";
import Link from "next/link";
import { Search } from "lucide-react";
import { getPublishedPosts, getBlogCategories } from "@/server/cms";
import { PostCard } from "@/components/post-card";
import { EmptyState } from "@/components/ui";
import { AdSlot } from "@/components/ad-slot";

export const revalidate = 120;

export const metadata: Metadata = {
  title: "Blog — AI Creation Guides, Prompt Ideas & Tips",
  description: "Guides, prompt ideas and practical tips for creating with AI — video, images, audio and writing.",
  alternates: { canonical: "/blog" },
};

export default async function BlogPage({ searchParams }: { searchParams: { q?: string; page?: string } }) {
  const q = (searchParams.q ?? "").trim();
  const page = Number(searchParams.page ?? "1") || 1;
  const { rows, pages, total } = getPublishedPosts({ q, page, perPage: 9, featuredFirst: page === 1 && !q });
  const categories = getBlogCategories();

  return (
    <div className="container-x pb-16 pt-12 sm:pt-16">
      <div className="max-w-2xl">
        <h1 className="text-3xl font-black tracking-tight sm:text-4xl">The AI Blog</h1>
        <p className="section-sub">Guides, prompt ideas and practical tips for creating better AI content.</p>
      </div>

      <div className="mt-8 flex flex-col gap-4 lg:flex-row lg:items-start">
        <div className="flex-1">
          <form className="relative mb-8" role="search">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
            <input name="q" defaultValue={q} className="input !pl-9" placeholder="Search articles…" aria-label="Search articles" />
          </form>

          {rows.length === 0 ? (
            <EmptyState icon={<Search size={20} />} title={q ? `No articles match “${q}”` : "No articles yet"}>
              {q ? <>Try another keyword or <Link href="/blog" className="font-semibold text-brand hover:underline">browse everything</Link>.</> : "Articles will appear here once published."}
            </EmptyState>
          ) : (
            <>
              <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {rows.map((p: any) => <PostCard key={p.id} post={p} />)}
              </div>
              {pages > 1 && (
                <nav className="mt-10 flex items-center justify-center gap-2" aria-label="Pagination">
                  {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                    <Link key={n} href={`/blog${n === 1 ? "" : `?page=${n}`}${q ? `&q=${encodeURIComponent(q)}` : ""}`}
                      className={`chip ${n === page ? "chip-active" : ""}`} aria-current={n === page ? "page" : undefined}>{n}</Link>
                  ))}
                </nav>
              )}
            </>
          )}
        </div>

        <aside className="w-full shrink-0 lg:w-72" aria-label="Blog categories">
          <div className="card sticky top-20 p-5">
            <h2 className="text-sm font-bold uppercase tracking-wider text-faint">Categories</h2>
            <ul className="mt-4 flex flex-col gap-1">
              <li><Link href="/blog" className={`block rounded-lg px-3 py-2 text-sm hover:bg-surface2 hover:text-brand ${!q && page === 1 ? "text-brand" : "text-muted"}`}>All articles</Link></li>
              {categories.map((c) => (
                <li key={c.slug}>
                  <Link href={`/blog/category/${c.slug}`} className="flex items-center justify-between rounded-lg px-3 py-2 text-sm text-muted hover:bg-surface2 hover:text-brand">
                    {c.name} <span className="text-xs text-faint">{c.post_count}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <AdSlot placement="sidebar_desktop" currentPath="/blog" className="hidden lg:block" />
        </aside>
      </div>
      <AdSlot placement="footer" currentPath="/blog" />
    </div>
  );
}
