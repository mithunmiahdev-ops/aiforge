import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { marked } from "marked";
import { ChevronRight } from "lucide-react";
import { getToolBySlug, getTools, parseToolConfig, getFaqs, getPromptTemplates } from "@/server/cms";
import { getSettings, applyTitleTemplate } from "@/server/settings";
import { providerConfigured } from "@/server/providers";
import { ToolIcon } from "@/components/icon";
import { ToolCard } from "@/components/tool-card";
import { Collapse } from "@/components/ui";
import { AdSlot } from "@/components/ad-slot";
import { VideoToolClient } from "@/components/tools/video";
import { ImageToolClient } from "@/components/tools/image";
import { PromptToolClient } from "@/components/tools/prompt";
import { AudioToolClient } from "@/components/tools/audio";
import { TextToolClient } from "@/components/tools/text";

export const revalidate = 60;

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const tool = getToolBySlug(params.slug);
  if (!tool) return {};
  const site = getSettings("site");
  const seo = getSettings("seo");
  const title = applyTitleTemplate(seo.titleTemplate, tool.seo_title || tool.name, site.siteName);
  return {
    title,
    description: tool.seo_description || tool.tagline,
    alternates: { canonical: `/tools/${tool.slug}` },
    robots: tool.noindex ? "noindex,nofollow" : seo.robotsDefault,
    openGraph: { title, description: tool.seo_description || tool.tagline, type: "website", url: `/tools/${tool.slug}` },
  };
}

export default async function ToolPage({ params }: { params: { slug: string } }) {
  const tool = getToolBySlug(params.slug);
  if (!tool) notFound();
  const config = parseToolConfig(tool);
  const site = getSettings("site");
  const audio = getSettings("audio");
  const configured = providerConfigured(tool.capability as any);
  const limits = {
    dailyLimit: tool.daily_limit, cooldownSeconds: tool.cooldown_seconds,
    maxPromptChars: tool.max_prompt_chars, maxDurationSeconds: tool.max_duration_seconds,
  };
  const faqs = getFaqs(tool.slug);
  const related = getTools().filter((t) => t.slug !== tool.slug && (t.category_id === tool.category_id || t.is_popular)).slice(0, 4);
  const templates = tool.type === "prompt" ? getPromptTemplates() : [];

  const client = (() => {
    switch (tool.type) {
      case "video":
        return <VideoToolClient slug={tool.slug} name={tool.name} config={config} limits={limits} configured={configured} />;
      case "image":
        return <ImageToolClient slug={tool.slug} name={tool.name} config={config} limits={limits} configured={configured} />;
      case "prompt":
        return <PromptToolClient slug={tool.slug} name={tool.name} config={config} limits={limits} configured={configured} templates={templates} />;
      case "audio":
        return <AudioToolClient slug={tool.slug} name={tool.name} config={config} limits={limits} configured={configured}
          languages={audio.languages} voices={audio.voices} />;
      default:
        return <TextToolClient slug={tool.slug} name={tool.name} fields={config.fields ?? []} limits={limits} configured={configured} />;
    }
  })();

  const base = process.env.PUBLIC_BASE_URL || "http://localhost:3000";
  const jsonLd: any = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "SoftwareApplication",
        name: tool.name,
        applicationCategory: "MultimediaApplication",
        operatingSystem: "Web",
        description: tool.seo_description || tool.tagline,
        url: `${base}/tools/${tool.slug}`,
        offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
      },
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Home", item: base },
          { "@type": "ListItem", position: 2, name: "AI Tools", item: `${base}/tools` },
          { "@type": "ListItem", position: 3, name: tool.name, item: `${base}/tools/${tool.slug}` },
        ],
      },
    ],
  };
  if (faqs.length > 0) {
    jsonLd["@graph"].push({
      "@type": "FAQPage",
      mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.answer } })),
    });
  }

  return (
    <div className="hero-glow relative">
      <div className="container-x relative pb-16 pt-10">
        {/* breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1.5 text-[13px] text-faint">
          <Link href="/" className="hover:text-brand">Home</Link>
          <ChevronRight size={13} aria-hidden />
          <Link href="/tools" className="hover:text-brand">AI Tools</Link>
          <ChevronRight size={13} aria-hidden />
          {tool.category_slug && (
            <>
              <Link href={`/tools?category=${tool.category_slug}`} className="hover:text-brand">{tool.category_name}</Link>
              <ChevronRight size={13} aria-hidden />
            </>
          )}
          <span className="text-muted">{tool.name}</span>
        </nav>

        {/* header */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-start">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand/20 to-brand2/20 text-brand shadow-glow">
            <ToolIcon name={tool.icon} size={26} />
          </span>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-black tracking-tight sm:text-3xl">{tool.name}</h1>
              {tool.is_new ? <span className="badge-new">New</span> : null}
              {tool.is_popular ? <span className="badge-warn">Popular</span> : null}
            </div>
            <p className="mt-2 max-w-2xl text-[15px] text-muted">{tool.tagline}</p>
          </div>
        </div>

        <AdSlot placement="tool_top" currentPath={`/tools/${tool.slug}`} />

        {client}

        <AdSlot placement="tool_middle" currentPath={`/tools/${tool.slug}`} />

        {/* description */}
        {tool.description && (
          <div className="prose-site mt-12 max-w-3xl" dangerouslySetInnerHTML={{ __html: marked.parse(tool.description, { async: false }) as string }} />
        )}

        {/* FAQs */}
        {faqs.length > 0 && (
          <div className="mt-12 max-w-3xl">
            <h2 className="section-title">Frequently asked questions</h2>
            <div className="mt-6 flex flex-col gap-3">
              {faqs.map((f, i) => <Collapse key={f.id} question={f.question} answer={<p>{f.answer}</p>} defaultOpen={i === 0} />)}
            </div>
          </div>
        )}

        <AdSlot placement="tool_bottom" currentPath={`/tools/${tool.slug}`} />

        {/* related */}
        {related.length > 0 && (
          <div className="mt-14">
            <h2 className="section-title">More free AI tools</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((t) => <ToolCard key={t.slug} tool={t} />)}
            </div>
          </div>
        )}
      </div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </div>
  );
}
