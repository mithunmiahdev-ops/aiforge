import type { Metadata } from "next";
import Link from "next/link";
import { Search, SlidersHorizontal, Sparkles, Star, Flame } from "lucide-react";
import { getTools, getCategories } from "@/server/cms";
import { ToolCard } from "@/components/tool-card";
import { EmptyState } from "@/components/ui";
import { AdSlot } from "@/components/ad-slot";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Free AI Tools — Video, Image, Prompt, Audio & More",
  description: "Browse every free AI tool: video generation, image generation, prompt builders, audio/TTS, story and script writers, SEO tools — no signup required.",
  alternates: { canonical: "/tools" },
};

const SORTS = [
  { id: "featured", label: "Featured" },
  { id: "popular", label: "Popular" },
  { id: "new", label: "New" },
  { id: "az", label: "A–Z" },
];

export default async function ToolsPage({ searchParams }: { searchParams: { q?: string; category?: string; sort?: string } }) {
  const q = (searchParams.q ?? "").trim().toLowerCase();
  const category = searchParams.category ?? "";
  const sort = searchParams.sort ?? "featured";
  const tools = getTools();
  const categories = getCategories();

  let filtered = tools;
  if (category) filtered = filtered.filter((t) => t.category_slug === category);
  if (q) {
    filtered = filtered.filter((t) =>
      t.name.toLowerCase().includes(q) || t.tagline.toLowerCase().includes(q) ||
      (t.category_name ?? "").toLowerCase().includes(q));
  }
  if (sort === "popular") filtered = [...filtered].sort((a, b) => (b.is_popular - a.is_popular) || a.sort - b.sort);
  else if (sort === "new") filtered = [...filtered].sort((a, b) => (b.is_new - a.is_new) || (b.created_at > a.created_at ? 1 : -1));
  else if (sort === "az") filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));
  else filtered = [...filtered].sort((a, b) => (b.is_featured - a.is_featured) || a.sort - b.sort);

  const qs = (patch: Record<string, string | undefined>) => {
    const params = new URLSearchParams();
    const merged = { q: q || undefined, category: category || undefined, sort: sort === "featured" && !("sort" in patch) ? undefined : sort, ...patch };
    for (const [k, v] of Object.entries(merged)) if (v) params.set(k, v);
    const s = params.toString();
    return s ? `/tools?${s}` : "/tools";
  };

  return (
    <div className="hero-glow relative">
      <div className="container-x relative pb-16 pt-12 sm:pt-16">
        <div className="max-w-2xl">
          <span className="badge-brand mb-4"><Sparkles size={11} /> {tools.length} free tools · no signup</span>
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">AI Tools Directory</h1>
          <p className="section-sub">Every tool is free to use within daily fair-use limits. Search, filter by category, and create in seconds.</p>
        </div>

        {/* search + sort bar */}
        <form className="card mt-8 flex flex-col gap-3 p-4 sm:flex-row sm:items-center" role="search">
          <div className="relative flex-1">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
            <input name="q" defaultValue={searchParams.q ?? ""} className="input !pl-9" placeholder="Search tools…" aria-label="Search tools" />
          </div>
          {category && <input type="hidden" name="category" value={category} />}
          <div className="flex items-center gap-2 overflow-x-auto">
            <SlidersHorizontal size={14} className="shrink-0 text-faint" aria-hidden />
            {SORTS.map((s) => (
              <button key={s.id} type="submit" formAction={qs({ sort: s.id })} className={`chip shrink-0 ${sort === s.id ? "chip-active" : ""}`}
                aria-pressed={sort === s.id}>{s.label}</button>
            ))}
          </div>
        </form>

        {/* category chips */}
        <div className="mt-4 flex flex-wrap gap-2">
          <Link href={qs({ category: undefined })} className={`chip ${!category ? "chip-active" : ""}`}>All</Link>
          {categories.map((c) => (
            <Link key={c.slug} href={qs({ category: c.slug })} className={`chip ${category === c.slug ? "chip-active" : ""}`}>{c.name}</Link>
          ))}
        </div>

        <AdSlot placement="tool_top" currentPath="/tools" />

        {filtered.length > 0 ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((t) => <ToolCard key={t.slug} tool={t} />)}
          </div>
        ) : (
          <div className="mt-10">
            <EmptyState icon={<Search size={20} />} title="No tools match your search">
              Try a different keyword or <Link href="/tools" className="font-semibold text-brand hover:underline">clear all filters</Link>.
            </EmptyState>
          </div>
        )}

        <div className="mt-10 flex flex-wrap items-center justify-center gap-3 text-sm text-faint">
          <span className="flex items-center gap-1.5"><Star size={13} className="text-brand" /> Featured</span>
          <span className="flex items-center gap-1.5"><Flame size={13} className="text-warn" /> Popular</span>
          <span>·</span>
          <span>New tools are added regularly — check back soon.</span>
        </div>
      </div>
    </div>
  );
}
