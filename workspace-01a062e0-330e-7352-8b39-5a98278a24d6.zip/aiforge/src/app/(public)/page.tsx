import Link from "next/link";
import { ArrowRight, Sparkles, Star, Flame, ChevronRight } from "lucide-react";
import { getHomepageSections, getTools, getCategories, getFaqs, getPublishedPosts } from "@/server/cms";
import { ToolCard } from "@/components/tool-card";
import { ToolIcon } from "@/components/icon";
import { HeroMockup } from "@/components/mockup";
import { Collapse } from "@/components/ui";
import { AdSlot } from "@/components/ad-slot";
import { PostCard } from "@/components/post-card";

export const revalidate = 60;

export default function HomePage() {
  const sections = getHomepageSections();
  const tools = getTools();
  const categories = getCategories();
  const faqs = getFaqs("home");
  const posts = getPublishedPosts({ perPage: 3 });

  return (
    <>
      {sections.map((section, i) => {
        const content = safeParse(section.content);
        const first = i === 0;
        return (
          <section key={section.key} aria-labelledby={section.key} className={first ? "hero-glow relative overflow-hidden" : undefined}>
            <div className={`container-x relative ${first ? "pb-16 pt-14 sm:pb-20 sm:pt-20" : "py-14 sm:py-16"} ${i % 2 === 1 ? "" : ""}`}>
              {renderSection(section, content, { tools, categories, faqs, posts })}
            </div>
            {i === 0 && <div className="grid-bg pointer-events-none absolute inset-0 -z-0" aria-hidden />}
            <AdSlot placement={i === 0 ? "below_hero" : "content_between"} currentPath="/" />
          </section>
        );
      })}
    </>
  );
}

type SectionData = {
  tools: ReturnType<typeof getTools>;
  categories: ReturnType<typeof getCategories>;
  faqs: ReturnType<typeof getFaqs>;
  posts: ReturnType<typeof getPublishedPosts>;
};

function renderSection(section: any, content: any, data: SectionData): React.ReactNode {
  const heading = (title: string, subtitle?: string, icon?: React.ReactNode) => (
    <div className="mb-8 max-w-2xl">
      {icon && <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-brand/10 text-brand">{icon}</div>}
      <h2 id={section.key} className="section-title">{title}</h2>
      {subtitle && <p className="section-sub">{subtitle}</p>}
    </div>
  );

  switch (section.type) {
    case "hero":
      return <Hero content={content} tools={data.tools} />;

    case "categories":
      return (
        <>
          {heading(section.title || "Create anything with AI", section.subtitle)}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {data.categories.map((c) => (
              <Link key={c.slug} href={`/tools?category=${c.slug}`} className="card-hover group flex flex-col items-center gap-3 p-5 text-center">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand/15 to-brand2/15 text-brand transition-transform group-hover:scale-110">
                  <ToolIcon name={c.icon} size={22} />
                </span>
                <span className="text-sm font-semibold">{c.name}</span>
              </Link>
            ))}
          </div>
        </>
      );

    case "popular_tools":
    case "featured_tools": {
      const filtered = section.type === "popular_tools"
        ? data.tools.filter((t) => t.is_popular).slice(0, 8)
        : data.tools.filter((t) => t.is_featured).slice(0, 8);
      if (filtered.length === 0) return null;
      return (
        <>
          {heading(section.title || "Popular AI tools", section.subtitle,
            section.type === "popular_tools" ? <Flame size={18} /> : <Star size={18} />)}
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {filtered.map((t) => <ToolCard key={t.slug} tool={t} />)}
          </div>
          <div className="mt-8 text-center">
            <Link href="/tools" className="btn-secondary">Browse all tools <ArrowRight size={15} /></Link>
          </div>
        </>
      );
    }

    case "how_it_works":
      return (
        <>
          {heading(section.title || "How it works", section.subtitle)}
          <ol className="grid gap-5 md:grid-cols-3">
            {(content.steps ?? []).map((step: any, i: number) => (
              <li key={i} className="card relative p-6">
                <span className="absolute right-5 top-4 text-4xl font-black text-brand/10">{i + 1}</span>
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand/10 text-brand"><ToolIcon name={step.icon} size={20} /></span>
                <h3 className="mt-4 font-semibold">{step.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">{step.desc}</p>
              </li>
            ))}
          </ol>
        </>
      );

    case "why_us":
      return (
        <>
          {heading(section.title || "Why choose us", section.subtitle, <Sparkles size={18} />)}
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {(content.items ?? []).map((item: any, i: number) => (
              <div key={i} className="card p-6">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-brand/15 to-brand2/15 text-brand"><ToolIcon name={item.icon} size={20} /></span>
                <h3 className="mt-4 font-semibold">{item.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">{item.desc}</p>
              </div>
            ))}
          </div>
        </>
      );

    case "blog_latest": {
      if (data.posts.rows.length === 0) return null;
      return (
        <>
          {heading(section.title || "Latest articles", section.subtitle)}
          <div className="grid gap-5 md:grid-cols-3">
            {data.posts.rows.map((p: any) => <PostCard key={p.id} post={p} />)}
          </div>
          <div className="mt-8 text-center">
            <Link href="/blog" className="btn-secondary">Read the blog <ArrowRight size={15} /></Link>
          </div>
        </>
      );
    }

    case "faq": {
      if (data.faqs.length === 0) return null;
      return (
        <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr]">
          {heading(section.title || "FAQ", section.subtitle)}
          <div className="flex flex-col gap-3">
            {data.faqs.map((f, i) => <Collapse key={f.id} question={f.question} answer={<p>{f.answer}</p>} defaultOpen={i === 0} />)}
          </div>
        </div>
      );
    }

    case "cta":
      return (
        <div className="card relative overflow-hidden bg-gradient-to-br from-brand/10 via-transparent to-brand2/10 p-8 text-center sm:p-14">
          <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-96 -translate-x-1/2 rounded-full bg-brand/20 blur-3xl" aria-hidden />
          <h2 id={section.key} className="relative mx-auto max-w-2xl text-2xl font-bold tracking-tight sm:text-4xl">{content.title || "Ready to create?"}</h2>
          <p className="relative mx-auto mt-4 max-w-xl text-muted">{content.sub}</p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Link href={content.ctaHref || "/tools"} className="btn-primary">{content.ctaLabel || "Create for Free"} <ArrowRight size={16} /></Link>
            <Link href="/blog" className="btn-secondary">Read guides</Link>
          </div>
        </div>
      );

    case "stats": {
      const items = content.items ?? [];
      if (!Array.isArray(items) || items.length === 0) return null;
      return (
        <>
          {heading(section.title || "By the numbers", section.subtitle)}
          <div className="grid grid-cols-2 gap-5 md:grid-cols-4">
            {items.map((s: any, i: number) => (
              <div key={i} className="card p-6 text-center">
                <div className="gradient-text text-3xl font-black sm:text-4xl">{s.value}</div>
                <div className="mt-1.5 text-sm text-muted">{s.label}</div>
              </div>
            ))}
          </div>
        </>
      );
    }

    default:
      return null;
  }
}

function Hero({ content, tools }: { content: any; tools: SectionData["tools"] }) {
  const quick = tools.filter((t) => t.is_featured || t.is_popular).slice(0, 4);
  return (
    <div className="grid items-center gap-12 lg:grid-cols-2">
      <div className="relative">
        {content.badge && (
          <span className="badge-brand mb-5 !px-3 !py-1.5 !text-xs"><Sparkles size={12} aria-hidden /> {content.badge}</span>
        )}
        <h1 className="text-4xl font-black leading-[1.08] tracking-tight sm:text-5xl xl:text-6xl">
          <span className="gradient-text">{(content.headline || "Create Powerful AI Content — Completely Free").split("—")[0]}</span>
          <span>{(content.headline || "Create Powerful AI Content — Completely Free").includes("—") ? "—" + (content.headline || "").split("—").slice(1).join("—") : ""}</span>
        </h1>
        <p className="mt-5 max-w-xl text-base leading-7 text-muted sm:text-lg">
          {content.subheadline || "Generate videos, images, prompts, audio and more — free, no account required."}
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href={content.ctaPrimaryHref || "/tools"} className="btn-primary !px-6 !py-3 !text-[15px]">
            {content.ctaPrimaryLabel || "Start Creating Free"} <ArrowRight size={17} />
          </Link>
          <Link href={content.ctaSecondaryHref || "/tools"} className="btn-secondary !px-6 !py-3 !text-[15px]">
            {content.ctaSecondaryLabel || "Explore AI Tools"}
          </Link>
        </div>
        <div className="mt-8 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-faint">
          <span className="flex items-center gap-1.5"><ChevronRight size={13} className="text-ok" /> No signup</span>
          <span className="flex items-center gap-1.5"><ChevronRight size={13} className="text-ok" /> No credit card</span>
          <span className="flex items-center gap-1.5"><ChevronRight size={13} className="text-ok" /> Daily free generations</span>
        </div>
      </div>
      <div className="relative lg:pl-4">
        <HeroMockup />
        <div className="mt-4 flex flex-wrap gap-2 lg:justify-center">
          {quick.map((t) => (
            <Link key={t.slug} href={`/tools/${t.slug}`} className="chip flex items-center gap-1.5">
              <ToolIcon name={t.icon} size={13} /> {t.name}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function safeParse(s: string) {
  try { return JSON.parse(s || "{}"); } catch { return {}; }
}
