import type { Metadata, Viewport } from "next";
import "./globals.css";
import { getSettings } from "@/server/settings";
import { AnalyticsScripts, CookieConsent } from "@/components/analytics";
import { SwRegistrar } from "@/components/sw-registrar";

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#090a12" },
    { media: "(prefers-color-scheme: light)", color: "#f8f9fc" },
  ],
  width: "device-width",
  initialScale: 1,
};

export function generateMetadata(): Metadata {
  const site = getSettings("site");
  const seo = getSettings("seo");
  const analytics = getSettings("analytics");
  return {
    metadataBase: new URL(process.env.PUBLIC_BASE_URL || "http://localhost:3000"),
    title: { default: `${site.siteName} — ${site.tagline}`, template: `%s | ${site.siteName}` },
    description: seo.defaultDescription,
    keywords: seo.defaultKeywords.split(",").map((k) => k.trim()).filter(Boolean),
    robots: seo.robotsDefault,
    openGraph: {
      type: "website",
      siteName: site.siteName,
      title: `${site.siteName} — ${site.tagline}`,
      description: seo.defaultDescription,
      images: seo.defaultOgImage ? [seo.defaultOgImage] : undefined,
    },
    twitter: { card: "summary_large_image", site: seo.twitterHandle || undefined },
    ...(analytics.searchConsoleVerification ? { verification: { google: analytics.searchConsoleVerification } } : {}),
    icons: site.faviconUrl ? { icon: site.faviconUrl } : undefined,
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const site = getSettings("site");
  const analytics = getSettings("analytics");

  return (
    <html lang="en" className={site.defaultTheme === "dark" ? "dark" : ""} suppressHydrationWarning>
      <head>
        <script
          // Apply saved theme before paint to avoid a flash (safe inline: constant only)
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('theme');var d=${site.defaultTheme === "dark" ? "true" : "false"};if(t==='dark'||(t!=='light'&&d))document.documentElement.classList.add('dark');}catch(e){}})();`,
          }}
        />
        <style
          // Admin-configurable brand colors (CSS variables)
          dangerouslySetInnerHTML={{ __html: `:root{--c-brand:${site.primaryColor};--c-brand2:${site.secondaryColor};}.dark{--c-brand:${site.primaryColor};--c-brand2:${site.secondaryColor};}` }}
        />
      </head>
      <body>
        <AnalyticsScripts config={analytics} />
        <CookieConsent requireConsent={analytics.requireConsent} />
        <SwRegistrar />
        {children}
      </body>
    </html>
  );
}
