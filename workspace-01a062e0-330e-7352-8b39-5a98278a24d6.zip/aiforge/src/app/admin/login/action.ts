"use server";
import { getDb, get, run, nowIso } from "@/db";
import { verifyPasswordHash, createSession, requestIp } from "@/server/auth";
import { checkRate } from "@/server/ratelimit";
import { getSettings } from "@/server/settings";
import { logEvent } from "@/server/audit";

export interface LoginResult { ok: boolean; error?: string; locked?: number }

/** Returns a result object (never redirect-throws) so the client controls navigation. */
export async function loginAction(formData: FormData): Promise<LoginResult> {
  const email = String(formData.get("email") ?? "").toLowerCase().trim().slice(0, 200);
  const password = String(formData.get("password") ?? "");
  if (!email || !password) return { ok: false, error: "Please enter your email and password." };

  const ip = await requestIp();
  const security = getSettings("security");

  // ── Login rate limiting: per IP and per email ──
  const ipAttempts = checkRate(`login:ip:${ip}`, security.loginMaxAttempts, security.loginWindowMinutes * 60);
  if (!ipAttempts.ok) {
    logEvent({ type: "security", action: "login.rate_limited", object: ip, ip });
    return { ok: false, error: "Too many login attempts from this address. Please wait.", locked: ipAttempts.retryAfter };
  }
  const emailAttempts = checkRate(`login:email:${email}`, security.loginMaxAttempts, security.loginWindowMinutes * 60);
  if (!emailAttempts.ok) {
    return { ok: false, error: "Too many attempts for this account. Please wait.", locked: emailAttempts.retryAfter };
  }

  const db = getDb();
  const user = get<{ id: number; password_hash: string; is_active: number }>(
    db, "SELECT id, password_hash, is_active FROM admin_users WHERE email = ?", email
  );

  const ok = user ? verifyPasswordHash(password, user.password_hash) : false;
  run(db, "INSERT INTO login_attempts (ip, email, success) VALUES (?,?,?)", ip, email, ok ? 1 : 0);

  if (!ok || !user || !user.is_active) {
    // uniform error — don't reveal whether the email exists
    logEvent({ type: "security", action: "login.failed", object: email, ip });
    return { ok: false, error: "Invalid email or password." };
  }

  createSession(user.id, ip, "");
  run(db, "UPDATE admin_users SET last_login_at = ? WHERE id = ?", nowIso(), user.id);
  logEvent({ type: "admin_action", actor: email, action: "login.success", ip });
  return { ok: true };
}
