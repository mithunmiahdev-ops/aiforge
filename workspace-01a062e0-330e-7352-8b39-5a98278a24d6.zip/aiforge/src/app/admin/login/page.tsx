"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Lock, ShieldCheck, Sparkles } from "lucide-react";
import { Alert, Btn, Field, Input } from "@/components/ui";
import { loginAction } from "./action";

export default function AdminLoginPage() {
  const router = useRouter();
  const [state, setState] = useState<{ error?: string; locked?: number } | null>(null);
  const [pending, setPending] = useState(false);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setPending(true);
    setState(null);
    const fd = new FormData(e.currentTarget);
    try {
      const result = await loginAction(fd);
      if (result.ok) {
        router.replace("/admin");          // success → into the dashboard
        router.refresh();
        return;
      }
      setState({ error: result.error, locked: result.locked });
    } catch {
      setState({ error: "Something went wrong. Please try again." });
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="grid-bg flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <span className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand to-brand2 text-white shadow-glow">
            <Sparkles size={20} aria-hidden />
          </span>
          <h1 className="text-xl font-bold tracking-tight">Administrator sign in</h1>
          <p className="mt-1.5 flex items-center gap-1.5 text-[13px] text-faint">
            <ShieldCheck size={13} className="text-ok" aria-hidden /> Secure area — staff only
          </p>
        </div>

        <div className="card p-6">
          {state?.error && <div className="mb-4"><Alert kind="danger">{state.error}</Alert></div>}
          {state?.locked && <div className="mb-4"><Alert kind="warn" title="Too many attempts">Wait {Math.ceil(state.locked / 60)} minute(s) before trying again.</Alert></div>}
          <form onSubmit={onSubmit} className="flex flex-col gap-4">
            <Field label="Email">
              <Input name="email" type="email" required autoComplete="username" autoFocus placeholder="admin@example.com" />
            </Field>
            <Field label="Password">
              <Input name="password" type="password" required autoComplete="current-password" placeholder="••••••••••" />
            </Field>
            <Btn type="submit" loading={pending} className="mt-1 w-full">
              <Lock size={15} /> {pending ? "Signing in…" : "Sign in"}
            </Btn>
          </form>
        </div>

        <p className="mt-6 text-center text-xs text-faint">
          <Link href="/" className="hover:text-muted">← Back to the site</Link>
        </p>
      </div>
    </div>
  );
}
