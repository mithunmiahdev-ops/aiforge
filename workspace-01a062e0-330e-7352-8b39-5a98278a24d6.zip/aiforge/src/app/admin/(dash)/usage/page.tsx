import Link from "next/link";
import { getDb, all, get } from "@/db";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminUsagePage({ searchParams }: { searchParams: { status?: string; tool?: string; page?: string } }) {
  const db = getDb();
  const status = searchParams.status ?? "";
  const tool = searchParams.tool ?? "";
  const page = Math.max(1, Number(searchParams.page ?? "1") || 1);
  const perPage = 25;

  const where: string[] = ["1=1"];
  const args: any[] = [];
  if (status) { where.push("status = ?"); args.push(status); }
  if (tool) { where.push("tool_slug = ?"); args.push(tool); }
  const whereSql = where.join(" AND ");

  const total = get<{ c: number }>(db, `SELECT COUNT(*) AS c FROM generation_jobs WHERE ${whereSql}`, ...args)?.c ?? 0;
  const rows = all(db, `SELECT id, tool_name, tool_slug, capability, status, provider, model, error_code, error_message, created_at, completed_at FROM generation_jobs WHERE ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`, ...args, perPage, (page - 1) * perPage);
  const tools = all<{ tool_slug: string; tool_name: string; c: number }>(db, "SELECT tool_slug, tool_name, COUNT(*) AS c FROM generation_jobs GROUP BY tool_slug ORDER BY c DESC");
  const pages = Math.max(1, Math.ceil(total / perPage));
  const qs = (patch: Record<string, string | undefined>) => {
    const params = new URLSearchParams();
    const merged = { status: status || undefined, tool: tool || undefined, ...patch };
    for (const [k, v] of Object.entries(merged)) if (v) params.set(k, v);
    const s = params.toString();
    return s ? `/admin/usage?${s}` : "/admin/usage";
  };

  return (
    <div>
      <AdminHeader title="Usage & Generation Jobs" description={`${total.toLocaleString()} job(s) — anonymous usage analytics. Internal errors are stored separately and never shown to visitors.`} />
      <div className="mb-4 flex flex-wrap gap-2">
        <Link href={qs({ status: undefined })} className={`chip ${!status ? "chip-active" : ""}`}>All statuses</Link>
        {["completed", "failed", "queued", "processing"].map((s) => (
          <Link key={s} href={qs({ status: s })} className={`chip ${status === s ? "chip-active" : ""}`}>{s}</Link>
        ))}
        <span className="mx-2 text-border2">|</span>
        <Link href={qs({ tool: undefined })} className={`chip ${!tool ? "chip-active" : ""}`}>All tools</Link>
        {tools.slice(0, 6).map((t) => (
          <Link key={t.tool_slug} href={qs({ tool: t.tool_slug })} className={`chip ${tool === t.tool_slug ? "chip-active" : ""}`}>{t.tool_name} ({t.c})</Link>
        ))}
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full min-w-[860px] text-sm">
          <thead><tr className="border-b border-border text-left text-xs uppercase tracking-wider text-faint">
            <th className="px-4 py-3">Tool</th><th className="px-4 py-3">Capability</th><th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Provider / model</th><th className="px-4 py-3">Error</th><th className="px-4 py-3">Created</th>
          </tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-muted">No jobs match these filters.</td></tr>}
            {rows.map((j) => (
              <tr key={j.id} className="border-b border-border/60 last:border-0">
                <td className="px-4 py-2.5 font-medium">{j.tool_name}</td>
                <td className="px-4 py-2.5 text-muted">{j.capability}</td>
                <td className="px-4 py-2.5"><span className={`badge ${j.status === "completed" ? "badge-ok" : j.status === "failed" ? "badge-danger" : "badge-warn"}`}>{j.status}</span></td>
                <td className="px-4 py-2.5 text-muted">{j.provider}{j.model ? ` · ${j.model}` : ""}</td>
                <td className="max-w-[220px] px-4 py-2.5 text-xs text-muted"><span className="block truncate" title={j.error_message}>{j.error_code ? `${j.error_code}: ${j.error_message}` : "—"}</span></td>
                <td className="px-4 py-2.5 text-xs text-faint">{j.created_at?.replace("T", " ").slice(0, 19)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && (
        <nav className="mt-4 flex flex-wrap gap-2" aria-label="Pagination">
          {Array.from({ length: Math.min(pages, 10) }, (_, i) => i + 1).map((n) => (
            <Link key={n} href={qs({ page: String(n) })} className={`chip ${n === page ? "chip-active" : ""}`}>{n}</Link>
          ))}
        </nav>
      )}
    </div>
  );
}
