import { getDb, all } from "@/db";
import { AdminHeader } from "../_lib/page-shell";
import { MediaGrid } from "./media-grid";
import { deleteMedia, updateMediaAlt } from "@/app/admin/actions";

export const dynamic = "force-dynamic";

export default async function AdminMediaPage() {
  const rows = all<{ id: number; filename: string; original_name: string; path: string; mime: string; size: number; width: number; height: number; alt_text: string; created_at: string }>(
    getDb(), "SELECT * FROM media ORDER BY id DESC LIMIT 200"
  );
  return (
    <div>
      <AdminHeader title="Media Library" description="Upload images (auto-optimized to WebP, max 1920px), copy URLs, edit alt text and delete. Use URLs in blog posts, logos and OG images." />
      <MediaGrid media={rows} deleteMedia={deleteMedia} updateAlt={updateMediaAlt} />
    </div>
  );
}
