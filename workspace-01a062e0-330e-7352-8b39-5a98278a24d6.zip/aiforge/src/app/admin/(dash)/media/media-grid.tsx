"use client";
import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Alert, Btn, EmptyState, Input, Modal, Spinner } from "@/components/ui";
import { Check, Copy, ImagePlus, Search, Trash2, Upload } from "lucide-react";

interface MediaItem { id: number; filename: string; original_name: string; path: string; mime: string; size: number; width: number; height: number; alt_text: string; created_at: string }

export function MediaGrid({ media, deleteMedia, updateAlt }: {
  media: MediaItem[];
  deleteMedia: (id: number) => Promise<{ ok: boolean; message: string }>;
  updateAlt: (id: number, alt: string) => Promise<{ ok: boolean; message: string }>;
}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const [search, setSearch] = useState("");
  const [copied, setCopied] = useState<number | null>(null);
  const [editing, setEditing] = useState<MediaItem | null>(null);
  const [altValue, setAltValue] = useState("");
  const [deleting, setDeleting] = useState<MediaItem | null>(null);
  const [, startTransition] = useTransition();

  const filtered = media.filter((m) => !search || m.original_name.toLowerCase().includes(search.toLowerCase()) || m.alt_text.toLowerCase().includes(search.toLowerCase()));

  const upload = async (files: FileList) => {
    setUploading(true);
    setFeedback(null);
    let ok = 0, fail = 0;
    for (const file of Array.from(files).slice(0, 10)) {
      const fd = new FormData();
      fd.set("file", file);
      try {
        const res = await fetch("/api/media/upload", { method: "POST", body: fd });
        if (res.ok) ok++; else fail++;
      } catch { fail++; }
    }
    setUploading(false);
    setFeedback({ ok: fail === 0, message: `${ok} file(s) uploaded${fail ? `, ${fail} failed` : ""}.` });
    startTransition(() => router.refresh());
  };

  const copy = async (m: MediaItem) => {
    try { await navigator.clipboard.writeText(m.path); } catch {}
    setCopied(m.id);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-faint" aria-hidden />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} className="!pl-9" placeholder="Search media…" aria-label="Search media" />
        </div>
        <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple hidden
          onChange={(e) => e.target.files && upload(e.target.files)} aria-label="Upload images" />
        <Btn onClick={() => inputRef.current?.click()} loading={uploading}><Upload size={15} /> Upload images</Btn>
      </div>

      {feedback && <div className="mb-4"><Alert kind={feedback.ok ? "success" : "danger"}>{feedback.message}</Alert></div>}
      {uploading && <div className="mb-4"><Alert kind="info">Optimizing & uploading…</Alert></div>}

      {filtered.length === 0 && !uploading ? (
        <EmptyState icon={<ImagePlus size={20} />} title={media.length === 0 ? "No media yet" : "No matches"}>
          {media.length === 0 ? "Upload your first image — logos, blog images, OG images." : "Try a different search."}
        </EmptyState>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {filtered.map((m) => (
            <figure key={m.id} className="card group overflow-hidden">
              <div className="relative aspect-square bg-surface2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={m.path} alt={m.alt_text || m.original_name} className="h-full w-full object-cover" loading="lazy" />
              </div>
              <figcaption className="p-3">
                <div className="truncate text-xs font-medium" title={m.original_name}>{m.original_name}</div>
                <div className="text-[10px] text-faint">{m.width}×{m.height} · {(m.size / 1024).toFixed(0)} KB</div>
                <div className="mt-2 flex gap-1">
                  <button onClick={() => copy(m)} className="btn-ghost btn-sm flex-1" aria-label={`Copy URL of ${m.original_name}`}>
                    {copied === m.id ? <Check size={13} className="text-ok" /> : <Copy size={13} />}
                  </button>
                  <button onClick={() => { setEditing(m); setAltValue(m.alt_text); }} className="btn-ghost btn-sm flex-1 !text-xs">Alt</button>
                  <button onClick={() => setDeleting(m)} className="btn-danger btn-sm flex-1" aria-label={`Delete ${m.original_name}`}><Trash2 size={13} /></button>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      )}

      <Modal open={!!editing} onClose={() => setEditing(null)} title="Alt text">
        <p className="mb-3 text-sm text-muted">Describe the image for screen readers and SEO.</p>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {editing && <img src={editing.path} alt="" className="mb-4 max-h-48 w-full rounded-xl border border-border object-contain" />}
        <Input value={altValue} onChange={(e) => setAltValue(e.target.value)} placeholder="e.g. Dashboard showing AI video generator" />
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setEditing(null)}>Cancel</Btn>
          <Btn onClick={async () => { if (editing) { await updateAlt(editing.id, altValue); setEditing(null); startTransition(() => router.refresh()); } }}>Save</Btn>
        </div>
      </Modal>

      <Modal open={!!deleting} onClose={() => setDeleting(null)} title="Delete media">
        <p className="text-sm text-muted">Delete <span className="font-semibold text-fg">{deleting?.original_name}</span> permanently?</p>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setDeleting(null)}>Cancel</Btn>
          <Btn variant="danger" onClick={async () => { if (deleting) { await deleteMedia(deleting.id); setDeleting(null); startTransition(() => router.refresh()); } }}><Trash2 size={14} /> Delete</Btn>
        </div>
      </Modal>
    </div>
  );
}
