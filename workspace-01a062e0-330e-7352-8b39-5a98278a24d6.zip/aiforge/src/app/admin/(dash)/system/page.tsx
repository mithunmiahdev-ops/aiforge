import fs from "node:fs";
import os from "node:os";
import { getDb, get, all } from "@/db";
import { DB_PATH, STORAGE_DIR } from "@/db";
import { providerStatus } from "@/server/providers";
import { storageStats } from "@/server/storage";
import { getSettings } from "@/server/settings";
import { AdminHeader } from "../_lib/page-shell";
import { Alert } from "@/components/ui";
import { CheckCircle2, XCircle, AlertTriangle } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminSystemPage() {
  const db = getDb();
  const providers = providerStatus();
  const storage = storageStats();
  const dbSize = fs.existsSync(DB_PATH) ? fs.statSync(DB_PATH).size : 0;
  const counts = {
    tools: get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM tools")!.c,
    posts: get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM blog_posts")!.c,
    media: get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM media")!.c,
    jobs: get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM generation_jobs")!.c,
    sessions: get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM admin_sessions WHERE expires_at > datetime('now')")!.c,
  };
  const recentErrors = all(db, "SELECT action, object, created_at FROM system_logs WHERE type='error' ORDER BY id DESC LIMIT 6");
  const maintenance = getSettings("system").maintenanceOn;
  const mem = process.memoryUsage();
  const capabilities = ["video", "image", "text", "audio"];

  return (
    <div className="flex flex-col gap-6">
      <AdminHeader title="System Status" description="Health of every subsystem. Green means operational." />
      {maintenance && <Alert kind="warn" title="Maintenance mode is ON">Visitors currently see the “Coming back soon” page. Disable it in General Settings.</Alert>}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <StatusCard title="Database" ok={fs.existsSync(DB_PATH)} detail={[
          `Engine: SQLite (WAL) — ${db ? "connected" : "unavailable"}`,
          `Size: ${(dbSize / 1048576).toFixed(2)} MB · ${counts.jobs.toLocaleString()} jobs`,
          `Path: ${DB_PATH}`,
        ]} />
        <StatusCard title="AI providers" ok={providers.some((p) => p.enabled)} detail={capabilities.map((cap) => {
          const list = providers.filter((p) => p.capability === cap && p.enabled);
          return `${cap}: ${list.length ? list.map((p) => p.name).join(", ") : "not configured"}`;
        })} />
        <StatusCard title="Storage" ok={true} detail={[
          `Files: ${storage.files} · ${(storage.bytes / 1048576).toFixed(1)} MB`,
          `Dir: ${STORAGE_DIR}`,
          `${counts.media} library items`,
        ]} />
        <StatusCard title="Runtime" ok={true} detail={[
          `Node ${process.version} · Next.js ${process.env.NEXT_RUNTIME ?? "nodejs"}`,
          `Uptime: ${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m`,
          `Memory (heap): ${(mem.heapUsed / 1048576).toFixed(0)} MB · Free sys: ${(os.freemem() / 1048576).toFixed(0)} MB`,
        ]} />
        <StatusCard title="Content" ok={true} detail={[
          `${counts.tools} tools · ${counts.posts} blog posts`,
          `${counts.media} media files`,
          `Maintenance mode: ${maintenance ? "ON" : "off"}`,
        ]} />
        <StatusCard title="Security" ok={true} detail={[
          `${counts.sessions} active admin session(s)`,
          `API keys: encrypted at rest (AES-256-GCM)`,
          `Sessions/limits: enforced server-side`,
        ]} />
      </div>

      <div className="card p-6">
        <h2 className="mb-3 font-semibold">Recent errors</h2>
        {recentErrors.length === 0 ? (
          <p className="flex items-center gap-2 text-sm text-ok"><CheckCircle2 size={15} /> No recent errors — all clear.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {recentErrors.map((e, i) => (
              <div key={i} className="flex items-center justify-between rounded-lg border border-danger/20 bg-danger/5 px-3 py-2 text-sm">
                <span className="flex items-center gap-2"><XCircle size={14} className="text-danger" /> {e.action} {e.object ? <span className="text-faint">· {e.object}</span> : null}</span>
                <span className="text-xs text-faint">{e.created_at?.slice(0, 19)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <Alert kind="info" title="Production checklist">
        Set <code>APP_SECRET</code>, <code>PUBLIC_BASE_URL</code> and initial <code>ADMIN_EMAIL/ADMIN_PASSWORD</code> env vars · switch the database to
        PostgreSQL for multi-instance deployments (README → Database) · point storage at S3-compatible storage · configure at least one real AI provider
        per capability and disable the demo providers.
      </Alert>
    </div>
  );
}

function StatusCard({ title, ok, detail }: { title: string; ok: boolean; detail: string[] }) {
  return (
    <div className="card p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-bold uppercase tracking-wider text-faint">{title}</h3>
        {ok ? <span className="badge-ok"><CheckCircle2 size={11} /> OK</span> : <span className="badge-danger"><AlertTriangle size={11} /> Check</span>}
      </div>
      <ul className="flex flex-col gap-1.5">
        {detail.map((d, i) => <li key={i} className="break-all text-[13px] text-muted">{d}</li>)}
      </ul>
    </div>
  );
}
