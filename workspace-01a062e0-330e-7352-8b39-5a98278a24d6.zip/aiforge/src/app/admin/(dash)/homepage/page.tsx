import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminHomepagePage() {
  const def = getResources().homepage_sections;
  const rows = all(getDb(), "SELECT * FROM homepage_sections ORDER BY sort, id");
  return (
    <div>
      <AdminHeader title="Homepage Sections"
        description="Reorder (Sort), enable/disable and edit every homepage section. Titles, subtitles and JSON content (per-type shapes are documented in the field hints) are all editable — no code required." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
