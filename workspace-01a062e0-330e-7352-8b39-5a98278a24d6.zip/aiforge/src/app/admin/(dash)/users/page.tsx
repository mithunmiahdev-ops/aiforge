import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage() {
  const def = getResources().users;
  const rows = all(getDb(), "SELECT u.id, u.name, u.email, u.role_id, u.is_active, u.last_login_at, r.name AS role FROM admin_users u JOIN admin_roles r ON r.id = u.role_id ORDER BY u.id");
  const roles = all(getDb(), "SELECT name, description, permissions FROM admin_roles ORDER BY id");
  return (
    <div>
      <AdminHeader title="Admins & Roles"
        description="Admin accounts only — visitors never need accounts. Passwords are scrypt-hashed; the primary administrator cannot be deleted." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
      <div className="mt-8">
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-faint">Roles & permissions</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          {roles.map((r) => (
            <div key={r.name} className="card p-5">
              <div className="font-semibold">{r.name}</div>
              <p className="mt-1 text-xs text-muted">{r.description}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {JSON.parse(r.permissions).map((p: string) => <span key={p} className="badge !bg-surface2 !text-muted">{p}</span>)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
