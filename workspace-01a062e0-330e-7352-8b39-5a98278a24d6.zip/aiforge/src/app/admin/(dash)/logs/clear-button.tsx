"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Btn } from "@/components/ui";
import { Trash2 } from "lucide-react";

export function ClearLogsButton({ action }: { action: (type: string) => Promise<{ ok: boolean; message: string }> }) {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);
  const [pending, startTransition] = useTransition();

  return confirming ? (
    <span className="flex items-center gap-2 text-xs text-muted">
      Clear all logs?
      <Btn size="sm" variant="danger" loading={pending} onClick={async () => { await action("all"); setConfirming(false); startTransition(() => router.refresh()); }}>Yes, clear</Btn>
      <Btn size="sm" variant="ghost" onClick={() => setConfirming(false)}>Cancel</Btn>
    </span>
  ) : (
    <Btn size="sm" variant="secondary" onClick={() => setConfirming(true)}><Trash2 size={13} /> Clear logs</Btn>
  );
}
