import Link from "next/link";
import { getDb, all, get } from "@/db";
import { AdminHeader } from "../_lib/page-shell";
import { clearLogs } from "@/app/admin/actions";
import { ClearLogsButton } from "./clear-button";

export const dynamic = "force-dynamic";

export default async function AdminLogsPage({ searchParams }: { searchParams: { type?: string; page?: string } }) {
  const db = getDb();
  const type = searchParams.type ?? "";
  const page = Math.max(1, Number(searchParams.page ?? "1") || 1);
  const perPage = 30;
  const where = type ? "WHERE type = ?" : "";
  const args = type ? [type] : [];
  const total = get<{ c: number }>(db, `SELECT COUNT(*) AS c FROM system_logs ${where}`, ...args)?.c ?? 0;
  const rows = all(db, `SELECT * FROM system_logs ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, perPage, (page - 1) * perPage);
  const pages = Math.max(1, Math.ceil(total / perPage));

  return (
    <div>
      <AdminHeader title="Audit & System Logs" description="Admin actions, security events, generation errors and system notices. IPs are logged where legally appropriate for security purposes." />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {["", "admin_action", "security", "error", "system"].map((t) => (
          <Link key={t || "all"} href={t ? `/admin/logs?type=${t}` : "/admin/logs"} className={`chip ${type === t ? "chip-active" : ""}`}>{t || "all"}</Link>
        ))}
        <span className="flex-1" />
        <ClearLogsButton action={clearLogs} />
      </div>
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[760px] text-sm">
          <thead><tr className="border-b border-border text-left text-xs uppercase tracking-wider text-faint">
            <th className="px-4 py-3">Type</th><th className="px-4 py-3">Actor</th><th className="px-4 py-3">Action</th>
            <th className="px-4 py-3">Object</th><th className="px-4 py-3">IP</th><th className="px-4 py-3">Time</th>
          </tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-muted">No log entries.</td></tr>}
            {rows.map((l) => (
              <tr key={l.id} className="border-b border-border/60 last:border-0">
                <td className="px-4 py-2.5"><span className={`badge ${l.type === "security" ? "badge-warn" : l.type === "error" ? "badge-danger" : l.type === "admin_action" ? "badge-brand" : "badge !bg-surface2 !text-faint"}`}>{l.type}</span></td>
                <td className="px-4 py-2.5 text-muted">{l.actor}</td>
                <td className="px-4 py-2.5 font-medium">{l.action}</td>
                <td className="max-w-[200px] truncate px-4 py-2.5 text-muted">{l.object}</td>
                <td className="px-4 py-2.5 text-xs text-faint">{l.ip || "—"}</td>
                <td className="px-4 py-2.5 text-xs text-faint">{l.created_at?.replace("T", " ").slice(0, 19)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pages > 1 && (
        <nav className="mt-4 flex flex-wrap gap-2" aria-label="Pagination">
          {Array.from({ length: Math.min(pages, 10) }, (_, i) => i + 1).map((n) => (
            <Link key={n} href={`/admin/logs${type ? `?type=${type}` : ""}${n > 1 ? `${type ? "&" : "?"}page=${n}` : ""}`} className={`chip ${n === page ? "chip-active" : ""}`}>{n}</Link>
          ))}
        </nav>
      )}
    </div>
  );
}
