import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminNavigationPage() {
  const def = getResources().navigation;
  const rows = all(getDb(), "SELECT * FROM navigation_items ORDER BY location, sort, id");
  return (
    <div>
      <AdminHeader title="Navigation"
        description="Header menu (with dropdowns via “Dropdown parent”), header CTA buttons and footer columns (grouped by “Footer column name”). Reorder with Sort." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
