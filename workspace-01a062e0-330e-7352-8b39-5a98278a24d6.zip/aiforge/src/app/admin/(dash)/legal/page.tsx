import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";
import { Alert } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function AdminLegalPage() {
  const def = getResources().pages;
  const rows = all(getDb(), "SELECT * FROM pages ORDER BY slug");
  return (
    <div>
      <AdminHeader title="Legal & Site Pages"
        description="Markdown-editable pages served at /<slug> — privacy policy, terms, cookie policy, disclaimer, about and any custom page you add. System pages can be edited but not deleted." />
      <div className="mb-5">
        <Alert kind="warn">Seeded legal text is a template — have it reviewed for your jurisdiction before relying on it.</Alert>
      </div>
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
