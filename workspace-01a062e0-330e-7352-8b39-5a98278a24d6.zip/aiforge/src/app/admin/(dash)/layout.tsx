import { requireAdmin } from "@/server/auth";
import { getSettings } from "@/server/settings";
import { AdminSidebar } from "@/components/admin/sidebar";
import { logoutAction } from "./logout-action";
import { purgeExpiredSessions } from "@/server/auth";

export const dynamic = "force-dynamic";

export default async function AdminDashLayout({ children }: { children: React.ReactNode }) {
  purgeExpiredSessions();
  const user = requireAdmin();
  const site = getSettings("site");
  return (
    <div className="flex min-h-screen bg-bg">
      <div className="sticky top-0 hidden h-screen lg:block">
        <AdminSidebar userName={user.name} userRole={user.role} siteName={site.siteName} logout={logoutAction} />
      </div>
      <div className="min-w-0 flex-1">
        {/* mobile top bar */}
        <div className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-border bg-surface/90 px-4 backdrop-blur lg:hidden">
          <span className="text-sm font-bold">{site.siteName} Admin</span>
          <form action={logoutAction}><button className="btn-ghost btn-sm">Log out</button></form>
        </div>
        <div className="p-4 sm:p-6 lg:p-8">{children}</div>
      </div>
    </div>
  );
}
