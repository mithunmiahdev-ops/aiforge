import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminTemplatesPage() {
  const def = getResources().prompt_templates;
  const rows = all(getDb(), "SELECT * FROM prompt_templates ORDER BY sort, id");
  return (
    <div>
      <AdminHeader title="Prompt Templates" description="Reusable templates offered inside the AI Prompt Generator. Use {{topic}}, {{audience}}, {{tone}} placeholders." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
