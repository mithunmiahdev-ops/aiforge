import { SettingsForm, type SettingsField } from "@/components/admin/settings-form";
import { saveSettingsGroup } from "@/app/admin/actions";
import { getSettings } from "@/server/settings";
import { Alert } from "@/components/ui";

export const dynamic = "force-dynamic";

const FIELDS: SettingsField[] = [
  { name: "titleTemplate", label: "Title template", type: "text", placeholder: "{title} | {siteName}", hint: "Tokens: {title}, {siteName}. Applied to every page title." },
  { name: "defaultDescription", label: "Default meta description", type: "textarea" },
  { name: "defaultKeywords", label: "Default keywords", type: "text", hint: "Comma separated" },
  { name: "defaultOgImage", label: "Default OG image URL", type: "text", half: true, hint: "1200×630 recommended (upload in Media)" },
  { name: "twitterHandle", label: "X/Twitter handle", type: "text", half: true, placeholder: "@yourhandle" },
  { name: "robotsDefault", label: "Default robots", type: "select", half: true, options: [
    { value: "index,follow", label: "index, follow" }, { value: "noindex,nofollow", label: "noindex, nofollow" },
  ] },
  { name: "noindexSearchPage", label: "noindex the search results page", type: "toggle", hint: "Recommended — search pages shouldn't be indexed" },
];

export default async function AdminSeoPage() {
  const seo = getSettings("seo");
  return (
    <div>
      <SettingsForm group="seo" title="SEO Settings" description="Global SEO defaults. Per-tool and per-post overrides live in their editors."
        fields={FIELDS} values={seo} save={saveSettingsGroup} />
      <div className="mt-6">
        <Alert kind="info" title="Built-in technical SEO">
          Every page emits canonical URLs, Open Graph + Twitter cards, WebSite/Organization/SoftwareApplication/Article/FAQ/Breadcrumb JSON-LD,
          plus a dynamic <code>/sitemap.xml</code>, <code>/robots.txt</code> and <code>/manifest</code>. Set <code>PUBLIC_BASE_URL</code> in your environment for absolute URLs.
        </Alert>
      </div>
    </div>
  );
}
