import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminCategoriesPage() {
  const def = getResources().categories;
  const rows = all(getDb(), "SELECT * FROM tool_categories ORDER BY sort, name");
  return (
    <div>
      <AdminHeader title="Tool Categories" description="Categories power the directory filters, homepage category section and tool grouping." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
