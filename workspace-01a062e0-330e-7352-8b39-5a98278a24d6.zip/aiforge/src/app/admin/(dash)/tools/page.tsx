import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminToolsPage() {
  const def = getResources().tools;
  const rows = all(getDb(), `SELECT t.*, c.name AS category_name FROM tools t LEFT JOIN tool_categories c ON c.id = t.category_id ORDER BY t.sort, t.name`);
  return (
    <div>
      <AdminHeader title="AI Tools"
        description="Add, edit and configure every tool. Type controls the interface; capability controls which AI provider powers it. Limits are enforced server-side." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
