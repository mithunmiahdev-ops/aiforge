"use client";
import { useState } from "react";
import { Alert, Btn, Field, Input } from "@/components/ui";
import { changeOwnPassword } from "@/app/admin/actions";
import { KeyRound } from "lucide-react";

export function ChangePasswordForm() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const [saving, setSaving] = useState(false);

  return (
    <form className="card max-w-lg p-6" onSubmit={async (e) => {
      e.preventDefault();
      setSaving(true);
      const result = await changeOwnPassword(current, next);
      setFeedback(result);
      setSaving(false);
      if (result.ok) { setCurrent(""); setNext(""); }
    }}>
      <h2 className="flex items-center gap-2 font-semibold"><KeyRound size={15} className="text-brand" /> Change my password</h2>
      <p className="mt-1 text-xs text-faint">Minimum 10 characters. You stay signed in after changing it.</p>
      {feedback && <div className="mt-4"><Alert kind={feedback.ok ? "success" : "danger"}>{feedback.message}</Alert></div>}
      <div className="mt-4 grid gap-4">
        <Field label="Current password"><Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} required autoComplete="current-password" /></Field>
        <Field label="New password"><Input type="password" value={next} onChange={(e) => setNext(e.target.value)} required minLength={10} autoComplete="new-password" /></Field>
      </div>
      <Btn type="submit" className="mt-4" loading={saving}>Update password</Btn>
    </form>
  );
}
