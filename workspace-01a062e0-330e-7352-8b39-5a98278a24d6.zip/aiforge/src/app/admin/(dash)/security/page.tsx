import { SettingsForm, type SettingsField } from "@/components/admin/settings-form";
import { saveSettingsGroup } from "@/app/admin/actions";
import { getSettings } from "@/server/settings";
import { getDb, all, get } from "@/db";
import { AdminHeader } from "../_lib/page-shell";
import { ChangePasswordForm } from "./change-password";

export const dynamic = "force-dynamic";

const FIELDS: SettingsField[] = [
  { name: "loginMaxAttempts", label: "Login attempts before lockout", type: "number", min: 1, half: true },
  { name: "loginWindowMinutes", label: "Login attempt window (minutes)", type: "number", min: 1, half: true },
  { name: "sessionHours", label: "Admin session duration (hours)", type: "number", min: 1, half: true },
  { name: "globalDailyLimitPerIp", label: "Global generations per IP / day", type: "number", min: 1, half: true },
  { name: "contactPerHour", label: "Contact messages per hour / IP", type: "number", min: 1, half: true },
];

export default async function AdminSecurityPage() {
  const security = getSettings("security");
  const db = getDb();
  const attempts = all(db, "SELECT ip, email, success, created_at FROM login_attempts ORDER BY id DESC LIMIT 10");
  const sessions = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM admin_sessions WHERE expires_at > datetime('now')")?.c ?? 0;

  return (
    <div className="flex flex-col gap-8">
      <SettingsForm group="security" title="Security & Abuse Prevention" description="Rate limits enforced server-side for anonymous usage and admin access."
        fields={FIELDS} values={security as any} save={saveSettingsGroup} />

      <ChangePasswordForm />

      <div>
        <AdminHeader title="Active sessions & recent attempts" description={`${sessions} active admin session(s).`} />
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[480px] text-sm">
            <thead><tr className="border-b border-border text-left text-xs uppercase tracking-wider text-faint">
              <th className="px-4 py-3">IP</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Result</th><th className="px-4 py-3">Time</th>
            </tr></thead>
            <tbody>
              {attempts.length === 0 && <tr><td colSpan={4} className="px-4 py-8 text-center text-muted">No login attempts recorded.</td></tr>}
              {attempts.map((a, i) => (
                <tr key={i} className="border-b border-border/60 last:border-0">
                  <td className="px-4 py-2.5 text-muted">{a.ip}</td>
                  <td className="px-4 py-2.5 text-muted">{a.email}</td>
                  <td className="px-4 py-2.5"><span className={a.success ? "badge-ok" : "badge-danger"}>{a.success ? "success" : "failed"}</span></td>
                  <td className="px-4 py-2.5 text-xs text-faint">{a.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
