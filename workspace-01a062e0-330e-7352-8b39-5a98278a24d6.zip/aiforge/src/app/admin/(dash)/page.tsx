import Link from "next/link";
import fs from "node:fs";
import { getDb, get, all } from "@/db";
import { DB_PATH } from "@/db";
import { providerStatus, providerConfigured } from "@/server/providers";
import { getSettings } from "@/server/settings";
import { storageStats } from "@/server/storage";
import { requireAdmin } from "@/server/auth";
import { LineChart, BarList, Donut } from "@/components/charts";
import { Alert } from "@/components/ui";
import { Activity, Database, HardDrive, Plug, Clock, TrendingUp, DollarSign, Newspaper, Wrench } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminDashboard({ searchParams }: { searchParams: { denied?: string } }) {
  const user = requireAdmin();
  const db = getDb();
  const usage = getSettings("usage");
  const ads = getSettings("ads");

  const totals = get<{ total: number; completed: number; failed: number; today: number; week: number; month: number; today_err: number }>(db, `
    SELECT COUNT(*) AS total,
      SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
      SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS failed,
      SUM(CASE WHEN created_at >= date('now','start of day') THEN 1 ELSE 0 END) AS today,
      SUM(CASE WHEN created_at >= date('now','-6 days') THEN 1 ELSE 0 END) AS week,
      SUM(CASE WHEN created_at >= date('now','start of month') THEN 1 ELSE 0 END) AS month,
      SUM(CASE WHEN status='failed' AND created_at >= date('now','start of day') THEN 1 ELSE 0 END) AS today_err
    FROM generation_jobs`)!;
  const byCapability = all<{ capability: string; c: number }>(db, "SELECT capability, COUNT(*) AS c FROM generation_jobs WHERE status='completed' GROUP BY capability");
  const byProvider = all<{ provider: string; c: number; model: string }>(db, "SELECT provider, model, COUNT(*) AS c FROM generation_jobs WHERE status='completed' AND provider != '' GROUP BY provider, model ORDER BY c DESC LIMIT 6");
  const topTools = all<{ tool_name: string; c: number; s: number }>(db, "SELECT tool_name, COUNT(*) AS c, SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS s FROM generation_jobs GROUP BY tool_name ORDER BY c DESC LIMIT 6");
  const recentJobs = all(db, "SELECT id, tool_name, status, error_code, created_at FROM generation_jobs ORDER BY created_at DESC LIMIT 8");
  const recentLogs = all(db, "SELECT type, actor, action, object, created_at FROM system_logs ORDER BY id DESC LIMIT 8");
  const daily = all<{ d: string; c: number }>(db, "SELECT date(created_at) AS d, COUNT(*) AS c FROM generation_jobs WHERE created_at >= date('now','-29 days') GROUP BY date(created_at) ORDER BY d");

  // fill 30-day series
  const series: number[] = [];
  const labels: string[] = [];
  for (let i = 29; i >= 0; i--) {
    const day = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    series.push(daily.find((r) => r.d === day)?.c ?? 0);
    labels.push(day.slice(5));
  }

  const cost = (cap: string) => (usage.costPerGeneration as any)[cap] ?? 0;
  const estimatedCost = byCapability.reduce((sum, r) => sum + r.c * cost(r.capability), 0);
  const providers = providerStatus();
  const storage = storageStats();
  const dbOk = fs.existsSync(DB_PATH);
  const messages = get<{ c: number }>(db, "SELECT COUNT(*) AS c FROM contact_messages WHERE is_read = 0")?.c ?? 0;
  const posts = get<{ drafts: number; published: number }>(db, "SELECT SUM(CASE WHEN status='draft' THEN 1 ELSE 0 END) AS drafts, SUM(CASE WHEN status='published' THEN 1 ELSE 0 END) AS published FROM blog_posts")!;
  const uptime = process.uptime();

  const capStatus = (["video", "image", "text", "audio"] as const).map((cap) => ({
    cap, configured: providerConfigured(cap),
    providers: providers.filter((p) => p.capability === cap && p.enabled).length,
  }));

  return (
    <div className="flex flex-col gap-6">
      {searchParams.denied && <Alert kind="warn" title="Access denied">Your role doesn't permit that section.</Alert>}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Welcome back, {user.name.split(" ")[0]} 👋</h1>
          <p className="mt-1 text-sm text-muted">Platform overview — usage, providers and system health.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/blog/new" className="btn-secondary btn-sm"><Newspaper size={14} /> New post</Link>
          <Link href="/admin/tools" className="btn-primary btn-sm"><Wrench size={14} /> Manage tools</Link>
        </div>
      </div>

      {/* stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Activity size={16} />} label="Total generations" value={totals.total ?? 0} sub={`${totals.completed ?? 0} completed · ${totals.failed ?? 0} failed`} />
        <StatCard icon={<Clock size={16} />} label="Today" value={totals.today ?? 0} sub={`${totals.today_err ?? 0} errors today`} />
        <StatCard icon={<TrendingUp size={16} />} label="This week / month" value={totals.week ?? 0} sub={`${totals.month ?? 0} this month`} />
        <StatCard icon={<DollarSign size={16} />} label="Est. API cost" value={`$${estimatedCost.toFixed(2)}`} sub={ads.adRevenueMonthly ? `Ad revenue (manual): ${ads.adRevenueMonthly}` : "Set cost rates in Usage"} />
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="card p-6 xl:col-span-2">
          <h2 className="mb-4 font-semibold">Generations — last 30 days</h2>
          <LineChart data={series} labels={labels} />
        </div>
        <div className="card p-6">
          <h2 className="mb-4 font-semibold">Outcomes</h2>
          <Donut parts={[
            { label: "Completed", value: totals.completed ?? 0, color: "rgb(16 163 127)" },
            { label: "Failed", value: totals.failed ?? 0, color: "rgb(220 60 74)" },
            { label: "Other", value: Math.max(0, (totals.total ?? 0) - (totals.completed ?? 0) - (totals.failed ?? 0)), color: "rgb(var(--c-faint))" },
          ]} />
          <h3 className="mb-3 mt-6 text-sm font-semibold">By capability</h3>
          <BarList items={["video", "image", "text", "audio"].map((cap) => ({ label: cap, value: byCapability.find((r) => r.capability === cap)?.c ?? 0 }))} />
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="card p-6">
          <h2 className="mb-4 font-semibold">Top tools</h2>
          <BarList items={topTools.map((t) => ({ label: t.tool_name || "(removed tool)", value: t.c, hint: `${t.s} ok` }))} />
        </div>
        <div className="card p-6">
          <h2 className="mb-4 font-semibold">API usage by provider</h2>
          {byProvider.length === 0 ? <p className="text-sm text-faint">No provider calls yet.</p> : (
            <BarList items={byProvider.map((p) => ({ label: `${p.provider}`, value: p.c, hint: p.model })) } />
          )}
          <div className="mt-6 flex flex-col gap-2">
            {capStatus.map((c) => (
              <div key={c.cap} className="flex items-center justify-between text-sm">
                <span className="capitalize text-muted">{c.cap}</span>
                <span className={`badge ${c.configured ? "badge-ok" : "badge-warn"}`}>
                  {c.configured ? `online · ${c.providers} provider${c.providers === 1 ? "" : "s"}` : "not configured"}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="card p-6">
          <h2 className="mb-4 flex items-center gap-2 font-semibold"><Plug size={15} className="text-brand" /> System status</h2>
          <div className="flex flex-col gap-3 text-sm">
            <StatusRow icon={<Database size={14} />} label="Database" ok={dbOk} detail={dbOk ? "connected (SQLite WAL)" : "not found"} />
            <StatusRow icon={<HardDrive size={14} />} label="Storage" ok={true} detail={`${storage.files} files · ${(storage.bytes / 1048576).toFixed(1)} MB`} />
            <StatusRow icon={<Clock size={14} />} label="Uptime" ok={true} detail={`${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`} />
            <StatusRow icon={<Newspaper size={14} />} label="Blog" ok={true} detail={`${posts.published ?? 0} published · ${posts.drafts ?? 0} drafts`} />
            <StatusRow icon={<Activity size={14} />} label="Unread messages" ok={messages === 0} detail={messages === 0 ? "none" : `${messages} new`} />
            <Link href="/admin/system" className="mt-1 text-xs font-semibold text-brand hover:underline">Full system report →</Link>
          </div>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <div className="card p-6">
          <h2 className="mb-4 font-semibold">Recent generations</h2>
          <div className="flex flex-col gap-2">
            {recentJobs.length === 0 && <p className="text-sm text-faint">No generations yet. Enable a provider and try a tool!</p>}
            {recentJobs.map((j) => (
              <div key={j.id} className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2 text-sm">
                <span className="truncate">{j.tool_name}</span>
                <span className="flex shrink-0 items-center gap-2">
                  <span className="text-xs text-faint">{j.created_at?.slice(5, 16)}</span>
                  <span className={`badge ${j.status === "completed" ? "badge-ok" : j.status === "failed" ? "badge-danger" : "badge-warn"}`}>{j.status}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="card p-6">
          <h2 className="mb-4 font-semibold">Recent admin activity</h2>
          <div className="flex flex-col gap-2">
            {recentLogs.length === 0 && <p className="text-sm text-faint">No activity yet.</p>}
            {recentLogs.map((l, i) => (
              <div key={i} className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2 text-sm">
                <span className="truncate"><span className="font-medium">{l.actor}</span> · {l.action} {l.object ? <span className="text-faint">({l.object})</span> : null}</span>
                <span className="shrink-0 text-xs text-faint">{l.created_at?.slice(5, 16)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: any; sub?: string }) {
  return (
    <div className="card p-5">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-faint">{icon} {label}</div>
      <div className="gradient-text mt-2 text-3xl font-black">{typeof value === "number" ? value.toLocaleString() : value}</div>
      {sub && <div className="mt-1 text-xs text-muted">{sub}</div>}
    </div>
  );
}

function StatusRow({ icon, label, ok, detail }: { icon: React.ReactNode; label: string; ok: boolean; detail: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="flex items-center gap-2 text-muted">{icon} {label}</span>
      <span className="flex items-center gap-2">
        <span className="text-xs text-faint">{detail}</span>
        <span className={`h-2 w-2 rounded-full ${ok ? "bg-ok" : "bg-danger"}`} aria-hidden />
      </span>
    </div>
  );
}
