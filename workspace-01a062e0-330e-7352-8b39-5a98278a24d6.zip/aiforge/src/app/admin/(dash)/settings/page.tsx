import { SettingsForm, type SettingsField } from "@/components/admin/settings-form";
import { saveSettingsGroup } from "@/app/admin/actions";
import { getSettings } from "@/server/settings";
import { Alert } from "@/components/ui";

export const dynamic = "force-dynamic";

const SYSTEM_FIELDS: SettingsField[] = [
  { name: "maintenanceOn", label: "Maintenance mode", type: "toggle", hint: "Visitors see a “Coming back soon” page; admins stay bypassed" },
  { name: "maintenanceMessage", label: "Maintenance message", type: "textarea" },
];

const PRICING_FIELDS: SettingsField[] = [
  { name: "plans", label: "Pricing plans (JSON array)", type: "json", hint: '[{name, price, period, description, features[], ctaLabel, ctaHref, highlight, enabled}] — keep it honest: the Free plan is real.' },
];

const AUDIO_FIELDS: SettingsField[] = [
  { name: "languages", label: "Audio languages (JSON)", type: "json", half: true, hint: '[{code:"en", label:"English"}]' },
  { name: "voices", label: "Voices (JSON)", type: "json", half: true, hint: '[{id:"alloy", label:"Alloy — neutral"}] — IDs map to your TTS provider voices' },
];

const USAGE_FIELDS: SettingsField[] = [
  { name: "costPerGeneration", label: "Estimated cost per generation (JSON)", type: "json", hint: '{"video":0.1,"image":0.04,"text":0.001,"audio":0.01} — used for the dashboard cost estimate' },
];

export default async function AdminGeneralSettingsPage() {
  const system = getSettings("system");
  const pricing = getSettings("pricing");
  const audio = getSettings("audio");
  const usage = getSettings("usage");

  return (
    <div className="flex flex-col gap-10">
      <SettingsForm group="system" title="General Settings" description="Maintenance mode and global switches."
        fields={SYSTEM_FIELDS} values={{ maintenanceOn: system.maintenanceOn, maintenanceMessage: system.maintenanceMessage }} save={saveSettingsGroup} />
      <SettingsForm group="pricing" title="Pricing Page" description="Plans shown on /pricing. Only publish what's true."
        fields={PRICING_FIELDS} values={{ plans: JSON.stringify(pricing.plans, null, 2) }} save={saveSettingsGroup} />
      <SettingsForm group="audio" title="Audio Tool Options" description="Languages and voices offered by the AI Audio Generator."
        fields={AUDIO_FIELDS} values={{ languages: JSON.stringify(audio.languages, null, 2), voices: JSON.stringify(audio.voices, null, 2) }} save={saveSettingsGroup} />
      <SettingsForm group="usage" title="Usage Economics" description="Cost assumptions for the dashboard's estimated API cost."
        fields={USAGE_FIELDS} values={{ costPerGeneration: JSON.stringify(usage.costPerGeneration, null, 2) }} save={saveSettingsGroup} />
      <Alert kind="info" title="Environment variables">
        Secrets like APP_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD and PUBLIC_BASE_URL are read from the environment (see .env.example / README).
        Set APP_SECRET in production so encrypted API keys survive redeploys.
      </Alert>
    </div>
  );
}
