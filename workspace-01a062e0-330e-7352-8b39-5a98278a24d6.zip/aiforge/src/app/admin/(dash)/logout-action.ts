"use server";
import { destroySession, getAdminUser } from "@/server/auth";
import { logEvent } from "@/server/audit";
import { redirect } from "next/navigation";

export async function logoutAction(): Promise<void> {
  const user = getAdminUser();
  if (user) logEvent({ type: "admin_action", actor: user.email, action: "logout" });
  destroySession();
  redirect("/admin/login");
}
