import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";
import { Alert } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function AdminProvidersPage() {
  const def = getResources().providers;
  const rows = all(getDb(), "SELECT id, name, capability, type, endpoint, model, enabled, priority, timeout_ms, max_requests, notes, (LENGTH(api_key_encrypted) > 0) AS has_key FROM ai_providers ORDER BY capability, priority");
  return (
    <div>
      <AdminHeader title="AI Providers"
        description="Connect the AI services that power each capability. API keys are encrypted at rest (AES-256-GCM) and never leave the server. Lower priority runs first; failures fall through the chain." />
      <div className="mb-5">
        <Alert kind="info" title="How adapters work">
          <b>OpenAI-compatible</b> — works with OpenAI or any compatible API (chat, images, speech). <b>Custom HTTP</b> — your endpoint receives
          {" "}<code>{"{tool, capability, params, prompt}"}</code> and must return JSON with <code>{"{url}"}</code>, <code>{"{b64, mime}"}</code> or <code>{"{text}"}</code> (use this for video providers).
                          <b> Demo</b> — watermarked local placeholders for testing the flow. Keys are stored server-side only.
        </Alert>
      </div>
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
