import { SettingsForm, type SettingsField } from "@/components/admin/settings-form";
import { saveSettingsGroup, saveResource, deleteResource } from "@/app/admin/actions";
import { getSettings } from "@/server/settings";
import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { Alert } from "@/components/ui";

export const dynamic = "force-dynamic";

const FIELDS: SettingsField[] = [
  { name: "enabled", label: "Enable ads globally", type: "toggle" },
  { name: "publisherId", label: "AdSense publisher ID", type: "text", half: true, placeholder: "ca-pub-XXXXXXXXXXXXXXXX" },
  { name: "testMode", label: "Test mode (outline placeholders, no live ads)", type: "toggle", hint: "Verify placements safely before going live" },
  { name: "adRevenueMonthly", label: "Ad revenue this month (manual, for dashboard)", type: "text", half: true, placeholder: "$0.00" },
  { name: "adNotesMonthly", label: "Monetization notes (private)", type: "textarea" },
];

export default async function AdminAdsPage() {
  const ads = getSettings("ads");
  const def = getResources().ads;
  const rows = all(getDb(), "SELECT * FROM ad_placements ORDER BY sort, id");
  return (
    <div className="flex flex-col gap-8">
      <SettingsForm group="ads" title="Ads (Google AdSense)" description="Monetization settings. Nothing renders unless you enable it AND provide a valid ca-pub-… publisher ID."
        fields={FIELDS} values={ads} save={saveSettingsGroup} />
      <div>
        <Alert kind="warn" title="Policy reminders">
          Ads are always labeled “Advertisement” and are never placed inside generation control areas. Use exclusions to keep ads off sensitive pages.
          Test mode shows outlined placeholders instead of live ads. Never ask or incentivize clicks — that violates AdSense policies.
        </Alert>
      </div>
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
      <p className="text-xs text-faint">ads.txt is served automatically at /ads.txt once a publisher ID is set.</p>
    </div>
  );
}
