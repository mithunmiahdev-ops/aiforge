import { SettingsForm, type SettingsField } from "@/components/admin/settings-form";
import { saveSettingsGroup } from "@/app/admin/actions";
import { getSettings } from "@/server/settings";
import { Alert } from "@/components/ui";

export const dynamic = "force-dynamic";

const FIELDS: SettingsField[] = [
  { name: "gaEnabled", label: "Enable Google Analytics 4", type: "toggle" },
  { name: "gaMeasurementId", label: "GA4 Measurement ID", type: "text", half: true, placeholder: "G-XXXXXXXXXX" },
  { name: "gtmEnabled", label: "Enable Google Tag Manager", type: "toggle" },
  { name: "gtmContainerId", label: "GTM Container ID", type: "text", half: true, placeholder: "GTM-XXXXXXX" },
  { name: "searchConsoleVerification", label: "Search Console verification code", type: "text", half: true, placeholder: "content value from the meta tag" },
  { name: "requireConsent", label: "Require cookie consent before tracking", type: "toggle", hint: "Recommended — shows the consent banner and loads trackers only after opt-in" },
];

export default async function AdminAnalyticsPage() {
  const analytics = getSettings("analytics");
  return (
    <div>
      <SettingsForm group="analytics" title="Analytics" description="Tracking is only injected when enabled here — nothing is hard-coded. IDs are validated before loading."
        fields={FIELDS} values={analytics} save={saveSettingsGroup} />
      <div className="mt-6">
        <Alert kind="info" title="Privacy notes">
          With consent required, GA/GTM load only after the visitor allows optional cookies. IP anonymization is enabled for GA4.
          The Search Console verification meta tag renders in the page head regardless of consent (it is not tracking).
        </Alert>
      </div>
    </div>
  );
}
