import { getDb, all } from "@/db";
import { getResources, clientDef } from "@/server/resources";
import { ResourceManager } from "@/components/admin/resource-manager";
import { saveResource, deleteResource } from "@/app/admin/actions";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

export default async function AdminFaqsPage() {
  const def = getResources().faqs;
  const rows = all(getDb(), "SELECT * FROM faqs ORDER BY section, sort, id");
  return (
    <div>
      <AdminHeader title="FAQs" description="Questions shown on the homepage (section “home”), on any tool page (section = tool slug, e.g. ai-video-generator) and anywhere else you embed them." />
      <ResourceManager def={clientDef(def)} rows={rows} save={saveResource} del={deleteResource} />
    </div>
  );
}
