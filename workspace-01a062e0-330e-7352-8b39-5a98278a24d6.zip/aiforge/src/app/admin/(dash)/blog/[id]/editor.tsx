"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, Btn, Field, Input, Select, Textarea, Toggle } from "@/components/ui";
import { saveBlogPost } from "@/app/admin/actions";
import { marked } from "marked";
import { Eye, FileText, Save } from "lucide-react";

export interface PostData {
  id: number; title: string; slug: string; excerpt: string; content: string;
  status: string; publish_at: string | null; author_name: string;
  featured_image: string; featured_image_alt: string; category_id: string;
  tags: string; faq: string; seo_title: string; meta_description: string;
  canonical_url: string; og_image: string; noindex: boolean;
}

export function BlogEditor({ post, categories }: { post: PostData | null; categories: { value: string; label: string }[] }) {
  const router = useRouter();
  const [v, setV] = useState<PostData>(post ?? {
    id: 0, title: "", slug: "", excerpt: "", content: "", status: "draft",
    publish_at: new Date().toISOString().slice(0, 16), author_name: "Admin",
    featured_image: "", featured_image_alt: "", category_id: "", tags: "", faq: "[]",
    seo_title: "", meta_description: "", canonical_url: "", og_image: "", noindex: false,
  });
  const [feedback, setFeedback] = useState<{ ok: boolean; message: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(false);
  const set = (k: keyof PostData, val: any) => setV((s) => ({ ...s, [k]: val }));

  const previewHtml = useMemo(() => marked.parse(v.content || "", { async: false }) as string, [v.content]);
  const words = v.content.split(/\s+/).filter(Boolean).length;

  const submit = async (statusOverride?: string) => {
    setSaving(true);
    const fd = new FormData();
    if (v.id) fd.set("__id", String(v.id));
    for (const key of Object.keys(v) as (keyof PostData)[]) {
      if (key === "id") continue;
      if (key === "noindex") { if (v.noindex) fd.set("noindex", "on"); continue; }
      const publishLocal = v.publish_at ? new Date(v.publish_at).toISOString() : "";
      fd.set(key, key === "publish_at" ? publishLocal : String(v[key] ?? ""));
    }
    if (statusOverride) fd.set("status", statusOverride);
    const result = await saveBlogPost(fd);
    setFeedback(result);
    setSaving(false);
    if (result.ok) {
      if (!v.id && post === null) router.push("/admin/blog");
      else router.refresh();
    }
  };

  return (
    <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
      <div className="flex flex-col gap-5">
        {feedback && <Alert kind={feedback.ok ? "success" : "danger"}>{feedback.message}</Alert>}

        <div className="card p-6">
          <Field label="Title"><Input value={v.title} onChange={(e) => set("title", e.target.value)} placeholder="Article title (H1)" maxLength={160} /></Field>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="Slug" hint={`/blog/${v.slug || "auto-from-title"}`}><Input value={v.slug} onChange={(e) => set("slug", e.target.value)} placeholder="auto" /></Field>
            <Field label="Author"><Input value={v.author_name} onChange={(e) => set("author_name", e.target.value)} /></Field>
          </div>
          <Field label="Excerpt" className="mt-4"><Textarea className="!min-h-[70px]" value={v.excerpt} onChange={(e) => set("excerpt", e.target.value)} maxLength={400} placeholder="1–2 sentence summary shown in listings and meta descriptions" /></Field>
        </div>

        <div className="card p-6">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-semibold"><FileText size={15} className="text-brand" /> Content (markdown) · {words} words · ≈{Math.max(1, Math.round(words / 200))} min read</div>
            <Btn size="sm" variant="secondary" onClick={() => setPreview(!preview)}><Eye size={13} /> {preview ? "Edit" : "Preview"}</Btn>
          </div>
          {preview ? (
            <div className="prose-site max-h-[640px] overflow-y-auto rounded-xl border border-border bg-surface2/40 p-5" dangerouslySetInnerHTML={{ __html: previewHtml }} />
          ) : (
            <Textarea className="!min-h-[480px] font-mono !text-[13px] leading-6" value={v.content} onChange={(e) => set("content", e.target.value)}
              placeholder={"## Heading\n\nWrite your article in markdown…"} spellCheck />
          )}
        </div>

        <div className="card p-6">
          <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-faint">SEO</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="SEO title" hint={`${(v.seo_title || v.title).length}/60 characters`}><Input value={v.seo_title} onChange={(e) => set("seo_title", e.target.value)} placeholder="Defaults to title" /></Field>
            <Field label="Canonical URL" hint="Leave empty for the default"><Input value={v.canonical_url} onChange={(e) => set("canonical_url", e.target.value)} placeholder="https://" /></Field>
          </div>
          <Field label="Meta description" className="mt-4" hint={`${(v.meta_description || v.excerpt).length}/160 characters`}>
            <Textarea className="!min-h-[70px]" value={v.meta_description} onChange={(e) => set("meta_description", e.target.value)} placeholder="Defaults to excerpt" />
          </Field>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="Featured image URL" hint="Upload in Media, paste the URL"><Input value={v.featured_image} onChange={(e) => set("featured_image", e.target.value)} /></Field>
            <Field label="Featured image alt text"><Input value={v.featured_image_alt} onChange={(e) => set("featured_image_alt", e.target.value)} /></Field>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="OG image URL (optional)" hint="Overrides featured image for social cards"><Input value={v.og_image} onChange={(e) => set("og_image", e.target.value)} /></Field>
            <div className="flex items-center justify-between rounded-xl border border-border bg-surface2/40 px-4 py-3">
              <div><div className="text-sm font-semibold">noindex</div><div className="text-xs text-faint">Hide from search engines</div></div>
              <Toggle checked={v.noindex} onChange={(b) => set("noindex", b)} label="noindex" />
            </div>
          </div>
          <Field label="FAQ (JSON — rendered as FAQ schema + section)" className="mt-4" hint='[{"question":"…?","answer":"…"}]'>
            <Textarea className="!min-h-[90px] font-mono !text-[13px]" value={v.faq} onChange={(e) => set("faq", e.target.value)} spellCheck={false} />
          </Field>
        </div>
      </div>

      {/* sidebar */}
      <aside className="flex flex-col gap-5">
        <div className="card sticky top-6 p-5">
          <Field label="Status">
            <Select value={v.status} onChange={(e) => set("status", e.target.value)}>
              <option value="draft">Draft</option>
              <option value="scheduled">Scheduled</option>
              <option value="published">Published</option>
            </Select>
          </Field>
          <Field label="Publish at" className="mt-4" hint="Future date + Scheduled = auto-publish time reached">
            <Input type="datetime-local" value={(v.publish_at ?? "").slice(0, 16)} onChange={(e) => set("publish_at", e.target.value)} />
          </Field>
          <Field label="Category" className="mt-4">
            <Select value={v.category_id} onChange={(e) => set("category_id", e.target.value)}>
              <option value="">— none —</option>
              {categories.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </Select>
          </Field>
          <Field label="Tags" className="mt-4" hint="Comma separated, max 10"><Input value={v.tags} onChange={(e) => set("tags", e.target.value)} placeholder="ai video, prompting" /></Field>
          <div className="mt-6 flex flex-col gap-2">
            <Btn loading={saving} onClick={() => submit()}><Save size={15} /> Save</Btn>
            <Btn variant="secondary" disabled={saving} onClick={() => submit("published")}>Save & publish</Btn>
          </div>
        </div>
      </aside>
    </div>
  );
}
