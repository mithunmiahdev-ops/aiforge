import { notFound } from "next/navigation";
import { getDb, get, all } from "@/db";
import { AdminHeader } from "../../_lib/page-shell";
import { BlogEditor } from "./editor";

export const dynamic = "force-dynamic";

export default async function AdminBlogEditorPage({ params }: { params: { id: string } }) {
  const db = getDb();
  const isNew = params.id === "new";
  let post: any = null;
  if (!isNew) {
    if (!/^\d+$/.test(params.id)) notFound();
    post = get(db, "SELECT * FROM blog_posts WHERE id = ?", Number(params.id));
    if (!post) notFound();
  }
  const categories = all(db, "SELECT id, name FROM blog_categories ORDER BY name");

  return (
    <div>
      <AdminHeader title={isNew ? "New article" : `Edit: ${post.title}`}
        description="Markdown editor with scheduling, SEO, tags and FAQ schema support." />
      <BlogEditor
        post={post ? {
          id: post.id, title: post.title, slug: post.slug, excerpt: post.excerpt, content: post.content,
          status: post.status, publish_at: post.publish_at, author_name: post.author_name,
          featured_image: post.featured_image, featured_image_alt: post.featured_image_alt,
          category_id: String(post.category_id ?? ""), tags: (JSON.parse(post.tags || "[]")).join(", "),
          faq: JSON.stringify(JSON.parse(post.faq || "[]"), null, 2),
          seo_title: post.seo_title, meta_description: post.meta_description,
          canonical_url: post.canonical_url, og_image: post.og_image, noindex: !!post.noindex,
        } : null}
        categories={categories.map((c) => ({ value: String(c.id), label: c.name }))}
      />
    </div>
  );
}
