"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Btn, Modal } from "@/components/ui";
import { deleteBlogPost } from "@/app/admin/actions";
import { Trash2 } from "lucide-react";

export function DeletePostButton({ id, title }: { id: number; title: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  return (
    <>
      <button className="btn-danger btn-sm" onClick={() => setOpen(true)} aria-label={`Delete ${title}`}><Trash2 size={14} /></button>
      <Modal open={open} onClose={() => setOpen(false)} title="Delete article">
        <p className="text-sm text-muted">Delete <span className="font-semibold text-fg">{title}</span>? This cannot be undone.</p>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setOpen(false)}>Cancel</Btn>
          <Btn variant="danger" loading={pending} onClick={async () => {
            await deleteBlogPost(id);
            setOpen(false);
            startTransition(() => router.refresh());
          }}><Trash2 size={14} /> Delete</Btn>
        </div>
      </Modal>
    </>
  );
}
