import Link from "next/link";
import { getDb, all } from "@/db";
import { AdminHeader } from "../_lib/page-shell";
import { DeletePostButton } from "./delete-button";
import { Pencil, Plus } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminBlogPage() {
  const db = getDb();
  const rows = all(db, `SELECT p.id, p.title, p.slug, p.status, p.publish_at, p.published_at, p.updated_at, p.author_name, p.reading_minutes,
    c.name AS category_name FROM blog_posts p LEFT JOIN blog_categories c ON c.id = p.category_id ORDER BY COALESCE(p.publish_at, p.created_at) DESC`);
  const statuses: Record<string, string> = { draft: "badge-warn", published: "badge-ok", scheduled: "badge-brand" };

  return (
    <div>
      <AdminHeader title="Blog" description="Draft, schedule and publish SEO-ready articles. The editor supports markdown, categories, tags, FAQ blocks, featured images and per-post SEO."
        actions={<Link href="/admin/blog/new" className="btn-primary btn-sm"><Plus size={14} /> New article</Link>} />
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[760px] text-sm">
          <thead><tr className="border-b border-border text-left text-xs uppercase tracking-wider text-faint">
            <th className="px-4 py-3">Title</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Author</th><th className="px-4 py-3">Publish at</th><th className="px-4 py-3 text-right">Actions</th>
          </tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-muted">No articles yet — create your first one.</td></tr>}
            {rows.map((p) => (
              <tr key={p.id} className="border-b border-border/60 last:border-0 hover:bg-surface2/40">
                <td className="px-4 py-3">
                  <div className="font-medium">{p.title}</div>
                  <div className="text-xs text-faint">/{p.slug} · {p.reading_minutes} min</div>
                </td>
                <td className="px-4 py-3 text-muted">{p.category_name ?? "—"}</td>
                <td className="px-4 py-3"><span className={`badge ${statuses[p.status] ?? ""}`}>{p.status}</span></td>
                <td className="px-4 py-3 text-muted">{p.author_name}</td>
                <td className="px-4 py-3 text-xs text-faint">{p.publish_at?.slice(0, 16).replace("T", " ")}</td>
                <td className="whitespace-nowrap px-4 py-3 text-right">
                  <Link href={`/admin/blog/${p.id}`} className="btn-ghost btn-sm mr-1" aria-label={`Edit ${p.title}`}><Pencil size={14} /></Link>
                  <DeletePostButton id={p.id} title={p.title} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
