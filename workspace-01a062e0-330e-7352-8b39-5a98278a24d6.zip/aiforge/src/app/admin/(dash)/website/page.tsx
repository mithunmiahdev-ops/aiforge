import { SettingsForm, type SettingsField } from "@/components/admin/settings-form";
import { saveSettingsGroup } from "@/app/admin/actions";
import { getSettings } from "@/server/settings";
import { AdminHeader } from "../_lib/page-shell";

export const dynamic = "force-dynamic";

const FIELDS: SettingsField[] = [
  { name: "siteName", label: "Site name", type: "text", half: true },
  { name: "tagline", label: "Tagline", type: "text", half: true, hint: "Used in the browser title and manifest" },
  { name: "description", label: "Site description", type: "textarea", hint: "Used for Organization schema and social defaults" },
  { name: "logoUrl", label: "Logo URL", type: "text", half: true, placeholder: "/api/media/uploads/… (upload in Media)" },
  { name: "faviconUrl", label: "Favicon URL", type: "text", half: true, placeholder: "/api/media/uploads/…" },
  { name: "primaryColor", label: "Primary color", type: "color", half: true },
  { name: "secondaryColor", label: "Secondary color", type: "color", half: true },
  { name: "defaultTheme", label: "Default theme", type: "select", half: true, options: [{ value: "dark", label: "Dark" }, { value: "light", label: "Light" }] },
  { name: "contactEmail", label: "Contact email", type: "text", half: true },
  { name: "footerDescription", label: "Footer description", type: "textarea" },
  { name: "copyright", label: "Copyright line", type: "text", hint: "“©” and the year are added automatically" },
  { name: "socials", label: "Social links (JSON)", type: "json", hint: '{"twitter":"https://…","youtube":"","github":"","linkedin":"","instagram":"","facebook":""}' },
];

export default async function AdminWebsitePage() {
  const site = getSettings("site");
  return (
    <SettingsForm group="site" title="Site & Branding" description="Identity, colors, logo, footer and social links — applied live across the site."
      fields={FIELDS} values={{ ...site, socials: JSON.stringify(site.socials, null, 2) }} save={saveSettingsGroup} />
  );
}
