"use server";
import { revalidatePath } from "next/cache";
import { getDb, get, run, nowIso } from "@/db";
import { assertAdmin, requestIp } from "@/server/auth";
import { getResources, validateAndCoerce, type ResourceDef } from "@/server/resources";
import { saveSettings } from "@/server/settings";
import { logEvent } from "@/server/audit";

export interface ActionResult { ok: boolean; message: string }

/* ── Generic resource CRUD (allow-listed columns, permission-checked, audited) ── */

export async function saveResource(resourceKey: string, formData: FormData): Promise<ActionResult> {
  let user;
  try { user = assertAdmin(); } catch { return { ok: false, message: "Not authorized." }; }
  const def = getResources()[resourceKey];
  if (!def) return { ok: false, message: "Unknown resource." };
  try { user = assertAdmin(def.permission); } catch { return { ok: false, message: "You don't have permission for this action." }; }

  const db = getDb();
  const id = String(formData.get("__id") ?? "").trim();
  let existing: Record<string, any> | null = null;
  if (id) {
    existing = get(db, `SELECT * FROM ${def.table} WHERE id = ?`, Number(id));
    if (!existing) return { ok: false, message: "Item not found." };
  }

  let values: Record<string, any>;
  try {
    values = validateAndCoerce(def, formData, existing);
    if (def.transform) values = await def.transform(values, existing);
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : "Validation failed." };
  }

  // only allow-listed columns from the def are ever written
  const cols = def.fields.map((f) => f.name).filter((c) => values[c] !== undefined)
    .concat(["api_key_encrypted", "password_hash", "updated_at", "published_at"])
    .filter((c) => values[c] !== undefined);

  try {
    if (existing) {
      const sets = cols.map((c) => `${c} = ?`).join(", ");
      run(db, `UPDATE ${def.table} SET ${sets} WHERE id = ?`, ...cols.map((c) => values[c]), existing.id);
    } else {
      const placeholders = cols.map(() => "?").join(", ");
      run(db, `INSERT INTO ${def.table} (${cols.join(", ")}) VALUES (${placeholders})`, ...cols.map((c) => values[c]));
    }
  } catch (err: any) {
    if (String(err).includes("UNIQUE")) return { ok: false, message: "A record with this unique value (slug/key/email) already exists." };
    return { ok: false, message: "Could not save — check required fields." };
  }

  logEvent({ type: "admin_action", actor: user.email, action: existing ? `${def.singular.toLowerCase()}.updated` : `${def.singular.toLowerCase()}.created`, object: String(values.name ?? values.label ?? values.slug ?? values.key ?? id), ip: await requestIp() });
  revalidatePath("/", "layout");
  return { ok: true, message: `${def.singular} saved.` };
}

export async function deleteResource(resourceKey: string, id: number): Promise<ActionResult> {
  let user;
  try { user = assertAdmin(); } catch { return { ok: false, message: "Not authorized." }; }
  const def = getResources()[resourceKey];
  if (!def) return { ok: false, message: "Unknown resource." };
  try { user = assertAdmin(def.permission); } catch { return { ok: false, message: "You don't have permission for this action." }; }
  const db = getDb();
  const row = get<Record<string, any>>(db, `SELECT * FROM ${def.table} WHERE id = ?`, id);
  if (!row) return { ok: false, message: "Item not found." };
  if (def.deletable && !def.deletable(row)) return { ok: false, message: "This item is protected and cannot be deleted." };
  run(db, `DELETE FROM ${def.table} WHERE id = ?`, id);
  logEvent({ type: "admin_action", actor: user.email, action: `${def.singular.toLowerCase()}.deleted`, object: String(row.name ?? row.label ?? row.slug ?? row.key ?? id), ip: await requestIp() });
  revalidatePath("/", "layout");
  return { ok: true, message: `${def.singular} deleted.` };
}

/* ── Settings groups ───────────────────────────────────────────────── */

export async function saveSettingsGroup(group: string, formData: FormData): Promise<ActionResult> {
  let user;
  try { user = assertAdmin("settings.manage"); } catch { return { ok: false, message: "You don't have permission for this action." }; }
  const patch: Record<string, any> = {};
  const jsonFields: Record<string, string[]> = {};
  // settings pages send simple scalars; arrays arrive as JSON in hidden fields prefixed __json__
  for (const [key, value] of formData.entries()) {
    if (key.startsWith("__json__")) { jsonFields[key.replace("__json__", "")] = JSON.parse(String(value)); continue; }
    if (key.startsWith("__bool__")) { patch[key.replace("__bool__", "")] = value === "1"; continue; }
    const num = String(value);
    if (num !== "" && !Number.isNaN(Number(num)) && /^-?\d+(\.\d+)?$/.test(num) && (key.includes("Hours") || key.includes("Attempts") || key.includes("Minutes") || key.includes("Limit") || key.endsWith("_ms"))) {
      patch[key] = Number(num);
    } else {
      patch[key] = String(value);
    }
  }
  for (const [k, v] of Object.entries(jsonFields)) patch[k] = v;
  saveSettings(group as any, patch as any);
  logEvent({ type: "admin_action", actor: user.email, action: "settings.changed", object: group, ip: await requestIp() });
  revalidatePath("/", "layout");
  return { ok: true, message: "Settings saved." };
}

/* ── Media actions ─────────────────────────────────────────────────── */

export async function updateMediaAlt(id: number, alt: string): Promise<ActionResult> {
  try { assertAdmin("content.manage"); } catch { return { ok: false, message: "Not authorized." }; }
  run(getDb(), "UPDATE media SET alt_text = ? WHERE id = ?", alt.slice(0, 300), id);
  revalidatePath("/admin/media");
  return { ok: true, message: "Alt text saved." };
}

export async function deleteMedia(id: number): Promise<ActionResult> {
  let user;
  try { user = assertAdmin("content.manage"); } catch { return { ok: false, message: "Not authorized." }; }
  const db = getDb();
  const row = get<{ filename: string; path: string }>(db, "SELECT filename, path FROM media WHERE id = ?", id);
  if (!row) return { ok: false, message: "Not found." };
  const { deleteStoredFile } = await import("@/server/storage");
  deleteStoredFile(row.path);
  run(db, "DELETE FROM media WHERE id = ?", id);
  logEvent({ type: "admin_action", actor: user.email, action: "media.deleted", object: row.filename, ip: await requestIp() });
  revalidatePath("/admin/media");
  return { ok: true, message: "Media deleted." };
}

/* ── Blog actions (dedicated editor) ──────────────────────────────── */

export async function saveBlogPost(formData: FormData): Promise<ActionResult> {
  let user;
  try { user = assertAdmin("blog.manage"); } catch { return { ok: false, message: "You don't have permission for this action." }; }
  const db = getDb();
  const id = String(formData.get("__id") ?? "").trim();
  const title = String(formData.get("title") ?? "").trim();
  if (title.length < 3) return { ok: false, message: "Title is too short." };
  const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 90);
  const slug = slugify(String(formData.get("slug") ?? "") || title);
  const content = String(formData.get("content") ?? "");
  const reading = Math.max(1, Math.round(content.split(/\s+/).filter(Boolean).length / 200));
  const status = String(formData.get("status") ?? "draft");
  const publishAtRaw = String(formData.get("publish_at") ?? "").trim();
  const publishAt = publishAtRaw ? new Date(publishAtRaw).toISOString().slice(0, 19).replace("T", " ") : nowIso().slice(0, 19).replace("T", " ");
  const categoryId = String(formData.get("category_id") ?? "");
  let tags: string[] = [], faq: any[] = [];
  try { tags = String(formData.get("tags") ?? "").split(",").map((t) => t.trim()).filter(Boolean).slice(0, 10); } catch {}
  try { const f = String(formData.get("faq") ?? "").trim(); if (f) { faq = JSON.parse(f); if (!Array.isArray(faq)) faq = []; } } catch { return { ok: false, message: "FAQ must be valid JSON: [{question, answer}]" }; }

  const values: any[] = [];
  const cols = "title, slug, excerpt, content, status, publish_at, author_name, featured_image, featured_image_alt, category_id, tags, faq, seo_title, meta_description, canonical_url, og_image, noindex, reading_minutes, updated_at";
  const vals = () => {
    const published = status === "published" && new Date(publishAt) <= new Date();
    return [title, slug, String(formData.get("excerpt") ?? "").slice(0, 400), content, status, publishAt,
      String(formData.get("author_name") ?? "Admin").slice(0, 100) || "Admin",
      String(formData.get("featured_image") ?? ""), String(formData.get("featured_image_alt") ?? ""),
      categoryId ? Number(categoryId) : null, JSON.stringify(tags), JSON.stringify(faq),
      String(formData.get("seo_title") ?? ""), String(formData.get("meta_description") ?? ""),
      String(formData.get("canonical_url") ?? ""), String(formData.get("og_image") ?? ""),
      formData.get("noindex") === "on" ? 1 : 0, reading, nowIso()].map((v, i) => i === 10 || i === 11 ? v : v);
  };

  try {
    if (id) {
      const existing = get<{ published_at: string }>(db, "SELECT published_at FROM blog_posts WHERE id = ?", Number(id));
      const v = vals();
      run(db, `UPDATE blog_posts SET ${cols} WHERE id = ?`, ...v, Number(id));
      if (!existing?.published_at && status === "published" && new Date(publishAt) <= new Date()) {
        run(db, "UPDATE blog_posts SET published_at = ? WHERE id = ?", publishAt, Number(id));
      }
    } else {
      const v = vals();
      run(db, `INSERT INTO blog_posts (${cols}) VALUES (${cols.split(", ").map(() => "?").join(", ")})`, ...v);
    }
  } catch (err: any) {
    if (String(err).includes("UNIQUE")) return { ok: false, message: "A post with this slug already exists." };
    return { ok: false, message: "Could not save the post." };
  }
  logEvent({ type: "admin_action", actor: user.email, action: status === "published" ? "blog.published" : "blog.saved", object: slug, ip: await requestIp() });
  revalidatePath("/", "layout");
  return { ok: true, message: `Post saved (${status}).` };
}

export async function deleteBlogPost(id: number): Promise<ActionResult> {
  let user;
  try { user = assertAdmin("blog.manage"); } catch { return { ok: false, message: "Not authorized." }; }
  const db = getDb();
  const row = get<{ slug: string }>(db, "SELECT slug FROM blog_posts WHERE id = ?", id);
  if (!row) return { ok: false, message: "Not found." };
  run(db, "DELETE FROM blog_posts WHERE id = ?", id);
  logEvent({ type: "admin_action", actor: user.email, action: "blog.deleted", object: row.slug, ip: await requestIp() });
  revalidatePath("/", "layout");
  return { ok: true, message: "Post deleted." };
}

/* ── System actions ────────────────────────────────────────────────── */

export async function clearLogs(type: string): Promise<ActionResult> {
  let user;
  try { user = assertAdmin("settings.manage"); } catch { return { ok: false, message: "Not authorized." }; }
  const db = getDb();
  if (type === "all") run(db, "DELETE FROM system_logs");
  else run(db, "DELETE FROM system_logs WHERE type = ?", type);
  logEvent({ type: "admin_action", actor: user.email, action: "logs.cleared", object: type, ip: await requestIp() });
  revalidatePath("/admin/logs");
  return { ok: true, message: "Logs cleared." };
}

export async function changeOwnPassword(currentPassword: string, newPassword: string): Promise<ActionResult> {
  let user;
  try { user = assertAdmin(); } catch { return { ok: false, message: "Not authorized." }; }
  if (newPassword.length < 10) return { ok: false, message: "New password must be at least 10 characters." };
  const { verifyPasswordHash, hashPassword } = await import("@/server/auth");
  const db = getDb();
  const row = get<{ password_hash: string }>(db, "SELECT password_hash FROM admin_users WHERE id = ?", user.id);
  if (!row || !verifyPasswordHash(currentPassword, row.password_hash)) return { ok: false, message: "Current password is incorrect." };
  run(db, "UPDATE admin_users SET password_hash = ?, updated_at = ? WHERE id = ?", hashPassword(newPassword), nowIso(), user.id);
  logEvent({ type: "security", actor: user.email, action: "password.changed", ip: await requestIp() });
  return { ok: true, message: "Password changed." };
}
