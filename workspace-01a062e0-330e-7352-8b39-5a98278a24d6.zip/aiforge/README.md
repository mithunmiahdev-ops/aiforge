# AIForge — Free AI Tools Platform

> **🔑 Admin login:** `/admin/login` → `admin@example.com` / `DemoAdmin!2026`
> Demo AI providers are **enabled by default** — every tool generates instantly
> (clearly-watermarked demo output). See **LOGIN-INFO.md** and “Connecting real AI” below.

A production-ready AI tools web platform where **visitors use every tool for free without any account**, managed through a secure, full-featured admin CMS.

Built with **Next.js 14 (App Router) · TypeScript · Tailwind CSS · SQLite (dev) / PostgreSQL-ready (prod)**.

---

## Quick start

```bash
npm install
cp .env.example .env      # optional — sensible defaults are auto-generated
npm run dev               # → http://localhost:3000
```

On first boot the app automatically creates the database, runs migrations and seeds
demo content (tools, categories, blog posts, FAQs, templates, legal pages — all marked *demo*
so you can replace them from the admin panel).

### Admin access

- URL: **`/admin/login`** (deliberately unadvertised on the public site)
- Credentials come from `ADMIN_EMAIL` / `ADMIN_PASSWORD` env vars. If no password is set,
  a strong random one is generated and printed **once** to the server console and to
  `data/.initial-admin.txt` (delete the file after first login).
- Passwords are stored as **scrypt hashes** — never plaintext.
- For this workspace preview the seeded demo credentials are:
  `admin@example.com` / `DemoAdmin!2026` (change them before any real deployment).

### Demo AI providers

No AI API is hard-coded. Four **demo providers** are seeded **enabled by default**, so every
tool works instantly — their output is always clearly watermarked ("DEMO OUTPUT — no real
AI provider is connected") and never presented as real AI. Demo providers sit at priority
`900`: the moment you enable a real provider (priority `100`), it takes over automatically
and the demo becomes a last-resort fallback. Disable them entirely in
**Admin → AI Providers** once real keys are configured.

---

## Architecture

```
src/
  app/
    (public)/          Public site: home, /tools, /tools/[slug], /blog, /pricing,
                       /about, /contact, /search, legal pages ([page]/[slug])
    admin/login/       Secure admin login (rate-limited server action)
    admin/(dash)/      Admin CMS — 20+ sections (dashboard, tools, providers, blog,
                       media, SEO, ads, analytics, users, usage, logs, security, system…)
    api/
      generate/[slug]/ Anonymous generation endpoint (validation + limits + jobs)
      jobs/[id]/       Job polling (owner-scoped)
      search/          Autocomplete
      media/…          Media upload (admin) + file serving (traversal-guarded)
    sitemap.ts robots.ts manifest.ts ads.txt/   SEO/PWA/AdSense plumbing
  server/
    providers.ts       Modular AI provider layer (adapters + fallback chain)
    jobs.ts            Generation job system (queued→processing→completed/failed)
    auth.ts            Sessions, roles/permissions, admin guards
    crypto.ts          AES-256-GCM secret encryption, scrypt hashing, tokens
    ratelimit.ts       DB-backed fixed-window rate limiting
    resources.ts       Allow-listed resource registry powering admin CRUD
    settings.ts        Typed settings groups (site/seo/ads/analytics/security/system…)
    cms.ts storage.ts audit.ts
  db/                  schema.sql + seed + connection (better-sqlite3)
  components/          Design system, header/footer, tool clients (video/image/prompt/
                       audio/schema-driven text), admin UI (resource manager, charts)
```

### The AI provider rule (no keys in the frontend)

```
Visitor → Frontend → Secure backend (this app) → AI provider → backend → visitor
```

- API keys are entered in **Admin → AI Providers**, encrypted with **AES-256-GCM**
  (key derived from `APP_SECRET`) and stored server-side only. They are never serialized
  to any client — the admin UI only ever sees "has key: yes/no".
- **Adapters** (swap providers without touching the app):
  - `openai` — any OpenAI-compatible REST API: `/chat/completions` (text),
    `/images/generations` (image), `/audio/speech` (TTS/audio).
  - `custom-http` — your endpoint receives `{tool, capability, params, prompt, system}` and
    returns `{url}` | `{b64, mime}` | `{text}`. Use this for any video-generation provider.
  - `demo` — local, watermarked placeholders for testing.
- Providers resolve by **priority** with automatic **fallback** across the chain, per
  capability (video / image / text / audio). Tools may pin a preferred provider.

### Anonymous usage & abuse prevention

No visitor accounts. Controls (all admin-configurable per tool, enforced server-side):
- daily generations per anonymous session **and** per IP (global cap in Security settings)
- cooldown between generations
- max prompt length, max duration, allowed aspect ratios/counts (validated server-side)
- anonymous session cookie (`aiforge_anon`, httpOnly), origin checking on mutations
- login rate limiting per IP + email, scrypt hashing, hashed session tokens, secure cookies
- every admin mutation is permission-checked and audit-logged

### Generation jobs

`generation_jobs` table with states `queued → processing → completed | failed | cancelled`,
tracking tool, anonymous session, provider, model, timings, public-safe error message and a
separate `internal_error` that is **never** exposed to visitors. Jobs are processed
in-process; stuck jobs self-heal after 5 minutes. For heavy load, point a background worker
at the same table — the create/poll API contract is already queue-shaped.

---

## Admin CMS coverage

| Area | What's editable |
|---|---|
| **Dashboard** | Usage totals, 30-day chart, top tools, provider usage, est. API cost, system status, recent activity |
| **Site & Branding** | Name, tagline, logo, favicon, primary/secondary colors (live), default theme, footer, socials, contact email |
| **Homepage** | Every section: reorder, enable/disable, titles, subtitles, JSON content (hero copy, steps, features, CTA, stats) |
| **Navigation** | Header menu + dropdowns, header CTAs, footer columns — order, labels, URLs, enable/disable |
| **AI Tools** | Full CRUD: slug, type (UI), capability, config JSON (options/presets/form fields), icons, flags, per-tool limits, SEO, provider pinning |
| **Tool Categories** | CRUD with icons + SEO |
| **AI Providers** | Adapters, endpoints, keys (encrypted), models, priority, timeout, request caps, fallbacks |
| **Blog** | Markdown editor, drafts/schedule/publish, categories, tags, featured image, reading time, FAQ blocks, full per-post SEO |
| **Media** | Upload (auto-WebP ≤1920px), alt text, copy URL, search, delete |
| **Prompt Templates** | CRUD with `{{placeholders}}`, surfaced in the Prompt Generator |
| **FAQs** | Per-section (home / tool slug) with FAQ schema output |
| **SEO** | Title template `{title} \| {siteName}`, defaults, OG image, robots, per-page noindex, sitemap/robots auto |
| **Ads** | AdSense publisher ID, per-placement slots, responsive/vertical formats, page exclusions, test mode, ads.txt auto-generated |
| **Analytics** | GA4 / GTM IDs (validated, only load when enabled + consent given), Search Console verification |
| **Admins & Roles** | Users, roles with granular permissions (Administrator/Editor/Viewer), password changes |
| **Usage** | Job browser with filters (tool/status), cost assumptions |
| **Logs** | Audit trail: admin actions, security events, errors (with IP where appropriate) |
| **Security** | Login attempt limits, session duration, global rate limits, recent attempts view |
| **Settings** | Maintenance mode (admin-bypassed), pricing page plans, audio languages/voices |
| **System** | Health of DB/providers/storage/runtime, recent errors, production checklist |

---

## SEO system

- Semantic HTML, clean URLs (`/tools/ai-video-generator`, `/blog/[slug]`)
- Dynamic metadata with admin-controlled title template, canonical URLs, OG + Twitter cards
- JSON-LD: **WebSite, Organization, SoftwareApplication (tools), Article (blog), FAQPage, BreadcrumbList**
- `sitemap.xml` (tools + posts + categories + pages), `robots.txt`, per-entity noindex toggles
- Search results page noindexed by default; lazy-loaded images with alt text; lightweight JS (~100 kB first load)

## Monetization (AdSense-ready)

Placements: below hero, between sections, tool top/middle/bottom, sidebar (desktop), blog content, footer —
each independently enabled with its own slot ID, format and page exclusions. Ads render **nothing** until a
valid `ca-pub-…` publisher ID is set. **Test mode** shows outlined placeholders to verify placement safely.
Ads are always labeled "Advertisement" and never placed near generation controls. `ads.txt` is generated
automatically. No click-bait or policy-hostile tricks anywhere.

## PWA

Web manifest with generated icons + theme colors; a conservative service worker
(network-first for content, cache-first only for static assets) registers in production builds only.

---

## Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `APP_SECRET` | Encrypts provider API keys at rest + hashes session tokens | auto-generated → `data/.app-secret` (set it in prod!) |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` / `ADMIN_NAME` | Initial admin (first boot only) | random password printed once |
| `PUBLIC_BASE_URL` | Canonical URL for SEO/sitemap/OG | `http://localhost:3000` |
| `DATABASE_PATH` | SQLite file | `./data/app.db` |
| `STORAGE_DIR` | Uploads + generated assets | `./storage` |

## Production deployment

1. Set the env vars above (a 64-hex `APP_SECRET` is critical — rotating it invalidates stored API keys).
2. `npm run build && npm start` (binds 0.0.0.0:3000) — or deploy to Vercel/Docker.
3. Log in, change the admin password, replace demo content, review legal page templates.
4. Configure real AI providers per capability and disable demo providers.

### Switching to PostgreSQL

SQLite keeps local setup zero-config. For multi-instance production:

- All data access flows through `src/db` + parameterized SQL in `src/server/*`, so the
  swap is contained: replace `better-sqlite3` with `postgres`/`pg` (or introduce Drizzle/Prisma),
  translate `schema.sql` (types: `INTEGER PRIMARY KEY AUTOINCREMENT` → `SERIAL`, `TEXT` ISO dates →
  `TIMESTAMPTZ`, `INTEGER` booleans → `BOOLEAN`) and adapt the four helpers in `src/db/index.ts`
  (`all/get/run` + connection). Queries themselves are ANSI-compatible.

### Storage → S3

`src/server/storage.ts` is the single seam: swap `saveBuffer/readStoredFile/deleteStoredFile`
for S3 SDK calls (presigned URLs) and point the media route at it.

### Job worker at scale

The create/poll API is queue-shaped. Run a worker that claims `queued` jobs
(`UPDATE … WHERE status='queued'`), executes the same `processJob` logic and set
`processJobAsync` to a no-op — nothing else changes.

---

## Scripts

| Command | Description |
|---|---|
| `npm run dev` | Dev server on 0.0.0.0:3000 (auto-migrates + seeds on boot) |
| `npm run build` | Production build |
| `npm start` | Production server |
| `npm run typecheck` | Strict TypeScript check |
| `npm run setup` | Creates `.env` + data directories |

## Notes & honest-design decisions

- **No fake data**: no fabricated testimonials or usage statistics anywhere. The stats
  homepage section ships disabled with an admin warning to enter only verifiable numbers.
- Demo blog posts/legal pages are explicitly labeled *(demo)* and editable.
- The demo AI provider always watermarks its output and states it isn't real AI.
- Minimal data collection: anonymous session ID + rate-limit counters only; contact form
  stores only what the visitor types; cookie consent gates optional analytics/ads.
