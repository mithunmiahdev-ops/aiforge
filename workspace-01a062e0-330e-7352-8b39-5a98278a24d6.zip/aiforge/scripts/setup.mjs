#!/usr/bin/env node
/**
 * AIForge setup helper — creates .env (with a generated APP_SECRET) and data dirs.
 * The app also self-initializes on first boot, so this script is optional convenience.
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const root = process.cwd();
const envPath = path.join(root, ".env");

fs.mkdirSync(path.join(root, "data"), { recursive: true });
fs.mkdirSync(path.join(root, "storage", "uploads"), { recursive: true });
fs.mkdirSync(path.join(root, "storage", "generated"), { recursive: true });

if (!fs.existsSync(envPath)) {
  const env = `APP_SECRET=${crypto.randomBytes(32).toString("hex")}
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=
ADMIN_NAME=Administrator
PUBLIC_BASE_URL=http://localhost:3000
DATABASE_PATH=./data/app.db
STORAGE_DIR=./storage
`;
  fs.writeFileSync(envPath, env, { mode: 0o600 });
  console.log("✓ Created .env with a generated APP_SECRET");
  console.log('  → Set ADMIN_PASSWORD before first boot, or a random one will be generated');
  console.log('    and printed to the console + data/.initial-admin.txt');
} else {
  console.log("• .env already exists — left untouched");
}
console.log("✓ Created data/ and storage/ directories");
console.log("\nNext steps:  npm run dev  →  http://localhost:3000  ·  admin at /admin/login");
