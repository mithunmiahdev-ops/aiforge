# 🔑 AIForge — Login & Quick Reference

## Admin Login (the only login on this platform)

| | |
|---|---|
| **URL** | **`/admin/login`**  (from the live preview: `http://localhost:3000/admin/login`) |
| **Email** | **`admin@example.com`** |
| **Password** | **`DemoAdmin!2026`** |

✅ Credentials verified against the database hash (and re-verified after every fix).

Visitors never need an account — every tool on the public site is free with no signup.

> ⚠️ Demo credentials for this workspace. Before real deployment: change the password
> in **Admin → Security**, or set `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env` before first boot.

---

## Everything verified working (latest full test run — zero server errors)

| Feature | Result |
|---|---|
| **Video Generator** | ✅ Real **24-frame animated GIF** (341 KB, watermark "DEMO", honors 16:9 / 9:16 / 1:1) — plays inline + downloads |
| **Image Generator** | ✅ Multiple variants per request (tested 2 & 3), gallery + download on every device |
| **Audio Generator** | ✅ Real playable WAV that honors requested duration (tested 15s → exactly 15s) |
| **Story / Blog / SEO / Hashtag… tools** | ✅ All 16 tools generate output |
| **Prompt Generator** | ✅ Generate + Improve / Shorten / Expand all return distinct results |
| Public pages | ✅ All 200 (home, tools, blog, pricing, legal, search…) |
| Admin CMS | ✅ All 22 sections 200, audit-logged, permission-checked |
| Abuse controls | ✅ Cooldowns, daily caps, prompt-length limits, login rate limiting |

## Fixes made in this round

1. **Video results are now real animated GIF files** — I wrote a pure-Node GIF89a + LZW
   encoder (`src/server/gif.ts`), found and fixed a subtle LZW code-size boundary bug,
   and validated every output frame-by-frame with libvips (the same decoder browsers-class
   image libraries use). Videos now visibly **move** in the preview and download as real files.
2. **Generation UI can no longer hang** — polling now retries network misses and times out
   with a clear message instead of spinning forever.
3. **Image download buttons always visible on phones/tablets** (were hover-only before).
4. Restarted the preview server (it stops when the sandbox resets between our chats —
   if it ever looks "down", just tell me and I'll restart it).

## Important: demo vs. real AI

All generations currently come from the built-in **demo providers** — honest, watermarked
placeholders so the full flow works **before** you add any API key. To generate real content:

1. Admin → **AI Providers** → edit a provider (e.g. *OpenAI-compatible (text)*)
2. Paste your **API key** (stored AES-256-GCM encrypted, never sent to the browser)
3. Set the **model**, **enable**, save — it automatically takes over from the demo
   (real providers run at priority 100, demos stay at 900 as fallback)

Video works through the **Custom HTTP** adapter with any video provider — your endpoint
receives `{tool, capability, params, prompt}` and returns `{url}` (see README for the contract).
